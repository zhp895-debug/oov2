import Link from 'next/link'
import HeaderClient from '@/components/HeaderClient'
import FooterCTA from '@/components/FooterCTA'
import { ArrowLeft, Home } from 'lucide-react'

export const metadata = {
  title: 'Page Not Found — 404',
  description: 'The page you are looking for could not be found.',
}

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col bg-neutral-950 text-white">
      <HeaderClient />
      <main className="flex-1 flex items-center justify-center px-4 py-24">
        <div className="max-w-md w-full text-center">
          <span className="text-sm font-semibold tracking-wider uppercase text-brand-400">404 Error</span>
          <h1 className="mt-3 text-4xl sm:text-5xl font-extrabold tracking-tight">Page Not Found</h1>
          <p className="mt-4 text-base text-neutral-400">
            The page you are looking for doesn't exist, has been moved, or is restricted.
          </p>
          <div className="mt-8 flex items-center justify-center gap-4">
            <Link
              href="/"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-brand-500 hover:bg-brand-600 text-white font-semibold text-sm transition"
            >
              <Home className="h-4 w-4" /> Go Home
            </Link>
            <Link
              href="/admin/login"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-neutral-800 hover:bg-neutral-700 text-neutral-200 font-semibold text-sm transition"
            >
              Admin Portal
            </Link>
          </div>
        </div>
      </main>
      <FooterCTA />
    </div>
  )
}

import { notFound } from 'next/navigation'
import { SERVICE_CATEGORIES, getCategoryBySlug } from '@/lib/services-data'
import { getServiceExtras } from '@/lib/service-extras'
import ServiceDetailClient from '@/components/ServiceDetailClient'
import { getServiceSchema, getBreadcrumbSchema } from '@/lib/seo'

export function generateStaticParams() {
  return SERVICE_CATEGORIES.map((c) => ({ slug: c.slug }))
}

export async function generateMetadata({ params }) {
  const { slug } = await params
  const cat = getCategoryBySlug(slug)
  if (!cat) return { title: 'Service — Olive Orange' }
  return {
    title: `${cat.name} | Olive Orange Services`,
    description: cat.tagline,
    alternates: {
      canonical: `/services/${cat.slug}`,
    },
    openGraph: {
      title: `${cat.name} — Olive Orange Technologies`,
      description: cat.tagline,
      url: `https://oliveorangetech.in/services/${cat.slug}`,
    },
  }
}

export default async function ServiceDetailPage({ params }) {
  const { slug } = await params
  const cat = getCategoryBySlug(slug)
  if (!cat) notFound()
  const related = (cat.related || [])
    .map((s) => getCategoryBySlug(s))
    .filter(Boolean)
    .map((r) => ({ slug: r.slug, name: r.name, icon: r.icon, tagline: r.tagline }))
  const extras = getServiceExtras(slug)

  const serviceSchema = getServiceSchema(cat)
  const breadcrumbSchema = getBreadcrumbSchema([
    { name: 'Home', url: '/' },
    { name: 'Services', url: '/services' },
    { name: cat.name, url: `/services/${cat.slug}` },
  ])

  return (
    <>
      {serviceSchema && (
        <script
          id="schema-service"
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }}
          suppressHydrationWarning
        />
      )}
      <script
        id="schema-breadcrumb-service"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
        suppressHydrationWarning
      />
      <ServiceDetailClient category={cat} related={related} extras={extras} />
    </>
  )
}

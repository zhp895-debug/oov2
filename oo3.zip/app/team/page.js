import TeamClient from '@/components/TeamClient'
import { getBreadcrumbSchema } from '@/lib/seo'
import { getTeamMembers, getSettings } from '@/lib/cms-store'

export const dynamic = 'force-dynamic'

export const metadata = {
  title: 'Team & Leadership — Olive Orange Technologies',
  description:
    'Meet the leadership and engineering team at Olive Orange Technologies. We analyse your business problems and build the right digital solution.',
  alternates: {
    canonical: '/team',
  },
  openGraph: {
    title: 'Team & Leadership — Olive Orange Technologies',
    description:
      'Meet the leadership and engineering team at Olive Orange Technologies. We analyse your business problems and build the right digital solution.',
    url: 'https://oliveorangetech.in/team',
  },
}

export default async function TeamPage() {
  const activeMembers = await getTeamMembers({ onlyActive: true })
  const settings = await getSettings()

  const breadcrumbSchema = getBreadcrumbSchema([
    { name: 'Home', url: '/' },
    { name: 'Team', url: '/team' },
  ])

  return (
    <>
      <script
        id="schema-breadcrumb-team"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
        suppressHydrationWarning
      />
      <TeamClient initialMembers={activeMembers} settings={settings} />
    </>
  )
}

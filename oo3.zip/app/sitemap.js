import { SERVICE_CATEGORIES } from '@/lib/services-data'
import { PRODUCTS } from '@/lib/products-data'
import { INDUSTRY_LIST } from '@/lib/industries-data'
import { getAllPosts, getCategories } from '@/lib/cms-store'

export default async function sitemap() {
  const baseUrl = (process.env.NEXT_PUBLIC_SITE_URL || 'https://oliveorangetech.in').replace(/\/$/, '')
  const now = new Date().toISOString()

  // Core static pages
  const staticRoutes = [
    '',
    '/services',
    '/products',
    '/industries',
    '/about',
    '/team',
    '/contact',
    '/game',
    '/blog',
  ].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: now,
    changeFrequency: route === '' || route === '/blog' ? 'daily' : 'weekly',
    priority: route === '' ? 1.0 : 0.8,
  }))

  // 12 Capabilities / Services
  const serviceRoutes = SERVICE_CATEGORIES.map((s) => ({
    url: `${baseUrl}/services/${s.slug}`,
    lastModified: now,
    changeFrequency: 'weekly',
    priority: 0.9,
  }))

  // 15 Software Products
  const productRoutes = PRODUCTS.map((p) => ({
    url: `${baseUrl}/products/${p.slug}`,
    lastModified: now,
    changeFrequency: 'weekly',
    priority: 0.85,
  }))

  // Priority Industries
  const industryRoutes = INDUSTRY_LIST.map((ind) => ({
    url: `${baseUrl}/industries/${ind.slug}`,
    lastModified: now,
    changeFrequency: 'monthly',
    priority: 0.8,
  }))

  // Published Blogs only
  const publishedPosts = await getAllPosts({ includeDrafts: false })
  const blogRoutes = publishedPosts.map((p) => ({
    url: `${baseUrl}/blog/${p.slug}`,
    lastModified: p.updatedAt || p.publicationDate || now,
    changeFrequency: 'monthly',
    priority: 0.75,
  }))

  // Blog Categories
  const categories = await getCategories()
  const categoryRoutes = categories.map((c) => ({
    url: `${baseUrl}/blog/category/${c.slug}`,
    lastModified: now,
    changeFrequency: 'weekly',
    priority: 0.7,
  }))

  return [
    ...staticRoutes,
    ...serviceRoutes,
    ...productRoutes,
    ...industryRoutes,
    ...blogRoutes,
    ...categoryRoutes,
  ]
}

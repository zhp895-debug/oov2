'use client'
import { useEffect, useRef, useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { motion, useInView } from 'framer-motion'
import {
  ArrowRight,
  Play,
  Sparkles,
  ShieldCheck,
  Zap,
  Gamepad2,
  MessageSquare,
  Bot,
  Boxes,
  Globe2,
  Smartphone,
  LayoutDashboard,
  Rocket,
  CheckCircle2,
  TrendingUp,
  BarChart3,
  Layers,
  Award,
  Phone,
  Target,
  Users,
  Building2,
  Palette,
  Search,
  Wrench,
  GraduationCap,
} from 'lucide-react'
import HeaderClient from '@/components/HeaderClient'
import FooterCTA from '@/components/FooterCTA'
import DemoModal from '@/components/DemoModal'
import GameChallenge from '@/components/GameChallenge'
import { OliImage } from '@/components/OliMascot'
import { SERVICE_CATEGORIES } from '@/lib/services-data'
import { PRODUCTS } from '@/lib/products-data'
import { INDUSTRY_LIST } from '@/lib/industries-data'

function Counter({ to = 100, suffix = '', duration = 1.6 }) {
  const ref = useRef(null)
  const inView = useInView(ref, { once: true, margin: '-40px' })
  const [val, setVal] = useState(0)
  useEffect(() => {
    if (!inView) return
    const start = performance.now()
    let raf
    const tick = (t) => {
      const p = Math.min(1, (t - start) / (duration * 1000))
      const eased = 1 - Math.pow(1 - p, 3)
      setVal(Math.round(to * eased))
      if (p < 1) raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [inView, to, duration])
  return <span ref={ref}>{val}{suffix}</span>
}

const SERVICE_ICON_MAP = {
  'Palette': Palette,
  'Globe': Globe2,
  'Briefcase': LayoutDashboard,
  'Megaphone': TrendingUp,
  'Bot': Bot,
  'BarChart3': BarChart3,
  'Layers': Layers,
  'Search': Search,
  'Wrench': Wrench,
  'Network': Boxes,
  'Smartphone': Smartphone,
  'GraduationCap': GraduationCap,
}

const PROCESS_STEPS = [
  { step: '01', title: 'Discover & Diagnose', desc: 'We analyse your actual workflows, spreadsheets, and bottlenecks to identify root problems.' },
  { step: '02', title: 'Architect Solution', desc: 'Design tailored data models, system interfaces, integrations, and operational roadmaps.' },
  { step: '03', title: 'Iterative Engineering', desc: 'Sprint-based development with direct working software demos at every single milestone.' },
  { step: '04', title: 'Deploy & Onboard', desc: 'Seamless release, database onboarding, staff training, and zero-downtime transition.' },
  { step: '05', title: 'Sustained Support', desc: 'Direct WhatsApp & phone reach, regular enhancements, security updates, and monitoring.' },
]

export const BUSINESS_PROBLEMS = [
  {
    problem: 'Low Sales & Conversions',
    symptom: 'Traffic visits your website or social channels but rarely converts into qualified customer inquiries.',
    solution: 'Digital Visibility + Lead Capture Systems + Automated Follow-Ups',
    link: '/services/digital-marketing',
    badge: 'Growth & Visibility',
  },
  {
    problem: 'Missed & Delayed Leads',
    symptom: 'Prospects drop off because inquiries sit unaddressed on WhatsApp or in personal inboxes for hours.',
    solution: 'Oli CRM + Multi-Channel Lead Automation',
    link: '/products/oli-crm',
    badge: 'CRM Automation',
  },
  {
    problem: 'Slow Manual Operations',
    symptom: 'Staff spend valuable hours manually re-keying data between spreadsheets and accounting systems.',
    solution: 'Workflow Automation + Custom Operational Software',
    link: '/services/ai-solutions-automation',
    badge: 'Process Automation',
  },
  {
    problem: 'Repetitive Routine Inquiries',
    symptom: 'Support teams repeatedly answer identical questions, calculate quotes, and check order statuses manually.',
    solution: 'Conversational AI Assistants & WhatsApp Business Automation',
    link: '/services/ai-solutions-automation',
    badge: 'AI Solutions',
  },
  {
    problem: 'No Real-Time Visibility',
    symptom: 'Management waits weeks for manual summaries to understand margins, cash flow, and stock levels.',
    solution: 'Real-Time Analytics, BI Dashboards & System Telemetry',
    link: '/services/data-analytics',
    badge: 'Business Intelligence',
  },
  {
    problem: 'Poor Customer Experience',
    symptom: 'Customers face clunky mobile interfaces, broken forms, or delayed service updates.',
    solution: 'Modern High-Performance Web Architecture & Mobile Apps',
    link: '/services/website-development',
    badge: 'Web & Mobile',
  },
  {
    problem: 'Weak Brand Perception',
    symptom: 'Prospects question credibility or pricing due to disjointed visual assets or outdated presentation.',
    solution: 'Cohesive Visual Identity Systems & Digital Design Assets',
    link: '/services/branding-creative',
    badge: 'Brand Strategy',
  },
  {
    problem: 'Invisible on Search & AI',
    symptom: 'Your business does not appear when buyers search on Google or ask ChatGPT, Perplexity, and Gemini.',
    solution: 'AEO (Answer Engine) + GEO + Technical SEO Optimization',
    link: '/services/ai-visibility-seo',
    badge: 'AEO & GEO Search',
  },
  {
    problem: 'Disconnected Software Silos',
    symptom: 'Inventory, billing, CRM, and logistics operate on separate tools with zero automated sync.',
    solution: 'Business Ecosystem Architecture & Centralized API Connectors',
    link: '/services/business-ecosystem',
    badge: 'Ecosystem Sync',
  },
  {
    problem: 'Recurring Technology Outages',
    symptom: 'Unmaintained web servers, unpatched CMS vulnerabilities, and unexpected outages jeopardize sales.',
    solution: 'Proactive System Maintenance, Security Patches & Cloud SLA',
    link: '/services/support-maintenance',
    badge: 'System Support',
  },
  {
    problem: 'Custom Business Workflows',
    symptom: 'Off-the-shelf software packages fail to match your actual factory floor, dispatch, or field operations.',
    solution: 'Tailored Enterprise Software & Proprietary Portal Development',
    link: '/services/software-development',
    badge: 'Custom Software',
  },
  {
    problem: 'Lack of Internal AI Literacy',
    symptom: 'Leadership and staff want to leverage modern AI tools but lack structured, safe corporate frameworks.',
    solution: 'Corporate AI Education, Prompting Mastery & Team Upskilling',
    link: '/services/ai-education-training',
    badge: 'Corporate Training',
  },
]

const COMMITMENTS = [
  {
    principle: 'Problem-First Operational Diagnostics',
    description: 'We deeply analyse your actual business workflows, manual bottlenecks, and operational leakage before engineering any software.',
    highlight: 'Zero Shelfware Guarantee',
    tag: 'Operational Analysis',
    badge: 'Step 01',
  },
  {
    principle: '100% Code & Intellectual Property Sovereignty',
    description: 'You receive complete source code, database access, and architectural ownership. We never trap growing businesses in proprietary lock-in.',
    highlight: 'Full Client IP Ownership',
    tag: 'Architecture & Trust',
    badge: 'Step 02',
  },
  {
    principle: 'Direct Technical Accountability & Ongoing Support',
    description: 'Work directly with dedicated engineers who understand your domain. Transparent sprints, weekly progress demos, and dependable post-launch maintenance.',
    highlight: 'Direct Engineering Access',
    tag: 'Delivery & Maintenance',
    badge: 'Step 03',
  },
]

export default function Home() {
  const [demoOpen, setDemoOpen] = useState(false)
  const [gameOpen, setGameOpen] = useState(false)
  const [activeCategoryTab, setActiveCategoryTab] = useState('all')

  const featuredServices = SERVICE_CATEGORIES.slice(0, 8)
  const featuredProducts = PRODUCTS.slice(0, 6)
  const featuredIndustries = INDUSTRY_LIST.slice(0, 6)

  return (
    <main className="relative bg-white text-neutral-900 overflow-x-hidden">
      <HeaderClient />

      {/* 1. HERO SECTION */}
      <section className="relative pt-36 pb-16 sm:pt-44 sm:pb-24">
        <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-24 -left-24 h-[440px] w-[440px] rounded-full bg-brand-200 opacity-70 blob" />
          <div className="absolute top-20 -right-20 h-[540px] w-[540px] rounded-full bg-orange-100 opacity-80 blob" style={{ animationDelay: '-4s' }} />
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 h-[320px] w-[620px] rounded-full bg-amber-100 opacity-60 blob" style={{ animationDelay: '-8s' }} />
          <div className="absolute inset-0 grid-pattern opacity-50" />
        </div>

        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-7 text-center lg:text-left">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/90 border border-brand-200 text-xs sm:text-sm text-neutral-700 shadow-soft"
              >
                <span className="h-2 w-2 rounded-full bg-brand-500 animate-pulse" />
                Olive Orange Technologies — Software &amp; Digital Solutions
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.1 }}
                className="font-display text-4xl sm:text-6xl md:text-7xl font-bold mt-6 tracking-tight leading-[1.05]"
              >
                We Analyse Your Business Problems and{' '}
                <span className="relative inline-block">
                  <span className="bg-gradient-to-r from-brand-500 via-orange-500 to-amber-500 bg-clip-text text-transparent">Build the Right Digital Solution</span>
                  <svg className="absolute -bottom-2 left-0 w-full" viewBox="0 0 300 12" fill="none"><path d="M2 8 C 80 2, 220 2, 298 8" stroke="#FF7A00" strokeWidth="3" strokeLinecap="round" /></svg>
                </span>
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.25 }}
                className="text-base sm:text-lg md:text-xl text-neutral-600 mt-6 max-w-2xl mx-auto lg:mx-0 leading-relaxed"
              >
                Olive Orange Technologies analyses business problems and builds digital solutions using AI, workflow automation, custom software, analytics, and digital visibility to streamline operations and drive business growth.
              </motion.p>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.7, delay: 0.4 }}
                className="mt-8 flex flex-wrap items-center justify-center lg:justify-start gap-3"
              >
                <button
                  onClick={() => setDemoOpen(true)}
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-brand-500 text-white font-semibold hover:bg-brand-600 shadow-glow transition"
                >
                  Discuss Your Business Problem <ArrowRight className="h-4 w-4" />
                </button>
                <Link
                  href="/services/ai-solutions-automation"
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-neutral-900 text-white font-semibold hover:bg-black transition"
                >
                  Explore Automation Solutions
                </Link>
                <button
                  onClick={() => setGameOpen(true)}
                  className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-white border border-neutral-200 text-neutral-900 font-semibold hover:border-brand-500 hover:text-brand-600 transition shadow-soft"
                >
                  <Play className="h-4 w-4 text-brand-500" /> Free Business Digital Audit
                </button>
              </motion.div>

              {/* Stat counters */}
              <div className="mt-10 pt-8 border-t border-neutral-200/80 grid grid-cols-2 sm:grid-cols-4 gap-6 text-center sm:text-left">
                <div>
                  <div className="font-display text-3xl font-bold text-neutral-900">
                    <Counter to={12} duration={1.2} />
                  </div>
                  <div className="text-xs text-neutral-500 mt-1 font-medium">Core Capabilities</div>
                </div>
                <div>
                  <div className="font-display text-3xl font-bold text-brand-600">
                    <Counter to={100} suffix="%" duration={1.5} />
                  </div>
                  <div className="text-xs text-neutral-500 mt-1 font-medium">Client Sovereignty</div>
                </div>
                <div>
                  <div className="font-display text-3xl font-bold text-neutral-900">
                    <Counter to={15} suffix="+" duration={1.4} />
                  </div>
                  <div className="text-xs text-neutral-500 mt-1 font-medium">Oli Product Suites</div>
                </div>
                <div>
                  <div className="font-display text-3xl font-bold text-neutral-900">
                    &lt; 2 min
                  </div>
                  <div className="text-xs text-neutral-500 mt-1 font-medium">WhatsApp Response</div>
                </div>
              </div>
            </div>

            {/* OLI Mascot Hero Card */}
            <div className="lg:col-span-5">
              <motion.div
                initial={{ opacity: 0, scale: 0.92 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="relative mx-auto max-w-md"
              >
                <div className="relative rounded-[2.5rem] overflow-hidden bg-gradient-to-br from-brand-100 via-orange-50 to-white p-6 border border-brand-200 shadow-glow">
                  <Image
                    src="/brand/oli-mascot.jpg"
                    alt="OLI - Olive Orange Mascot"
                    width={520}
                    height={520}
                    priority
                    className="w-full h-auto rounded-[2rem] shadow-soft"
                  />
                  <div className="mt-4 p-4 rounded-2xl bg-white/90 backdrop-blur border border-brand-100 text-center">
                    <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-brand-700 bg-brand-50 px-2.5 py-0.5 rounded-full">
                      <Sparkles className="h-3 w-3" /> Meet OLI
                    </div>
                    <p className="text-xs text-neutral-600 mt-1.5 font-medium">
                      Your friendly business software co-pilot. Need a consultation or custom quote? Reach us on WhatsApp anytime!
                    </p>
                  </div>
                </div>

                <div className="hidden md:block absolute -left-8 top-10 float-y">
                  <BadgeIcon icon={Zap} label="Fast Delivery" />
                </div>
                <div className="hidden md:block absolute -right-6 top-32 float-y" style={{ animationDelay: '-1.5s' }}>
                  <BadgeIcon icon={ShieldCheck} label="100% Secure" />
                </div>
                <div className="hidden md:block absolute -right-8 -bottom-2 float-y" style={{ animationDelay: '-2.5s' }}>
                  <BadgeIcon icon={Bot} label="AI Automation" />
                </div>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. LOGO / CAPABILITY MARQUEE */}
      <section className="py-6 border-y border-neutral-100 bg-neutral-50/70 overflow-hidden">
        <div className="container max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between text-xs uppercase tracking-widest text-neutral-400 font-semibold mb-3">
            <span>Specialized Capabilities</span>
            <span>Pragmatic Engineering</span>
          </div>
        </div>
        <div className="relative flex overflow-x-hidden">
          <div className="marquee-track flex items-center gap-8 py-2 whitespace-nowrap text-neutral-700 text-sm font-medium">
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-xs"><Palette className="h-4 w-4 text-brand-500" /> Branding &amp; Creative</span>
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-xs"><Globe2 className="h-4 w-4 text-brand-500" /> Modern Web Engineering</span>
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-xs"><Bot className="h-4 w-4 text-brand-500" /> AI Solutions &amp; Automation</span>
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-xs"><Smartphone className="h-4 w-4 text-brand-500" /> Mobile App Development</span>
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-xs"><LayoutDashboard className="h-4 w-4 text-brand-500" /> Custom Business Software &amp; ERP</span>
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-xs"><BarChart3 className="h-4 w-4 text-brand-500" /> Data Analytics &amp; BI</span>
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-xs"><ShieldCheck className="h-4 w-4 text-brand-500" /> Support &amp; Maintenance</span>
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-xs"><Target className="h-4 w-4 text-brand-500" /> Business Consulting</span>
            {/* Duplicated for smooth infinite scroll */}
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-xs"><Palette className="h-4 w-4 text-brand-500" /> Branding &amp; Creative</span>
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-xs"><Globe2 className="h-4 w-4 text-brand-500" /> Modern Web Engineering</span>
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-xs"><Bot className="h-4 w-4 text-brand-500" /> AI Solutions &amp; Automation</span>
            <span className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-neutral-200 shadow-xs"><Smartphone className="h-4 w-4 text-brand-500" /> Mobile App Development</span>
          </div>
        </div>
      </section>

      {/* 3. BUSINESS PROBLEMS MATRIX (Problem-First Positioning) */}
      <section className="py-20 bg-neutral-50/70 border-b border-neutral-100">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">
              Business Problem Diagnostics
            </div>
            <h2 className="font-display text-3xl sm:text-5xl font-bold mt-3 text-neutral-900">
              Problems We Solve for Growing Businesses
            </h2>
            <p className="text-neutral-600 mt-3 text-base sm:text-lg leading-relaxed">
              Business Problems &rarr; Analysis &rarr; Digital Solution &rarr; Automation &rarr; Better Operations &rarr; Business Growth.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-14">
            {BUSINESS_PROBLEMS.map((bp, idx) => (
              <motion.div
                key={bp.problem}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.04 }}
              >
                <Link
                  href={bp.link}
                  className="group flex flex-col justify-between h-full p-6 rounded-3xl bg-white border border-neutral-200/90 hover:border-brand-500 shadow-soft hover:shadow-glow transition-all card-lift"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-brand-50 text-brand-700 font-bold uppercase tracking-wider">
                        {bp.badge}
                      </span>
                      <ArrowRight className="h-4 w-4 text-neutral-400 group-hover:text-brand-600 group-hover:translate-x-1 transition-all" />
                    </div>

                    <h3 className="font-display font-bold text-lg text-neutral-900 mt-4 group-hover:text-brand-600 transition-colors">
                      {bp.problem}
                    </h3>
                    <p className="text-xs text-neutral-500 mt-2 leading-relaxed">
                      {bp.symptom}
                    </p>
                  </div>

                  <div className="mt-5 pt-3.5 border-t border-neutral-100">
                    <div className="text-[10px] uppercase font-bold text-neutral-400 tracking-wider">Engineered Solution</div>
                    <div className="text-xs font-semibold text-neutral-900 mt-0.5 group-hover:text-brand-600 transition-colors">
                      {bp.solution}
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>

          <div className="mt-12 text-center flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => setDemoOpen(true)}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-neutral-900 hover:bg-black text-white text-xs font-semibold shadow-soft transition"
            >
              Discuss Your Business Problem <ArrowRight className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setGameOpen(true)}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-white border border-neutral-200 text-neutral-800 hover:border-brand-500 text-xs font-semibold shadow-soft transition"
            >
              Get a Business Digital Audit
            </button>
          </div>
        </div>
      </section>

      {/* 4. CORE SERVICES SHOWCASE */}
      <section className="py-20 bg-white">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">
                Our Capabilities
              </div>
              <h2 className="font-display text-3xl sm:text-5xl font-bold mt-3">
                12 Core Digital Services
              </h2>
              <p className="text-neutral-600 mt-2 max-w-2xl text-base sm:text-lg">
                We analyse your business problems and build the right digital solution — end-to-end.
              </p>
            </div>
            <Link
              href="/services"
              className="inline-flex items-center gap-2 text-brand-600 font-semibold hover:text-brand-700 hover:gap-3 transition-all self-start md:self-auto"
            >
              View All 12 Categories <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-12">
            {featuredServices.map((cat, idx) => {
              const IconComponent = SERVICE_ICON_MAP[cat.icon] || Boxes
              return (
                <motion.div
                  key={cat.slug}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.05 }}
                >
                  <Link
                    href={`/services/${cat.slug}`}
                    className="group flex flex-col justify-between h-full rounded-3xl p-6 bg-white border border-neutral-200 hover:border-brand-500 shadow-soft hover:shadow-glow transition-all card-lift"
                  >
                    <div>
                      <div className="h-12 w-12 rounded-2xl bg-gradient-to-br from-brand-50 to-orange-100 text-brand-600 flex items-center justify-center group-hover:scale-105 transition-transform">
                        <IconComponent className="h-6 w-6" />
                      </div>
                      <h3 className="font-display font-bold text-lg text-neutral-900 mt-4 group-hover:text-brand-600 transition-colors">
                        {cat.name}
                      </h3>
                      <p className="text-xs text-neutral-500 mt-2 leading-relaxed">
                        {cat.tagline}
                      </p>
                    </div>

                    <div className="mt-6 pt-4 border-t border-neutral-100 flex items-center justify-between text-xs font-semibold text-brand-600 group-hover:translate-x-1 transition-transform">
                      <span>Explore details</span>
                      <ArrowRight className="h-4 w-4" />
                    </div>
                  </Link>
                </motion.div>
              )
            })}
          </div>
        </div>
      </section>

      {/* 4. FEATURED PRODUCTS SHOWCASE */}
      <section className="py-20 bg-neutral-950 text-white relative overflow-hidden">
        <div className="absolute -top-32 -right-32 h-[500px] w-[500px] rounded-full bg-brand-500/20 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-32 -left-32 h-[500px] w-[500px] rounded-full bg-orange-500/10 blur-3xl pointer-events-none" />

        <div className="container max-w-7xl mx-auto px-4 sm:px-6 relative">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-white/10 text-brand-300 font-semibold uppercase tracking-widest">
                Product Ecosystem
              </div>
              <h2 className="font-display text-3xl sm:text-5xl font-bold mt-3">
                Pre-built Software Suites
              </h2>
              <p className="text-neutral-400 mt-2 max-w-2xl text-base">
                Ready-to-deploy, customized for Indian mid-sized businesses with GST, WhatsApp and multi-branch workflows.
              </p>
            </div>
            <Link
              href="/products"
              className="inline-flex items-center gap-2 text-brand-400 font-semibold hover:text-brand-300 hover:gap-3 transition-all self-start md:self-auto"
            >
              View All 15 Products <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
            {featuredProducts.map((p, idx) => (
              <motion.div
                key={p.slug}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.06 }}
                className="group rounded-3xl bg-neutral-900 border border-neutral-800 hover:border-brand-500/60 p-6 flex flex-col justify-between transition-all"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs px-2.5 py-1 rounded-full bg-brand-500/20 text-brand-400 font-medium">
                      {p.tag}
                    </span>
                    <span className="text-xs text-neutral-400">
                      ₹{p.pricing.offer.toLocaleString('en-IN')}{' '}
                      <span className="line-through text-neutral-600">₹{p.pricing.mrp.toLocaleString('en-IN')}</span>
                    </span>
                  </div>

                  <h3 className="font-display text-xl font-bold mt-4 text-white group-hover:text-brand-400 transition-colors">
                    {p.name}
                  </h3>
                  <p className="text-xs text-neutral-400 mt-2 leading-relaxed line-clamp-2">
                    {p.tagline}
                  </p>

                  <div className="mt-4 space-y-1.5">
                    {p.features.slice(0, 3).map((f, fi) => (
                      <div key={fi} className="flex items-center gap-2 text-xs text-neutral-300">
                        <CheckCircle2 className="h-3.5 w-3.5 text-brand-400 shrink-0" />
                        <span className="truncate">{f}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-4 border-t border-neutral-800 flex items-center justify-between">
                  <Link
                    href={`/products/${p.slug}`}
                    className="text-xs font-semibold text-brand-400 hover:text-white transition flex items-center gap-1"
                  >
                    View Details <ArrowRight className="h-3.5 w-3.5" />
                  </Link>
                  <button
                    onClick={() => setDemoOpen(true)}
                    className="px-3.5 py-1.5 rounded-full bg-white/10 hover:bg-brand-500 hover:text-white text-xs font-semibold transition"
                  >
                    Free Trial
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. INTERACTIVE BUSINESS HEALTH GAME EMBED */}
      <section className="py-20 bg-gradient-to-b from-brand-50/40 via-white to-orange-50/30">
        <div className="container max-w-6xl mx-auto px-4 sm:px-6">
          <div className="rounded-[2.5rem] bg-white border border-brand-200 shadow-glow p-8 sm:p-12 relative overflow-hidden">
            <div className="grid lg:grid-cols-12 gap-8 items-center">
              <div className="lg:col-span-7">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100 text-brand-700 text-xs font-semibold uppercase tracking-widest">
                  <Gamepad2 className="h-3.5 w-3.5" /> 60-Second Assessment
                </div>
                <h2 className="font-display text-3xl sm:text-4xl font-bold mt-4">
                  Take the Business Health Challenge
                </h2>
                <p className="text-neutral-600 mt-3 text-base leading-relaxed">
                  Are slow follow-ups, manual Excel sheets, or disconnected systems holding back your business? Answer 8 simple questions to get your instant rule-based AI Health Score (0–100) and actionable recommendations.
                </p>

                <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 gap-4">
                  <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-100">
                    <div className="text-xs text-neutral-500">Duration</div>
                    <div className="font-display font-bold text-sm text-neutral-900 mt-0.5">Under 60 sec</div>
                  </div>
                  <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-100">
                    <div className="text-xs text-neutral-500">Output</div>
                    <div className="font-display font-bold text-sm text-brand-600 mt-0.5">Health Score 0-100</div>
                  </div>
                  <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-100">
                    <div className="text-xs text-neutral-500">Cost</div>
                    <div className="font-display font-bold text-sm text-emerald-600 mt-0.5">100% Free</div>
                  </div>
                </div>

                <div className="mt-8 flex flex-wrap gap-3">
                  <button
                    onClick={() => setGameOpen(true)}
                    className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-brand-500 text-white font-semibold hover:bg-brand-600 shadow-glow transition"
                  >
                    <Play className="h-4 w-4" /> Start Health Check
                  </button>
                  <Link
                    href="/game"
                    className="inline-flex items-center gap-2 px-6 py-3.5 rounded-full bg-white border border-neutral-200 text-neutral-800 font-semibold hover:border-brand-500 transition"
                  >
                    View Game Page
                  </Link>
                </div>
              </div>

              <div className="lg:col-span-5 flex justify-center">
                <div className="relative p-6 rounded-3xl bg-gradient-to-br from-brand-100 to-orange-50 border border-brand-200 max-w-sm w-full text-center shadow-soft">
                  <div className="h-16 w-16 mx-auto rounded-full bg-brand-500 text-white flex items-center justify-center shadow-glow mb-3">
                    <Gamepad2 className="h-8 w-8" />
                  </div>
                  <div className="font-display font-bold text-xl text-neutral-900">Interactive Quiz</div>
                  <p className="text-xs text-neutral-500 mt-1">Diagnose follow-up friction, operational silos &amp; missed revenue opportunities.</p>
                  <div className="mt-4 p-3 rounded-2xl bg-white border border-brand-100 text-left space-y-2 text-xs">
                    <div className="flex items-center gap-2 text-neutral-700">
                      <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0" />
                      <span>Instant verdict &amp; priority fixes</span>
                    </div>
                    <div className="flex items-center gap-2 text-neutral-700">
                      <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0" />
                      <span>Estimated revenue lift potential</span>
                    </div>
                    <div className="flex items-center gap-2 text-neutral-700">
                      <CheckCircle2 className="h-4 w-4 text-green-500 shrink-0" />
                      <span>Confidential diagnostic report</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. OUR 5-STEP PROCESS */}
      <section className="py-20 bg-white">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="max-w-3xl mx-auto text-center">
            <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">
              Execution Methodology
            </div>
            <h2 className="font-display text-3xl sm:text-5xl font-bold mt-3">
              How We Solve Business Problems
            </h2>
            <p className="text-neutral-600 mt-3 text-base sm:text-lg">
              No generic off-the-shelf templates. A systematic discovery and delivery roadmap.
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6 mt-14">
            {PROCESS_STEPS.map((p, idx) => (
              <div
                key={p.step}
                className="relative rounded-3xl p-6 bg-white border border-neutral-200 shadow-soft hover:border-brand-500 transition-all card-lift flex flex-col justify-between"
              >
                <div>
                  <span className="font-display text-4xl font-extrabold text-brand-200">
                    {p.step}
                  </span>
                  <h3 className="font-display font-bold text-lg text-neutral-900 mt-3">
                    {p.title}
                  </h3>
                  <p className="text-xs text-neutral-500 mt-2 leading-relaxed">
                    {p.desc}
                  </p>
                </div>
                <div className="mt-4 pt-3 border-t border-neutral-100 flex items-center gap-1.5 text-xs font-semibold text-brand-600">
                  <CheckCircle2 className="h-3.5 w-3.5" /> Milestone verified
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. INDUSTRIES WE SERVE */}
      <section className="py-20 bg-neutral-50">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">
                Tailored Systems
              </div>
              <h2 className="font-display text-3xl sm:text-5xl font-bold mt-3">
                Industries We Empower
              </h2>
              <p className="text-neutral-600 mt-2 max-w-2xl text-base">
                Deep vertical workflows built for the real day-to-day operations of Indian businesses.
              </p>
            </div>
            <Link
              href="/industries"
              className="inline-flex items-center gap-2 text-brand-600 font-semibold hover:text-brand-700 hover:gap-3 transition-all self-start md:self-auto"
            >
              Explore All Industries <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-12">
            {featuredIndustries.map((ind, idx) => (
              <motion.div
                key={ind.slug}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.05 }}
              >
                <Link
                  href={`/industries/${ind.slug}`}
                  className="group block rounded-3xl p-6 bg-white border border-neutral-200 hover:border-brand-500 shadow-soft transition-all card-lift"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-display font-bold text-xl text-neutral-900 group-hover:text-brand-600 transition-colors">
                      {ind.name}
                    </span>
                    <ArrowRight className="h-4 w-4 text-neutral-400 group-hover:text-brand-600 group-hover:translate-x-1 transition-all" />
                  </div>
                  <p className="text-xs text-neutral-500 mt-2 leading-relaxed line-clamp-2">
                    {ind.tagline}
                  </p>
                  <div className="mt-4 pt-4 border-t border-neutral-100 flex flex-wrap gap-2">
                    {ind.metrics?.slice(0, 2).map((m, mi) => (
                      <span key={mi} className="text-[11px] px-2.5 py-1 rounded-full bg-neutral-100 text-neutral-700 font-medium">
                        {m.v}
                      </span>
                    ))}
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 8. CLIENT PARTNERSHIP COMMITMENTS */}
      <section className="py-20 bg-white">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="max-w-2xl mx-auto text-center">
            <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">
              Our Core Commitments
            </div>
            <h2 className="font-display text-3xl sm:text-5xl font-bold mt-3">
              Built on Problem-First Principles
            </h2>
            <p className="text-neutral-600 mt-3 text-base">
              Every Problem Has A Solution. We analyse your business problems and build the right digital solution.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 mt-12">
            {COMMITMENTS.map((c) => (
              <div
                key={c.principle}
                className="rounded-3xl p-6 bg-white border border-neutral-200 shadow-soft flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="inline-block text-xs px-2.5 py-1 rounded-full bg-brand-50 text-brand-700 font-semibold">
                      {c.tag}
                    </span>
                    <span className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider">
                      {c.badge}
                    </span>
                  </div>
                  <h3 className="font-display font-bold text-lg text-neutral-900 mb-2">
                    {c.principle}
                  </h3>
                  <p className="text-neutral-600 text-sm leading-relaxed">
                    {c.description}
                  </p>
                </div>
                <div className="mt-6 pt-4 border-t border-neutral-100">
                  <div className="font-display font-semibold text-xs text-brand-600 flex items-center gap-1.5">
                    <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" /> {c.highlight}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 9. WHY OLIVE ORANGE PILLARS */}
      <section className="py-16 bg-gradient-to-b from-neutral-900 to-neutral-950 text-white">
        <div className="container max-w-7xl mx-auto px-4 sm:px-6">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 rounded-3xl bg-neutral-900/80 border border-neutral-800">
              <div className="h-10 w-10 rounded-xl bg-brand-500/20 text-brand-400 flex items-center justify-center mb-4">
                <ShieldCheck className="h-5 w-5" />
              </div>
              <h3 className="font-display font-bold text-lg">100% Code Sovereignty</h3>
              <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                You own your code, databases, customer lists, and schemas completely. No vendor lock-in.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-neutral-900/80 border border-neutral-800">
              <div className="h-10 w-10 rounded-xl bg-brand-500/20 text-brand-400 flex items-center justify-center mb-4">
                <Target className="h-5 w-5" />
              </div>
              <h3 className="font-display font-bold text-lg">Problem-First Discovery</h3>
              <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                We analyse your business problems and build the right digital solution. Every Problem Has A Solution.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-neutral-900/80 border border-neutral-800">
              <div className="h-10 w-10 rounded-xl bg-brand-500/20 text-brand-400 flex items-center justify-center mb-4">
                <Zap className="h-5 w-5" />
              </div>
              <h3 className="font-display font-bold text-lg">Modern Engineering</h3>
              <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                Next.js, Node.js, AI automation, secure cloud storage, and responsive UI built for rapid loading.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-neutral-900/80 border border-neutral-800">
              <div className="h-10 w-10 rounded-xl bg-brand-500/20 text-brand-400 flex items-center justify-center mb-4">
                <Phone className="h-5 w-5" />
              </div>
              <h3 className="font-display font-bold text-lg">Direct WhatsApp Reach</h3>
              <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
                Direct phone and WhatsApp communication (+91 96246 89335) with senior engineers and architects.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 10. FOOTER & MODALS */}
      <FooterCTA />
      <DemoModal open={demoOpen} onClose={() => setDemoOpen(false)} />
      <GameChallenge open={gameOpen} onClose={() => setGameOpen(false)} />
    </main>
  )
}

function BadgeIcon({ icon: Icon, label }) {
  return (
    <div className="flex items-center gap-2 px-3 py-2 rounded-2xl bg-white border border-brand-100 shadow-soft">
      <div className="h-8 w-8 rounded-xl bg-brand-100 text-brand-600 flex items-center justify-center">
        <Icon className="h-4 w-4" />
      </div>
      <span className="text-sm font-semibold">{label}</span>
    </div>
  )
}

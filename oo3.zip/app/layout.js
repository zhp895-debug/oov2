import { Inter, Poppins } from 'next/font/google'
import { Toaster } from 'sonner'
import './globals.css'
import { getOrganizationSchema, getWebSiteSchema } from '@/lib/seo'

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
  display: 'swap',
})

const poppins = Poppins({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800', '900'],
  variable: '--font-poppins',
  display: 'swap',
})

export const metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://oliveorangetech.in'),
  title: {
    default: 'Olive Orange Technologies | Business Solutions, AI & Digital Transformation',
    template: '%s | Olive Orange Technologies',
  },
  description:
    'Olive Orange Technologies analyses business problems and builds digital solutions using AI, automation, software, analytics and digital technologies to improve operations and business growth.',
  keywords: [
    'Olive Orange Technologies',
    'business solutions',
    'business automation',
    'business process automation',
    'AI automation',
    'AI solutions for business',
    'digital transformation',
    'digital transformation for SMEs',
    'digital transformation for MSMEs',
    'business technology solutions',
    'custom business software',
    'workflow automation',
    'CRM automation',
    'lead automation',
    'business analytics',
    'business intelligence',
    'digital visibility',
    'SEO',
    'AI visibility',
    'GEO',
    'AEO',
    'software development',
    'website development',
    'mobile app development',
    'business consulting',
    'AI training for businesses',
    'business automation company India',
    'business solutions Gujarat',
  ],
  authors: [{ name: 'Olive Orange Technologies', url: 'https://oliveorangetech.in' }],
  creator: 'Olive Orange Technologies',
  publisher: 'Olive Orange Technologies',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  alternates: {
    canonical: '/',
  },
  openGraph: {
    type: 'website',
    locale: 'en_IN',
    url: 'https://oliveorangetech.in',
    siteName: 'Olive Orange Technologies',
    title: 'Olive Orange Technologies | Business Solutions, AI & Digital Transformation',
    description:
      'Olive Orange Technologies analyses business problems and builds digital solutions using AI, automation, software, analytics and digital technologies to improve operations and business growth.',
    images: [
      {
        url: '/brand/oo-logo.jpg',
        width: 800,
        height: 800,
        alt: 'Olive Orange Technologies',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Olive Orange Technologies | Business Solutions, AI & Digital Transformation',
    description:
      'Olive Orange Technologies analyses business problems and builds digital solutions using AI, automation, software, analytics and digital technologies to improve operations and business growth.',
    images: ['/brand/oo-logo.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  icons: {
    icon: '/brand/oo-logo.jpg',
    shortcut: '/brand/oo-logo.jpg',
    apple: '/brand/oo-logo.jpg',
  },
}

export default function RootLayout({ children }) {
  const orgSchema = getOrganizationSchema()
  const webSiteSchema = getWebSiteSchema()

  return (
    <html lang="en" className={`${inter.variable} ${poppins.variable}`} suppressHydrationWarning>
      <body className="font-inter antialiased bg-white text-neutral-900 selection:bg-orange-200 selection:text-orange-900" suppressHydrationWarning>
        <script
          id="schema-organization"
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }}
          suppressHydrationWarning
        />
        <script
          id="schema-website"
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(webSiteSchema) }}
          suppressHydrationWarning
        />
        {children}
        <Toaster position="bottom-center" richColors />
      </body>
    </html>
  )
}

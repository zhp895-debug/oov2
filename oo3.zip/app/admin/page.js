import { redirect } from 'next/navigation'
import { getServerSession } from '@/lib/auth'
import AdminCMSClient from '@/components/AdminCMSClient'

export const dynamic = 'force-dynamic'

export const metadata = {
  title: 'Operations & CMS Console — Olive Orange Technologies',
  description: 'Internal operations, inbound leads CRM, blog publisher, and SEO registry for Olive Orange Technologies.',
  robots: {
    index: false,
    follow: false,
  },
}

export default async function AdminPage() {
  const session = await getServerSession()
  return <AdminCMSClient initialUser={session} />
}

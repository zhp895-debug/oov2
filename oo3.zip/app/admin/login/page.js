import { redirect } from 'next/navigation'
import { getServerSession } from '@/lib/auth'
import AdminLoginClient from '@/components/AdminLoginClient'

export const dynamic = 'force-dynamic'

export const metadata = {
  title: 'Sign In — Operations & CMS Console | Olive Orange Technologies',
  description: 'Authorized administrative sign-in portal for Olive Orange Technologies internal console.',
  robots: {
    index: false,
    follow: false,
  },
}

export default async function AdminLoginPage() {
  const session = await getServerSession()

  // If already authenticated, redirect directly to admin dashboard
  if (session) {
    redirect('/admin')
  }

  return <AdminLoginClient />
}

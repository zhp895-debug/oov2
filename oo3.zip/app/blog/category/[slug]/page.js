import { notFound } from 'next/navigation'
import Link from 'next/link'
import { ArrowLeft, Sparkles, Folder } from 'lucide-react'
import { getAllPosts, getCategories } from '@/lib/cms-store'
import BlogIndexClient from '@/components/BlogIndexClient'
import { getBreadcrumbSchema } from '@/lib/seo'
import HeaderClient from '@/components/HeaderClient'
import FooterCTA from '@/components/FooterCTA'

export const dynamic = 'force-dynamic'
export const revalidate = 0

export async function generateMetadata({ params }) {
  const { slug } = await params
  const categories = await getCategories()
  const cat = categories.find((c) => c.slug === slug)
  if (!cat) return { title: 'Category Not Found — Olive Orange Technologies' }

  return {
    title: `${cat.name} Articles & Analysis — Olive Orange Technologies`,
    description: cat.description || `Read engineering guides, case studies and playbooks about ${cat.name}.`,
    alternates: {
      canonical: `https://oliveorangetech.in/blog/category/${cat.slug}`,
    },
    openGraph: {
      title: `${cat.name} — Olive Orange Blog`,
      description: cat.description,
      url: `https://oliveorangetech.in/blog/category/${cat.slug}`,
    },
  }
}

export default async function BlogCategoryPage({ params }) {
  const { slug } = await params
  const categories = await getCategories()
  const cat = categories.find((c) => c.slug === slug)
  if (!cat) notFound()

  // Only published posts in this category
  const posts = await getAllPosts({ includeDrafts: false, category: cat.name })

  const breadcrumbSchema = getBreadcrumbSchema([
    { name: 'Home', url: '/' },
    { name: 'Blog', url: '/blog' },
    { name: cat.name, url: `/blog/category/${cat.slug}` },
  ])

  return (
    <>
      <script
        id="schema-breadcrumb-category"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
        suppressHydrationWarning
      />
      <main className="relative bg-white text-neutral-900 overflow-x-hidden min-h-screen">
        <HeaderClient />

        <section className="relative pt-36 pb-12 sm:pt-44 bg-gradient-to-b from-brand-50/30 to-white">
          <div className="container max-w-5xl mx-auto px-4 text-center">
            <Link
              href="/blog"
              className="inline-flex items-center gap-1.5 text-xs text-neutral-500 hover:text-brand-600 mb-4 transition font-medium"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> Back to all articles
            </Link>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-brand-100 text-brand-700 text-xs font-semibold uppercase tracking-widest block mx-auto w-max mb-3">
              <Folder className="h-3.5 w-3.5" /> Category Archive
            </div>
            <h1 className="font-display text-3xl sm:text-5xl font-bold text-neutral-900 tracking-tight">
              {cat.name}
            </h1>
            <p className="text-neutral-600 text-base sm:text-lg mt-4 max-w-2xl mx-auto leading-relaxed">
              {cat.description || `Practical, factual analysis and engineering insights on ${cat.name}.`}
            </p>
            <div className="mt-4 text-xs text-neutral-500">
              Showing {posts.length} published {posts.length === 1 ? 'article' : 'articles'}
            </div>
          </div>
        </section>

        <section className="pb-24">
          <div className="container max-w-7xl mx-auto px-4">
            {posts.length === 0 ? (
              <div className="p-12 text-center rounded-3xl bg-neutral-50 border border-neutral-200 max-w-xl mx-auto">
                <p className="text-neutral-600 text-sm">No published articles in this category yet.</p>
                <Link
                  href="/blog"
                  className="mt-4 inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-brand-500 text-white text-xs font-semibold"
                >
                  Explore All Articles
                </Link>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {posts.map((post) => (
                  <Link
                    key={post.slug}
                    href={`/blog/${post.slug}`}
                    className="group flex flex-col justify-between rounded-3xl bg-white border border-neutral-200 hover:border-brand-500 shadow-soft transition-all overflow-hidden"
                  >
                    <div>
                      <div className="relative aspect-[16/10] bg-neutral-100 overflow-hidden">
                        <img
                          src={post.featuredImage || post.image}
                          alt={post.imageAltText || post.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                      <div className="p-6">
                        <div className="text-xs text-brand-600 font-semibold mb-2">{post.category}</div>
                        <h2 className="font-display font-bold text-xl text-neutral-900 group-hover:text-brand-600 transition-colors leading-snug">
                          {post.title}
                        </h2>
                        <p className="text-xs text-neutral-600 mt-2 line-clamp-3 leading-relaxed">
                          {post.excerpt}
                        </p>
                      </div>
                    </div>
                    <div className="px-6 pb-6 pt-2 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-500">
                      <span>{post.readMin} min read</span>
                      <span className="font-semibold text-brand-600 flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                        Read Article &rarr;
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </section>

        <FooterCTA />
      </main>
    </>
  )
}

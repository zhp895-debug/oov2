import { notFound } from 'next/navigation'
import { getPostBySlug, getAllPosts } from '@/lib/cms-store'
import { getRelatedPosts } from '@/lib/blog-data'
import BlogArticleClient from '@/components/BlogArticleClient'
import { getArticleSchema, getBreadcrumbSchema, getFaqSchema } from '@/lib/seo'

export const dynamic = 'force-dynamic'
export const revalidate = 0

export async function generateMetadata({ params }) {
  const { slug } = await params
  // Only published posts can be resolved
  const p = await getPostBySlug(slug, { includeDrafts: false })
  if (!p) return { title: 'Article Not Found — Olive Orange Technologies' }

  const title = p.metaTitle || `${p.title} | Olive Orange Technologies`
  const description = p.metaDescription || p.excerpt
  const image = p.ogImage || p.featuredImage || p.image || 'https://images.unsplash.com/photo-1652156752342-c786f1e1d1ce'
  const canonical = p.canonicalUrl || `https://oliveorangetech.in/blog/${p.slug}`

  return {
    title,
    description,
    alternates: {
      canonical,
    },
    openGraph: {
      type: 'article',
      title,
      description,
      url: canonical,
      publishedTime: p.publicationDate || p.createdAt,
      modifiedTime: p.updatedAt || p.publicationDate || p.createdAt,
      authors: [p.author || 'Olive Orange Technologies'],
      tags: p.tags,
      images: [
        {
          url: image,
          width: 1200,
          height: 630,
          alt: p.imageAltText || p.title,
        },
      ],
    },
    twitter: {
      card: 'summary_large_image',
      title,
      description,
      images: [image],
    },
  }
}

export default async function BlogPostPage({ params }) {
  const { slug } = await params
  // Public website ONLY shows published posts. Drafts/unpublished return 404!
  const post = await getPostBySlug(slug, { includeDrafts: false })
  if (!post || post.status !== 'published') {
    notFound()
  }

  const allPublished = await getAllPosts({ includeDrafts: false })
  const related = allPublished.filter((p) => p.slug !== slug).slice(0, 3)

  // Structured schemas
  const articleSchema = getArticleSchema({
    ...post,
    date: post.publicationDate || post.createdAt,
    image: post.featuredImage || post.image,
  })

  const breadcrumbSchema = getBreadcrumbSchema([
    { name: 'Home', url: '/' },
    { name: 'Blog', url: '/blog' },
    { name: post.title, url: `/blog/${post.slug}` },
  ])

  const faqSchema = post.faqs && post.faqs.length > 0
    ? getFaqSchema(post.faqs.map((f) => ({ question: f.q, answer: f.a })))
    : null

  return (
    <>
      {articleSchema && (
        <script
          id="schema-article"
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(articleSchema) }}
          suppressHydrationWarning
        />
      )}
      <script
        id="schema-breadcrumb"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
        suppressHydrationWarning
      />
      {faqSchema && (
        <script
          id="schema-faq"
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
          suppressHydrationWarning
        />
      )}
      <BlogArticleClient post={post} related={related} />
    </>
  )
}

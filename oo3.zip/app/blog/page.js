import BlogIndexClient from '@/components/BlogIndexClient'
import { getAllPosts } from '@/lib/cms-store'
import { getBreadcrumbSchema } from '@/lib/seo'

export const metadata = {
  title: 'Blog & Engineering Insights — Olive Orange Technologies',
  description:
    'Factual, practical analysis on Business Automation, AI Solutions, CRM & ERP Architecture, and Answer Engine Optimization (AEO/GEO) for growing businesses.',
  alternates: {
    canonical: 'https://oliveorangetech.in/blog',
  },
  openGraph: {
    title: 'Blog & Engineering Insights — Olive Orange Technologies',
    description:
      'Factual, practical analysis on Business Automation, AI Solutions, CRM & ERP Architecture, and Answer Engine Optimization (AEO/GEO).',
    url: 'https://oliveorangetech.in/blog',
    type: 'website',
  },
}

export const revalidate = 0 // Always show fresh published CMS content

export default async function BlogIndexPage() {
  // Only published posts appear on the public website
  const publishedPosts = await getAllPosts({ includeDrafts: false })

  const breadcrumbSchema = getBreadcrumbSchema([
    { name: 'Home', url: '/' },
    { name: 'Blog', url: '/blog' },
  ])

  return (
    <>
      <script
        id="schema-breadcrumb-blog"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
        suppressHydrationWarning
      />
      <BlogIndexClient initialPosts={publishedPosts} />
    </>
  )
}

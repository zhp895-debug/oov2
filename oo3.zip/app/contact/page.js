import ContactClient, { CONTACT_FAQS } from '@/components/ContactClient'
import { getFaqSchema, getBreadcrumbSchema } from '@/lib/seo'

export const metadata = {
  title: 'Contact Us — Olive Orange Technologies',
  description:
    'Contact Olive Orange Technologies. Call or WhatsApp us directly at +91 96246 89335, or email oliveorangetechnologies@gmail.com. We analyse your business problems and build the right digital solution.',
  alternates: {
    canonical: '/contact',
  },
  openGraph: {
    title: 'Contact Olive Orange Technologies',
    description:
      'Direct phone, WhatsApp Business (+91 96246 89335), and consultation booking with Olive Orange Technologies.',
    url: 'https://oliveorangetech.in/contact',
  },
}

export default function ContactPage() {
  const faqSchema = getFaqSchema(CONTACT_FAQS)
  const breadcrumbSchema = getBreadcrumbSchema([
    { name: 'Home', url: '/' },
    { name: 'Contact', url: '/contact' },
  ])

  return (
    <>
      <script
        id="schema-breadcrumb-contact"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
        suppressHydrationWarning
      />
      {faqSchema && (
        <script
          id="schema-faq-contact"
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
          suppressHydrationWarning
        />
      )}
      <ContactClient />
    </>
  )
}

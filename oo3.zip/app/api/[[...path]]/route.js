import { NextResponse } from 'next/server'
import { v4 as uuidv4 } from 'uuid'
import {
  getAllPosts,
  getPostBySlug,
  createPost,
  updatePost,
  deletePost,
  togglePostStatus,
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
  getTeamMembers,
  createTeamMember,
  updateTeamMember,
  deleteTeamMember,
  getSettings,
  updateSettings,
  getMediaList,
  addMediaItem,
  deleteMediaItem,
  updateMediaMetadata,
  submitLead,
  getLeads,
  updateLead,
  deleteLead,
} from '@/lib/cms-store'
import {
  authenticateCredentials,
  createSessionToken,
  revokeSessionToken,
  getAuthenticatedUser,
  AUTH_COOKIE_NAME,
} from '@/lib/auth'
import { getDatabase, checkDatabaseHealth, isProductionEnvironment } from '@/lib/mongodb'
import { uploadMediaToGCS, isGCSConfigured } from '@/lib/media-storage'

function json(data, init = {}) {
  return NextResponse.json(data, init)
}

/**
 * Role-Based Access Control (RBAC) helper
 * Strictly validated via cryptographically signed session token.
 * Roles: 'super_admin', 'admin', 'editor'
 */
function getAuthContext(request) {
  const user = getAuthenticatedUser(request)
  if (!user) {
    return {
      isAuthenticated: false,
      user: null,
      role: null,
      isSuperAdmin: false,
      isAdmin: false,
      isEditor: false,
    }
  }

  const role = user.role
  return {
    isAuthenticated: true,
    user,
    role,
    isSuperAdmin: role === 'super_admin',
    isAdmin: role === 'admin' || role === 'super_admin',
    isEditor: role === 'editor' || role === 'admin' || role === 'super_admin',
  }
}

/* -------- Game Challenge scoring engine -------- */
const QUESTION_WEIGHTS = {
  lose_leads: { weight: 14, recommends: ['CRM', 'AI Chatbots'] },
  use_excel: { weight: 12, recommends: ['ERP', 'Inventory Management'] },
  miss_followups: { weight: 12, recommends: ['CRM', 'AI Automation'] },
  customers_wait: { weight: 10, recommends: ['Service Desk', 'AI Chatbots'] },
  sales_struggling: { weight: 12, recommends: ['CRM', 'Real Estate CRM'] },
  manual_invoices: { weight: 10, recommends: ['Billing Software', 'ERP'] },
  no_hr_system: { weight: 8, recommends: ['HRMS'] },
  no_reports: { weight: 12, recommends: ['ERP', 'AI Automation'] },
}

function scoreGame(answers = {}) {
  let painTotal = 0
  let maxPain = 0
  const recs = new Set()

  for (const [key, meta] of Object.entries(QUESTION_WEIGHTS)) {
    maxPain += meta.weight
    const val = Number(answers[key] || 0)
    if (val > 0) {
      painTotal += (val / 10) * meta.weight
      if (val >= 6) {
        meta.recommends.forEach((r) => recs.add(r))
      }
    }
  }

  if (maxPain === 0) maxPain = 1
  const healthPct = Math.max(6, Math.round(100 - (painTotal / maxPain) * 100))
  const health = Math.min(100, healthPct)

  let verdict = 'Critically Fragmented Operations'
  if (health >= 80) {
    verdict = 'Highly Automated & Stable Operations'
  } else if (health >= 55) {
    verdict = 'Partially Automated with Bottlenecks'
  } else if (health >= 35) {
    verdict = 'Significant Operational Leakage & Disjointed Tools'
  }

  const priorityRecommendations = recs.size > 0
    ? Array.from(recs).slice(0, 4)
    : ['Custom Operational ERP', 'WhatsApp & CRM Automation']

  const growthGap = 100 - health
  return {
    health,
    growthGap,
    verdict,
    recommendations: priorityRecommendations,
  }
}

async function handle(request, ctx) {
  const params = await ctx.params
  const seg = (params?.path || []).join('/')
  const method = request.method
  const url = new URL(request.url)
  const auth = getAuthContext(request)

  try {
    // 1. Health Check (Public - production safe, no secret leakage)
    if (seg === '' || seg === 'health') {
      const dbHealth = await checkDatabaseHealth()
      const isHealthy = !isProductionEnvironment() || dbHealth.connected
      const httpStatus = isHealthy ? 200 : 503

      return json(
        {
          ok: isHealthy,
          service: 'olive-orange-api',
          status: isHealthy ? 'healthy' : 'degraded',
          environment: process.env.NODE_ENV || 'development',
          database: {
            configured: dbHealth.configured,
            connected: dbHealth.connected,
            status: dbHealth.status,
            mode: dbHealth.mode,
          },
          mediaStorage: {
            provider: isGCSConfigured() ? 'google_cloud_storage' : 'external_urls',
            configured: isGCSConfigured(),
          },
          ts: Date.now(),
        },
        { status: httpStatus }
      )
    }

    // ==================== AUTHENTICATION API ====================
    // POST /api/auth/login (Public)
    if (seg === 'auth/login' && method === 'POST') {
      const body = await request.json().catch(() => ({}))
      const { email, password } = body
      if (!email || !password || typeof email !== 'string' || typeof password !== 'string') {
        return json({ ok: false, error: 'Email and password are required' }, { status: 400 })
      }

      const user = await authenticateCredentials(email, password)
      if (!user) {
        return json({ ok: false, error: 'Invalid email or password' }, { status: 401 })
      }

      const token = createSessionToken(user)
      const res = json({
        ok: true,
        message: 'Signed in successfully',
        token,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
        },
      })

      const isHttps =
        request.url.startsWith('https:') ||
        request.headers.get('x-forwarded-proto') === 'https' ||
        request.headers.get('x-forwarded-ssl') === 'on' ||
        Boolean(request.headers.get('host')?.includes('.run.app')) ||
        process.env.NODE_ENV === 'production'

      res.cookies.set(AUTH_COOKIE_NAME, token, {
        httpOnly: true,
        secure: isHttps,
        sameSite: isHttps ? 'none' : 'lax',
        path: '/',
        maxAge: 24 * 60 * 60, // 24 hours
        partitioned: isHttps,
      })

      return res
    }

    // POST /api/auth/logout (Protected / Session clearing)
    if (seg === 'auth/logout' && method === 'POST') {
      const bearerToken = request.headers.get('authorization')?.startsWith('Bearer ')
        ? request.headers.get('authorization').substring(7).trim()
        : null
      const cookieToken = request.cookies.get(AUTH_COOKIE_NAME)?.value

      if (bearerToken) {
        await revokeSessionToken(bearerToken)
      }
      if (cookieToken) {
        await revokeSessionToken(cookieToken)
      }

      const isHttps =
        request.url.startsWith('https:') ||
        request.headers.get('x-forwarded-proto') === 'https' ||
        request.headers.get('x-forwarded-ssl') === 'on' ||
        Boolean(request.headers.get('host')?.includes('.run.app')) ||
        process.env.NODE_ENV === 'production'

      const res = json({ ok: true, message: 'Logged out successfully' })
      res.cookies.set(AUTH_COOKIE_NAME, '', {
        httpOnly: true,
        secure: isHttps,
        sameSite: isHttps ? 'none' : 'lax',
        path: '/',
        maxAge: 0,
        expires: new Date(0),
        partitioned: isHttps,
      })
      return res
    }

    // GET /api/auth/me (Protected - current authenticated user session)
    if (seg === 'auth/me' && method === 'GET') {
      if (!auth.isAuthenticated || !auth.user) {
        return json({ ok: false, authenticated: false, error: 'Unauthorized: No active session' }, { status: 401 })
      }
      return json({
        ok: true,
        authenticated: true,
        user: {
          id: auth.user.id,
          email: auth.user.email,
          name: auth.user.name,
          role: auth.user.role,
        },
      })
    }

    // ==================== ADMIN STATS & DASHBOARD API (PROTECTED) ====================
    // GET /api/stats, /api/admin/dashboard, /api/admin/stats - Requires authenticated session
    if ((seg === 'stats' || seg === 'admin/dashboard' || seg === 'admin/stats') && method === 'GET') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required to view dashboard' }, { status: 401 })
      }

      const allPosts = await getAllPosts({ includeDrafts: true })
      const publishedPosts = allPosts.filter((p) => p.status === 'published').length
      const draftPosts = allPosts.filter((p) => p.status === 'draft').length
      const team = await getTeamMembers()
      const media = await getMediaList()
      const leads = await getLeads({ limit: 100 })

      const totalLeads = leads.length
      const demoRequests = leads.filter((l) => l.type === 'demo_request').length
      const contactInquiries = leads.filter((l) => l.type === 'contact').length
      const newLeads = leads.filter((l) => l.status === 'new' || !l.status).length

      return json({
        ok: true,
        service: 'olive-orange-dashboard',
        user: {
          id: auth.user.id,
          email: auth.user.email,
          name: auth.user.name,
          role: auth.user.role,
        },
        stats: {
          totalLeads,
          demoRequests,
          contactInquiries,
          newLeads,
          totalPosts: allPosts.length,
          publishedPosts,
          draftPosts,
          teamCount: team.length,
          mediaCount: media.length,
          systemStatus: 'Operational',
          activeCapabilities: 12,
        },
        recentLeads: leads.slice(0, 5),
        recentPosts: allPosts.slice(0, 5),
      })
    }

    // ==================== BLOG POSTS API (MODULE 1 & 7) ====================
    // GET /api/posts - Public list (published only) or CMS list (requires editor/admin/super_admin)
    if (seg === 'posts' && method === 'GET') {
      const includeDrafts = url.searchParams.get('includeDrafts') === 'true'
      const category = url.searchParams.get('category') || ''
      const search = url.searchParams.get('search') || ''
      const slug = url.searchParams.get('slug')

      if (slug) {
        if (includeDrafts) {
          if (!auth.isAuthenticated) {
            return json({ ok: false, error: 'Unauthorized: Authentication required to view draft articles' }, { status: 401 })
          }
          if (!auth.isEditor) {
            return json({ ok: false, error: 'Forbidden: Insufficient permissions to view draft articles' }, { status: 403 })
          }
        }
        const post = await getPostBySlug(slug, { includeDrafts: includeDrafts && auth.isEditor })
        if (!post) return json({ ok: false, error: 'Article not found' }, { status: 404 })
        return json({ ok: true, post })
      }

      // If drafts requested, enforce authenticated editor/admin session
      if (includeDrafts) {
        if (!auth.isAuthenticated) {
          return json({ ok: false, error: 'Unauthorized: Authentication required to view draft articles' }, { status: 401 })
        }
        if (!auth.isEditor) {
          return json({ ok: false, error: 'Forbidden: Insufficient permissions to view draft articles' }, { status: 403 })
        }
      }

      const posts = await getAllPosts({ includeDrafts: includeDrafts && auth.isEditor, category, search })
      return json({ ok: true, posts, total: posts.length })
    }

    // POST /api/posts - Create blog post (Editor, Admin, Super Admin)
    if (seg === 'posts' && method === 'POST') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isEditor) {
        return json({ ok: false, error: 'Forbidden: Insufficient permissions to create articles' }, { status: 403 })
      }
      const body = await request.json().catch(() => ({}))
      try {
        const post = await createPost(body)
        return json({ ok: true, post, message: 'Article created successfully' }, { status: 201 })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // PUT /api/posts - Update blog post (Editor, Admin, Super Admin)
    if (seg === 'posts' && method === 'PUT') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isEditor) {
        return json({ ok: false, error: 'Forbidden: Insufficient permissions to edit articles' }, { status: 403 })
      }
      const body = await request.json().catch(() => ({}))
      const slug = body.targetSlug || body.slug || url.searchParams.get('slug')
      if (!slug) return json({ ok: false, error: 'Target article slug is required' }, { status: 400 })

      try {
        const updated = await updatePost(slug, body)
        return json({ ok: true, post: updated, message: 'Article updated successfully' })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // PATCH /api/posts - Toggle Publish / Unpublish (Editor, Admin, Super Admin)
    if (seg === 'posts' && method === 'PATCH') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isEditor) {
        return json({ ok: false, error: 'Forbidden: Insufficient permissions to publish/unpublish' }, { status: 403 })
      }
      const body = await request.json().catch(() => ({}))
      const slug = body.slug || url.searchParams.get('slug')
      if (!slug) return json({ ok: false, error: 'Article slug is required' }, { status: 400 })

      try {
        const post = await togglePostStatus(slug)
        return json({ ok: true, post, message: `Article status changed to "${post.status}"` })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // DELETE /api/posts - Delete blog post (Editor, Admin, Super Admin)
    if (seg === 'posts' && method === 'DELETE') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isEditor) {
        return json({ ok: false, error: 'Forbidden: Insufficient permissions to delete articles' }, { status: 403 })
      }
      const slug = url.searchParams.get('slug')
      if (!slug) return json({ ok: false, error: 'Article slug is required' }, { status: 400 })

      try {
        const deleted = await deletePost(slug)
        return json({ ok: true, message: `Article "${deleted.title}" deleted successfully`, slug })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // ==================== BLOG CATEGORIES API (MODULE 2) ====================
    // GET /api/categories - Public taxonomy
    if (seg === 'categories' && method === 'GET') {
      const categories = await getCategories()
      return json({ ok: true, categories })
    }

    // POST /api/categories (Editor, Admin, Super Admin)
    if (seg === 'categories' && method === 'POST') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isEditor) {
        return json({ ok: false, error: 'Forbidden: Insufficient permissions to create categories' }, { status: 403 })
      }
      const body = await request.json().catch(() => ({}))
      try {
        const category = await createCategory(body)
        return json({ ok: true, category, message: 'Category created' }, { status: 201 })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // PUT /api/categories (Editor, Admin, Super Admin)
    if (seg === 'categories' && method === 'PUT') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isEditor) {
        return json({ ok: false, error: 'Forbidden: Insufficient permissions to edit categories' }, { status: 403 })
      }
      const body = await request.json().catch(() => ({}))
      const slug = body.targetSlug || body.slug || url.searchParams.get('slug')
      if (!slug) return json({ ok: false, error: 'Category slug is required' }, { status: 400 })

      try {
        const updated = await updateCategory(slug, body)
        return json({ ok: true, category: updated, message: 'Category updated' })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // DELETE /api/categories (Editor, Admin, Super Admin)
    if (seg === 'categories' && method === 'DELETE') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isEditor) {
        return json({ ok: false, error: 'Forbidden: Insufficient permissions to delete categories' }, { status: 403 })
      }
      const slug = url.searchParams.get('slug')
      if (!slug) return json({ ok: false, error: 'Category slug is required' }, { status: 400 })

      try {
        const deleted = await deleteCategory(slug)
        return json({ ok: true, message: `Category "${deleted.name}" deleted` })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // ==================== TEAM CMS API (MODULE 3) ====================
    // GET /api/team - Team Management & Public Listing API
    if (seg === 'team' && method === 'GET') {
      const showAll = url.searchParams.get('all') === 'true' && auth.isAuthenticated && auth.isAdmin
      const members = await getTeamMembers({ onlyActive: !showAll })
      return json({ ok: true, members })
    }

    // POST /api/team (Admin, Super Admin only — Editor forbidden)
    if (seg === 'team' && method === 'POST') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isAdmin) {
        return json({ ok: false, error: 'Forbidden: Editors cannot modify team management' }, { status: 403 })
      }
      const body = await request.json().catch(() => ({}))
      try {
        const member = await createTeamMember(body)
        return json({ ok: true, member, message: 'Team member added' }, { status: 201 })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // PUT /api/team (Admin, Super Admin only)
    if (seg === 'team' && method === 'PUT') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isAdmin) {
        return json({ ok: false, error: 'Forbidden: Editors cannot modify team management' }, { status: 403 })
      }
      const body = await request.json().catch(() => ({}))
      const id = body.id || url.searchParams.get('id')
      if (!id) return json({ ok: false, error: 'Team member ID is required' }, { status: 400 })

      try {
        const updated = await updateTeamMember(id, body)
        return json({ ok: true, member: updated, message: 'Team member updated' })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // DELETE /api/team (Admin, Super Admin only)
    if (seg === 'team' && method === 'DELETE') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isAdmin) {
        return json({ ok: false, error: 'Forbidden: Editors cannot modify team management' }, { status: 403 })
      }
      const id = url.searchParams.get('id')
      if (!id) return json({ ok: false, error: 'Team member ID is required' }, { status: 400 })

      try {
        const deleted = await deleteTeamMember(id)
        return json({ ok: true, message: `Team member "${deleted.name}" deleted` })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // ==================== WEBSITE SETTINGS API (MODULE 4) ====================
    // GET /api/settings - Public safe settings + full admin settings
    if (seg === 'settings' && method === 'GET') {
      const settings = await getSettings()
      return json({ ok: true, settings })
    }

    // POST / PUT /api/settings - Super Admin & Admin (Editor forbidden)
    if (seg === 'settings' && (method === 'POST' || method === 'PUT')) {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isAdmin) {
        return json({ ok: false, error: 'Forbidden: Admin access required to modify settings' }, { status: 403 })
      }
      const body = await request.json().catch(() => ({}))
      const updated = await updateSettings(body)
      return json({ ok: true, settings: updated, message: 'Settings updated successfully' })
    }

    // ==================== MEDIA LIBRARY API (MODULE 5) ====================
    // GET /api/media - Protected Media Library listing
    if (seg === 'media' && method === 'GET') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required to access media library' }, { status: 401 })
      }
      const media = await getMediaList()
      return json({
        ok: true,
        media,
        storageArchitectureNote: isGCSConfigured()
          ? 'Google Cloud Storage (GCS) is configured as the persistent binary media store.'
          : 'Persistent MongoDB stores media metadata. For binary uploads, configure GCS_BUCKET_NAME.',
      })
    }

    // POST /api/media (Editor, Admin, Super Admin) - Supports both JSON metadata & multipart GCS uploads
    if (seg === 'media' && method === 'POST') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isEditor) {
        return json({ ok: false, error: 'Forbidden: Insufficient permissions to manage media' }, { status: 403 })
      }

      const contentType = request.headers.get('content-type') || ''
      if (contentType.includes('multipart/form-data')) {
        // Binary file upload to Google Cloud Storage
        try {
          const formData = await request.formData()
          const file = formData.get('file')
          if (!file || typeof file === 'string') {
            return json({ ok: false, error: 'File is required' }, { status: 400 })
          }

          const buffer = Buffer.from(await file.arrayBuffer())
          const altText = (formData.get('altText') || file.name || '').toString()

          const gcsResult = await uploadMediaToGCS({
            buffer,
            fileName: file.name,
            mimeType: file.type || 'image/jpeg',
            altText,
          })

          const item = await addMediaItem(gcsResult)
          return json({ ok: true, item, message: 'Media asset uploaded to GCS successfully' }, { status: 201 })
        } catch (err) {
          return json({ ok: false, error: err.message }, { status: 400 })
        }
      }

      // JSON metadata registration (External CDN / URL)
      const body = await request.json().catch(() => ({}))
      try {
        const item = await addMediaItem(body)
        return json({ ok: true, item, message: 'Media asset added' }, { status: 201 })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // PATCH /api/media (Editor, Admin, Super Admin)
    if (seg === 'media' && method === 'PATCH') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isEditor) {
        return json({ ok: false, error: 'Forbidden: Insufficient permissions to manage media' }, { status: 403 })
      }
      const body = await request.json().catch(() => ({}))
      const id = body.id || url.searchParams.get('id')
      if (!id) return json({ ok: false, error: 'Media ID required' }, { status: 400 })

      try {
        const item = await updateMediaMetadata(id, body)
        return json({ ok: true, item, message: 'Media metadata updated' })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // DELETE /api/media (Editor, Admin, Super Admin)
    if (seg === 'media' && method === 'DELETE') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isEditor) {
        return json({ ok: false, error: 'Forbidden: Insufficient permissions to delete media' }, { status: 403 })
      }
      const id = url.searchParams.get('id')
      if (!id) return json({ ok: false, error: 'Media ID required' }, { status: 400 })

      try {
        await deleteMediaItem(id)
        return json({ ok: true, message: 'Media asset deleted' })
      } catch (err) {
        return json({ ok: false, error: err.message }, { status: 400 })
      }
    }

    // ==================== PUBLIC LEADS CRM & GAME SCORING ====================
    // POST /api/game/score (Public game calculation and inbound lead submission)
    if (seg === 'game/score' && method === 'POST') {
      const body = await request.json().catch(() => ({}))
      const answers = body.answers || {}
      const lead = body.lead || {}
      const result = scoreGame(answers)
      const doc = {
        id: uuidv4(),
        type: 'game_assessment',
        name: lead.name || 'Assessment User',
        email: lead.email || '',
        phone: lead.phone || '',
        company: lead.company || '',
        service: `Health Assessment (${result.verdict} - Score: ${result.health})`,
        answers,
        result,
        status: 'new',
        createdAt: new Date().toISOString(),
      }

      await submitLead(doc)
      return json({ ok: true, id: doc.id, result })
    }

    // POST /api/demo (Public demo request form)
    if (seg === 'demo' && method === 'POST') {
      const body = await request.json().catch(() => ({}))

      // Honeypot spam check
      if (body.website_url || body.honeypot || body.fax) {
        return json({ ok: true, spam: true, message: 'Demo request received' })
      }

      const name = (body.name || '').trim()
      const email = (body.email || '').trim()
      const phone = (body.phone || '').trim()
      const company = (body.company || '').trim()
      const message = (body.message || body.notes || '').trim()

      if (!name || (!email && !phone)) {
        return json({ ok: false, error: 'Name and either email or phone number are required' }, { status: 400 })
      }

      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return json({ ok: false, error: 'Please enter a valid email address' }, { status: 400 })
      }

      const doc = {
        id: uuidv4(),
        type: 'demo_request',
        status: 'new',
        name,
        email,
        phone,
        company,
        message,
        source: body.source || 'website_demo_modal',
        createdAt: new Date().toISOString(),
      }

      await submitLead(doc)
      return json({ ok: true, id: doc.id, message: 'Demo request received successfully' })
    }

    // POST /api/contact (Public contact inquiry form)
    if (seg === 'contact' && method === 'POST') {
      const body = await request.json().catch(() => ({}))

      // Honeypot spam check
      if (body.website_url || body.honeypot || body.fax) {
        return json({ ok: true, spam: true, message: 'Inquiry received' })
      }

      const name = (body.name || '').trim()
      const email = (body.email || '').trim()
      const phone = (body.phone || '').trim()
      const company = (body.company || '').trim()
      const message = (body.message || '').trim()

      if (!name || (!email && !phone)) {
        return json({ ok: false, error: 'Name and at least one contact method (email or phone) are required' }, { status: 400 })
      }

      if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return json({ ok: false, error: 'Please enter a valid email address' }, { status: 400 })
      }

      const doc = {
        id: uuidv4(),
        type: body.type || 'contact',
        status: 'new',
        name,
        email,
        phone,
        company,
        message,
        source: body.source || 'website_contact_form',
        createdAt: new Date().toISOString(),
      }

      await submitLead(doc)
      return json({ ok: true, id: doc.id, message: 'Inquiry submitted successfully' })
    }

    // ==================== PROTECTED LEADS CRM API ====================
    // GET /api/leads - Admin and Super Admin only (Editor forbidden, Public forbidden)
    if (seg === 'leads' && method === 'GET') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required to access Leads CRM' }, { status: 401 })
      }
      if (!auth.isAdmin) {
        return json({ ok: false, error: 'Forbidden: Editors do not have access to Leads CRM' }, { status: 403 })
      }

      const items = await getLeads({ limit: 100 })
      return json({ ok: true, items })
    }

    // PATCH /api/leads - Update lead status (Admin and Super Admin only)
    if (seg === 'leads' && (method === 'PATCH' || method === 'POST')) {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isAdmin) {
        return json({ ok: false, error: 'Forbidden: Editors cannot modify leads' }, { status: 403 })
      }
      const body = await request.json().catch(() => ({}))
      const { id, status, notes } = body
      if (!id) return json({ ok: false, error: 'Lead id is required' }, { status: 400 })

      await updateLead(id, { status, notes })
      return json({ ok: true, message: 'Lead updated successfully' })
    }

    // DELETE /api/leads (Admin and Super Admin only)
    if (seg === 'leads' && method === 'DELETE') {
      if (!auth.isAuthenticated) {
        return json({ ok: false, error: 'Unauthorized: Authentication required' }, { status: 401 })
      }
      if (!auth.isAdmin) {
        return json({ ok: false, error: 'Forbidden: Editors cannot delete leads' }, { status: 403 })
      }
      const id = url.searchParams.get('id')
      if (!id) return json({ ok: false, error: 'id required' }, { status: 400 })

      await deleteLead(id)
      return json({ ok: true, message: 'Lead deleted successfully' })
    }

    return json({ ok: false, error: 'Not found', path: seg }, { status: 404 })
  } catch (err) {
    console.error(`[API Error in ${method} /api/${seg}]`, err)
    return json({ ok: false, error: err.message }, { status: 500 })
  }
}

export const GET = handle
export const POST = handle
export const PUT = handle
export const DELETE = handle
export const PATCH = handle

import AboutClient from '@/components/AboutClient'
import { getBreadcrumbSchema } from '@/lib/seo'

export const metadata = {
  title: 'About Us — Enterprise Software Engineered for Real Growth',
  description:
    'The story, engineering mission, core values, and delivery process behind Olive Orange Technologies. Solving real business bottlenecks in weeks.',
  alternates: {
    canonical: '/about',
  },
  openGraph: {
    title: 'About Olive Orange Technologies',
    description:
      'The story, engineering mission, core values, and delivery process behind Olive Orange Technologies.',
    url: 'https://oliveorangetech.in/about',
  },
}

export default function AboutPage() {
  const breadcrumbSchema = getBreadcrumbSchema([
    { name: 'Home', url: '/' },
    { name: 'About', url: '/about' },
  ])

  return (
    <>
      <script
        id="schema-breadcrumb-about"
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }}
        suppressHydrationWarning
      />
      <AboutClient />
    </>
  )
}

const nextConfig = {
  output: 'standalone',
  devIndicators: false,
  images: {
    unoptimized: true,
    remotePatterns: [
      { protocol: 'https', hostname: '**' },
      { protocol: 'http', hostname: '**' },
    ],
  },
  // Renamed from experimental.serverComponentsExternalPackages in Next 15
  serverExternalPackages: ['mongodb'],
  webpack(config, { dev }) {
    if (dev) {
      // Reduce CPU/memory from file watching
      config.watchOptions = {
        poll: 2000, // check every 2 seconds
        aggregateTimeout: 300, // wait before rebuilding
        ignored: ['**/node_modules'],
      };
    }
    return config;
  },
  onDemandEntries: {
    maxInactiveAge: 10000,
    pagesBufferLength: 2,
  },
  async headers() {
    const isProduction = process.env.NODE_ENV === 'production' && process.env.FORCE_PRODUCTION_PERSISTENCE === 'true';
    const siteUrl = (process.env.NEXT_PUBLIC_SITE_URL || 'https://oliveorangetech.in').replace(/\/$/, '');

    const frameAncestors =
      process.env.FRAME_ANCESTORS ||
      (isProduction ? "'self' " + siteUrl : "'self' https://*.google.com https://*.run.app");

    const corsOrigin =
      process.env.CORS_ORIGINS ||
      (isProduction ? siteUrl : '*');

    return [
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
          { key: 'Content-Security-Policy', value: 'frame-ancestors ' + frameAncestors + ';' },
        ],
      },
      {
        source: '/api/:path*',
        headers: [
          { key: 'Access-Control-Allow-Origin', value: corsOrigin },
          { key: 'Access-Control-Allow-Methods', value: 'GET, POST, PUT, DELETE, OPTIONS' },
          { key: 'Access-Control-Allow-Headers', value: 'Content-Type, Authorization, X-Requested-With' },
        ],
      },
    ];
  },
};

module.exports = nextConfig;

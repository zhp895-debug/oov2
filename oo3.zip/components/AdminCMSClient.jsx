'use client'
import { useState, useEffect, useMemo } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'
import {
  LayoutDashboard,
  Users,
  FileText,
  Package,
  Settings,
  Download,
  Plus,
  Search,
  Filter,
  CheckCircle,
  Clock,
  AlertCircle,
  ExternalLink,
  Trash2,
  Edit,
  Eye,
  RefreshCw,
  Phone,
  Mail,
  Building,
  CheckCircle2,
  X as XIcon,
  ShieldCheck,
  Globe,
  Sparkles,
  Folder,
  Image as ImageIcon,
  KeyRound,
  Lock,
  Unlock,
  Check,
  Copy,
  ChevronRight,
  ArrowRight,
  BookOpen,
  LogOut,
  User as UserIcon,
  Upload,
} from 'lucide-react'
import { toast } from 'sonner'
import HeaderClient from '@/components/HeaderClient'
import FooterCTA from '@/components/FooterCTA'
import { slugify } from '@/lib/utils'

const STATUS_COLORS = {
  new: 'bg-emerald-50 text-emerald-700 border-emerald-200',
  contacted: 'bg-blue-50 text-blue-700 border-blue-200',
  qualified: 'bg-purple-50 text-purple-700 border-purple-200',
  closed_won: 'bg-amber-50 text-amber-700 border-amber-200',
  archived: 'bg-neutral-100 text-neutral-600 border-neutral-200',
}

const ROLES = [
  { id: 'super_admin', label: 'Super Admin', badge: 'Full Access', desc: 'Can manage all content, leads, team, and security settings.' },
  { id: 'admin', label: 'Admin', badge: 'Content & Leads', desc: 'Can manage content, leads, team, but cannot edit sensitive site settings.' },
  { id: 'editor', label: 'Editor', badge: 'Blog & Media Only', desc: 'Can manage blog, categories, and media only. Forbidden from leads, team & settings.' },
]

export default function AdminCMSClient({ initialUser, user: legacyUser }) {
  // Authoritative role comes from cryptographically verified server session
  const [currentUser, setCurrentUser] = useState(initialUser || legacyUser || null)
  const [verifying, setVerifying] = useState(!initialUser && !legacyUser)
  const activeRole = currentUser?.role || 'editor'
  const [loggingOut, setLoggingOut] = useState(false)
  const [activeTab, setActiveTab] = useState('overview')
  const [loading, setLoading] = useState(true)

  // Data states
  const [leads, setLeads] = useState([])
  const [posts, setPosts] = useState([])
  const [categories, setCategories] = useState([])
  const [team, setTeam] = useState([])
  const [media, setMedia] = useState([])
  const [settingsForm, setSettingsForm] = useState({
    companyName: 'Olive Orange Technologies',
    tagline: 'Every Problem Has A Solution.',
    positioning: 'We analyse your business problems and build the right digital solution.',
    phone: '+91 96246 89335',
    whatsapp: '+91 96246 89335',
    email: 'oliveorangetechnologies@gmail.com',
    instagram: 'https://www.instagram.com/oliveorange_technologies_india',
    facebook: 'https://www.facebook.com/profile.php?id=61592286137276',
    teamPhoto: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1600&q=80',
    teamPhotoAlt: 'Olive Orange Technologies engineering and operations team collaborating on client solutions',
  })
  const [stats, setStats] = useState(null)

  // Blog Management State
  const [searchPost, setSearchPost] = useState('')
  const [postStatusFilter, setPostStatusFilter] = useState('all') // all | published | draft
  const [postCatFilter, setPostCatFilter] = useState('all')
  const [postModal, setPostModal] = useState({ open: false, isEdit: false, targetSlug: '' })
  const [previewPost, setPreviewPost] = useState(null)
  const [savingPost, setSavingPost] = useState(false)
  const [postForm, setPostForm] = useState({
    title: '',
    slug: '',
    excerpt: '',
    content: '',
    featuredImage: '',
    category: 'AI Solutions & Automation',
    tags: 'AI, Automation, Digital Transformation',
    author: 'Olive Orange Technologies',
    role: 'Editorial Team',
    publicationDate: '',
    status: 'draft',
    metaTitle: '',
    metaDescription: '',
    canonicalUrl: '',
    ogImage: '',
    imageAltText: '',
    keyTakeawaysText: '',
    faqsText: '',
  })

  // Category Management State
  const [catModal, setCatModal] = useState({ open: false, isEdit: false, targetSlug: '' })
  const [catForm, setCatForm] = useState({ name: '', slug: '', description: '', active: true })
  const [savingCat, setSavingCat] = useState(false)

  // Team Management State
  const [teamModal, setTeamModal] = useState({ open: false, isEdit: false, targetId: '' })
  const [teamForm, setTeamForm] = useState({
    name: '',
    designation: '',
    profileImage: '',
    bio: '',
    email: '',
    linkedin: '',
    otherSocials: '',
    displayOrder: 1,
    isActive: true,
  })
  const [savingTeam, setSavingTeam] = useState(false)

  // Media Management State
  const [mediaModal, setMediaModal] = useState(false)
  const [mediaForm, setMediaForm] = useState({ url: '', fileName: '', altText: '' })
  const [savingMedia, setSavingMedia] = useState(false)

  // Leads CRM State
  const [searchLead, setSearchLead] = useState('')
  const [leadStatusFilter, setLeadStatusFilter] = useState('all')
  const [leadTypeFilter, setLeadTypeFilter] = useState('all')
  const [selectedLead, setSelectedLead] = useState(null)

  // Settings State
  const [savingSettings, setSavingSettings] = useState(false)

  // Secure fetch wrapper with automatic credentials and 401 session expiration handling
  const authFetch = async (url, options = {}) => {
    const token =
      typeof window !== 'undefined'
        ? sessionStorage.getItem('oo_admin_token') || localStorage.getItem('oo_admin_token')
        : null

    const headers = {
      ...(options.headers || {}),
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    }

    const res = await fetch(url, {
      ...options,
      headers,
      credentials: 'include',
    })

    if (res.status === 401) {
      toast.error('Session expired or unauthorized. Redirecting to sign in...')
      try {
        sessionStorage.removeItem('oo_admin_token')
        sessionStorage.removeItem('oo_admin_user')
        localStorage.removeItem('oo_admin_token')
      } catch (e) {}
      window.location.href = '/admin/login'
      return res
    }

    return res
  }

  const handleLogout = async () => {
    setLoggingOut(true)
    try {
      const token =
        typeof window !== 'undefined'
          ? sessionStorage.getItem('oo_admin_token') || localStorage.getItem('oo_admin_token')
          : null

      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: token ? { Authorization: `Bearer ${token}` } : {},
        credentials: 'include',
      })
      try {
        sessionStorage.removeItem('oo_admin_token')
        sessionStorage.removeItem('oo_admin_user')
        localStorage.removeItem('oo_admin_token')
      } catch (e) {}
      toast.success('Signed out successfully')
      window.location.href = '/admin/login'
    } catch {
      window.location.href = '/admin/login'
    }
  }

  // Load all CMS data
  const fetchData = async () => {
    setLoading(true)
    try {
      const [dashRes, leadsRes, postsRes, settingsRes, catsRes, teamRes, mediaRes] = await Promise.all([
        authFetch('/api/admin/dashboard').then((r) => r.json()).catch(() => ({ ok: false })),
        authFetch('/api/leads').then((r) => r.json()).catch(() => ({ ok: false })),
        authFetch('/api/posts?includeDrafts=true').then((r) => r.json()).catch(() => ({ ok: false })),
        authFetch('/api/settings').then((r) => r.json()).catch(() => ({ ok: false })),
        authFetch('/api/categories').then((r) => r.json()).catch(() => ({ ok: false })),
        authFetch('/api/team?all=true').then((r) => r.json()).catch(() => ({ ok: false })),
        authFetch('/api/media').then((r) => r.json()).catch(() => ({ ok: false })),
      ])

      if (dashRes?.ok && dashRes.stats) {
        setStats(dashRes.stats)
      }

      if (leadsRes?.ok) setLeads(leadsRes.items || [])
      else setLeads([])

      if (postsRes?.ok) setPosts(postsRes.posts || [])
      if (settingsRes?.ok && settingsRes.settings) setSettingsForm(settingsRes.settings)
      if (catsRes?.ok) setCategories(catsRes.categories || [])
      if (teamRes?.ok) setTeam(teamRes.members || [])
      if (mediaRes?.ok) setMedia(mediaRes.media || [])
    } catch {
      toast.error('Failed to load live data')
    }
    setLoading(false)
  }

  useEffect(() => {
    // If user already authenticated from server cookie
    if (currentUser) {
      setVerifying(false)
      fetchData()
      return
    }

    // Fallback: check stored token for iframe environments
    const token =
      typeof window !== 'undefined'
        ? sessionStorage.getItem('oo_admin_token') || localStorage.getItem('oo_admin_token')
        : null

    if (!token) {
      window.location.href = '/admin/login'
      return
    }

    // Verify cryptographic token with server-side /api/auth/me
    fetch('/api/auth/me', {
      headers: { Authorization: `Bearer ${token}` },
      credentials: 'include',
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.ok && data.user) {
          setCurrentUser(data.user)
          setVerifying(false)
          fetchData()
        } else {
          try {
            sessionStorage.removeItem('oo_admin_token')
            sessionStorage.removeItem('oo_admin_user')
            localStorage.removeItem('oo_admin_token')
          } catch (e) {}
          window.location.href = '/admin/login'
        }
      })
      .catch(() => {
        window.location.href = '/admin/login'
      })
  }, [])

  // ==================== BLOG POST HANDLERS ====================
  const openNewPost = () => {
    setPostForm({
      title: '',
      slug: '',
      excerpt: '',
      content: '',
      featuredImage: media[0]?.url || 'https://images.unsplash.com/photo-1652156752342-c786f1e1d1ce',
      category: categories[0]?.name || 'AI Solutions & Automation',
      tags: 'AI, Automation, Digital Transformation',
      author: 'Olive Orange Technologies',
      role: 'Editorial Team',
      publicationDate: new Date().toISOString().split('T')[0],
      status: 'draft',
      metaTitle: '',
      metaDescription: '',
      canonicalUrl: '',
      ogImage: '',
      imageAltText: '',
      keyTakeawaysText: '• Practical automation reduces operational friction.\n• Problem-first discovery delivers sustainable ROI.\n• Complete client code & data sovereignty.',
      faqsText: 'Q: How does this solution integrate?\nA: Through clean API connectors.\n\nQ: Is our business data safe?\nA: Yes, data stays strictly private.',
    })
    setPostModal({ open: true, isEdit: false, targetSlug: '' })
  }

  const openEditPost = (post) => {
    const contentStr = Array.isArray(post.content) ? post.content.join('\n\n') : (post.content || '')
    const takeawaysStr = Array.isArray(post.keyTakeaways) ? post.keyTakeaways.join('\n') : ''
    const faqsStr = Array.isArray(post.faqs)
      ? post.faqs.map((f) => `Q: ${f.q}\nA: ${f.a}`).join('\n\n')
      : ''

    setPostForm({
      title: post.title || '',
      slug: post.slug || '',
      excerpt: post.excerpt || '',
      content: contentStr,
      featuredImage: post.featuredImage || post.image || '',
      category: post.category || 'AI Solutions & Automation',
      tags: Array.isArray(post.tags) ? post.tags.join(', ') : (post.tags || ''),
      author: post.author || 'Olive Orange Technologies',
      role: post.role || 'Editorial Team',
      publicationDate: post.publicationDate || '',
      status: post.status || 'draft',
      metaTitle: post.metaTitle || '',
      metaDescription: post.metaDescription || '',
      canonicalUrl: post.canonicalUrl || '',
      ogImage: post.ogImage || '',
      imageAltText: post.imageAltText || '',
      keyTakeawaysText: takeawaysStr,
      faqsText: faqsStr,
    })
    setPostModal({ open: true, isEdit: true, targetSlug: post.slug })
  }

  const handleTitleChange = (val) => {
    setPostForm((prev) => ({
      ...prev,
      title: val,
      slug: !postModal.isEdit || !prev.slug ? slugify(val) : prev.slug,
      metaTitle: `${val} | Olive Orange Technologies`,
    }))
  }

  const handleSavePost = async (e) => {
    e.preventDefault()
    if (!postForm.title.trim() || !postForm.excerpt.trim()) {
      toast.error('Title and excerpt are required.')
      return
    }

    setSavingPost(true)

    // Parse takeaways
    const keyTakeaways = postForm.keyTakeawaysText
      .split('\n')
      .map((s) => s.replace(/^[•\-\*]\s*/, '').trim())
      .filter(Boolean)

    // Parse FAQs
    const faqs = []
    const faqBlocks = postForm.faqsText.split('\n\n')
    for (const block of faqBlocks) {
      const lines = block.split('\n').map((l) => l.trim()).filter(Boolean)
      let q = '', a = ''
      for (const line of lines) {
        if (/^Q:\s*/i.test(line)) q = line.replace(/^Q:\s*/i, '')
        else if (/^A:\s*/i.test(line)) a = line.replace(/^A:\s*/i, '')
      }
      if (q && a) faqs.push({ q, a })
    }

    const payload = {
      title: postForm.title,
      slug: slugify(postForm.slug || postForm.title),
      targetSlug: postModal.targetSlug,
      excerpt: postForm.excerpt,
      content: postForm.content,
      featuredImage: postForm.featuredImage,
      category: postForm.category,
      tags: postForm.tags,
      author: postForm.author,
      role: postForm.role,
      publicationDate: postForm.publicationDate,
      status: postForm.status,
      metaTitle: postForm.metaTitle,
      metaDescription: postForm.metaDescription,
      canonicalUrl: postForm.canonicalUrl,
      ogImage: postForm.ogImage,
      imageAltText: postForm.imageAltText,
      keyTakeaways,
      faqs,
    }

    try {
      const method = postModal.isEdit ? 'PUT' : 'POST'
      const res = await authFetch('/api/posts', {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (data?.ok) {
        toast.success(postModal.isEdit ? 'Article updated successfully!' : 'Article created successfully!')
        setPostModal({ open: false, isEdit: false, targetSlug: '' })
        fetchData()
      } else {
        toast.error(data?.error || 'Failed to save article')
      }
    } catch {
      toast.error('Network error saving article')
    }
    setSavingPost(false)
  }

  const handleTogglePublish = async (post) => {
    try {
      const res = await authFetch('/api/posts', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slug: post.slug }),
      })
      const data = await res.json()
      if (data?.ok) {
        const nextStatus = data.post.status
        toast.success(nextStatus === 'published' ? `Published "${post.title}"! Visible publicly.` : `Unpublished "${post.title}". Saved as draft.`)
        fetchData()
      } else {
        toast.error(data?.error || 'Failed to update article status')
      }
    } catch {
      toast.error('Error changing article status')
    }
  }

  const handleDeletePost = async (post) => {
    if (!confirm(`Are you sure you want to delete article "${post.title}"?`)) return
    try {
      const res = await authFetch(`/api/posts?slug=${encodeURIComponent(post.slug)}`, { method: 'DELETE' })
      const data = await res.json()
      if (data?.ok) {
        toast.success('Article deleted')
        fetchData()
      } else {
        toast.error(data?.error || 'Failed to delete article')
      }
    } catch {
      toast.error('Error deleting article')
    }
  }

  // ==================== CATEGORY HANDLERS ====================
  const openNewCategory = () => {
    setCatForm({ name: '', slug: '', description: '', active: true })
    setCatModal({ open: true, isEdit: false, targetSlug: '' })
  }

  const openEditCategory = (cat) => {
    setCatForm({ name: cat.name, slug: cat.slug, description: cat.description || '', active: cat.active ?? true })
    setCatModal({ open: true, isEdit: true, targetSlug: cat.slug })
  }

  const handleSaveCategory = async (e) => {
    e.preventDefault()
    if (!catForm.name.trim()) {
      toast.error('Category name is required')
      return
    }
    setSavingCat(true)
    try {
      const method = catModal.isEdit ? 'PUT' : 'POST'
      const payload = { ...catForm, targetSlug: catModal.targetSlug, slug: slugify(catForm.slug || catForm.name) }
      const res = await authFetch('/api/categories', {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (data?.ok) {
        toast.success(catModal.isEdit ? 'Category updated' : 'Category created')
        setCatModal({ open: false, isEdit: false, targetSlug: '' })
        fetchData()
      } else {
        toast.error(data?.error || 'Failed to save category')
      }
    } catch {
      toast.error('Network error saving category')
    }
    setSavingCat(false)
  }

  const handleDeleteCategory = async (cat) => {
    if (!confirm(`Delete category "${cat.name}"?`)) return
    try {
      const res = await authFetch(`/api/categories?slug=${encodeURIComponent(cat.slug)}`, { method: 'DELETE' })
      const data = await res.json()
      if (data?.ok) {
        toast.success('Category deleted')
        fetchData()
      } else {
        toast.error(data?.error || 'Failed to delete category')
      }
    } catch {
      toast.error('Error deleting category')
    }
  }

  // ==================== TEAM HANDLERS ====================
  const openNewTeamMember = () => {
    setTeamForm({
      name: '',
      designation: '',
      profileImage: '',
      bio: '',
      email: '',
      linkedin: '',
      otherSocials: '',
      displayOrder: team.length + 1,
      isActive: true,
    })
    setTeamModal({ open: true, isEdit: false, targetId: '' })
  }

  const openEditTeamMember = (m) => {
    setTeamForm({
      name: m.name || '',
      designation: m.designation || '',
      profileImage: m.profileImage || '',
      bio: m.bio || '',
      email: m.email || '',
      linkedin: m.linkedin || '',
      otherSocials: m.otherSocials || '',
      displayOrder: m.displayOrder || 1,
      isActive: m.isActive ?? true,
    })
    setTeamModal({ open: true, isEdit: true, targetId: m.id })
  }

  const handleSaveTeam = async (e) => {
    e.preventDefault()
    if (!teamForm.name.trim() || !teamForm.designation.trim()) {
      toast.error('Name and designation are required.')
      return
    }
    setSavingTeam(true)
    try {
      const method = teamModal.isEdit ? 'PUT' : 'POST'
      const payload = { ...teamForm, id: teamModal.targetId }
      const res = await authFetch('/api/team', {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (data?.ok) {
        toast.success(teamModal.isEdit ? 'Team member updated' : 'Team member added')
        setTeamModal({ open: false, isEdit: false, targetId: '' })
        fetchData()
      } else {
        toast.error(data?.error || 'Failed to save team member')
      }
    } catch {
      toast.error('Network error saving team member')
    }
    setSavingTeam(false)
  }

  const handleDeleteTeam = async (m) => {
    if (!confirm(`Delete profile for "${m.name}"?`)) return
    try {
      const res = await authFetch(`/api/team?id=${encodeURIComponent(m.id)}`, { method: 'DELETE' })
      const data = await res.json()
      if (data?.ok) {
        toast.success('Team member removed')
        fetchData()
      } else {
        toast.error(data?.error || 'Failed to delete member')
      }
    } catch {
      toast.error('Error deleting member')
    }
  }

  // ==================== MEDIA HANDLERS ====================
  const handleAddMedia = async (e) => {
    e.preventDefault()
    if (!mediaForm.url.trim()) {
      toast.error('Media URL is required')
      return
    }
    setSavingMedia(true)
    try {
      const res = await authFetch('/api/media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(mediaForm),
      })
      const data = await res.json()
      if (data?.ok) {
        toast.success('Media asset added!')
        setMediaModal(false)
        setMediaForm({ url: '', fileName: '', altText: '' })
        fetchData()
      } else {
        toast.error(data?.error || 'Failed to add media')
      }
    } catch {
      toast.error('Network error adding media')
    }
    setSavingMedia(false)
  }

  const handleDeleteMedia = async (item) => {
    if (!confirm(`Delete media item "${item.fileName}"?`)) return
    try {
      const res = await authFetch(`/api/media?id=${encodeURIComponent(item.id)}`, { method: 'DELETE' })
      const data = await res.json()
      if (data?.ok) {
        toast.success('Media asset removed')
        fetchData()
      } else {
        toast.error(data?.error || 'Failed to delete media')
      }
    } catch {
      toast.error('Error deleting media')
    }
  }

  // ==================== SETTINGS HANDLER ====================
  const handleSaveSettings = async (e) => {
    e.preventDefault()
    setSavingSettings(true)
    try {
      const res = await authFetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settingsForm),
      })
      const data = await res.json()
      if (data?.ok) {
        toast.success('Website settings updated!')
      } else {
        toast.error(data?.error || 'Failed to update settings')
      }
    } catch {
      toast.error('Network error saving settings')
    }
    setSavingSettings(false)
  }

  // ==================== LEADS HANDLERS ====================
  const handleUpdateLeadStatus = async (id, newStatus) => {
    try {
      const res = await authFetch('/api/leads', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus }),
      })
      const data = await res.json()
      if (data?.ok) {
        toast.success(`Lead marked as ${newStatus}`)
        fetchData()
      } else {
        toast.error(data?.error || 'Failed to update lead')
      }
    } catch {
      toast.error('Error updating lead')
    }
  }

  const handleDeleteLead = async (id) => {
    if (!confirm('Are you sure you want to delete this lead?')) return
    try {
      const res = await authFetch(`/api/leads?id=${encodeURIComponent(id)}`, { method: 'DELETE' })
      const data = await res.json()
      if (data?.ok) {
        toast.success('Lead deleted')
        fetchData()
      } else {
        toast.error(data?.error || 'Failed to delete lead')
      }
    } catch {
      toast.error('Error deleting lead')
    }
  }

  const handleExportCSV = () => {
    if (leads.length === 0) {
      toast.error('No leads available to export')
      return
    }
    const headers = ['ID', 'Type', 'Status', 'Name', 'Email', 'Phone', 'Company', 'Service/Interest', 'Created At']
    const rows = leads.map((l) => [
      `"${l.id || ''}"`,
      `"${l.type || ''}"`,
      `"${l.status || 'new'}"`,
      `"${(l.name || '').replace(/"/g, '""')}"`,
      `"${l.email || ''}"`,
      `"${l.phone || ''}"`,
      `"${(l.company || '').replace(/"/g, '""')}"`,
      `"${(l.service || '').replace(/"/g, '""')}"`,
      `"${l.createdAt || ''}"`,
    ])
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n')
    const encodedUri = encodeURI(csvContent)
    const link = document.createElement('a')
    link.setAttribute('href', encodedUri)
    link.setAttribute('download', `olive-orange-leads-${new Date().toISOString().split('T')[0]}.csv`)
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    toast.success('Leads exported to CSV!')
  }

  // Filtered Blog Posts
  const filteredPosts = useMemo(() => {
    return posts.filter((p) => {
      const matchesSearch =
        (p.title || '').toLowerCase().includes(searchPost.toLowerCase()) ||
        (p.excerpt || '').toLowerCase().includes(searchPost.toLowerCase()) ||
        (p.slug || '').toLowerCase().includes(searchPost.toLowerCase())
      const matchesStatus = postStatusFilter === 'all' || p.status === postStatusFilter
      const matchesCat = postCatFilter === 'all' || p.category === postCatFilter
      return matchesSearch && matchesStatus && matchesCat
    })
  }, [posts, searchPost, postStatusFilter, postCatFilter])

  // Filtered Leads
  const filteredLeads = useMemo(() => {
    return leads.filter((l) => {
      const matchesSearch =
        (l.name || '').toLowerCase().includes(searchLead.toLowerCase()) ||
        (l.email || '').toLowerCase().includes(searchLead.toLowerCase()) ||
        (l.company || '').toLowerCase().includes(searchLead.toLowerCase()) ||
        (l.phone || '').includes(searchLead)
      const matchesStatus = leadStatusFilter === 'all' || l.status === leadStatusFilter
      const matchesType = leadTypeFilter === 'all' || l.type === leadTypeFilter
      return matchesSearch && matchesStatus && matchesType
    })
  }, [leads, searchLead, leadStatusFilter, leadTypeFilter])

  const activeRoleMeta = ROLES.find((r) => r.id === activeRole)

  if (verifying || !currentUser) {
    return (
      <main className="min-h-screen bg-neutral-950 text-white flex items-center justify-center p-6 selection:bg-brand-500 selection:text-white">
        <div className="flex flex-col items-center gap-3 text-center">
          <div className="w-10 h-10 border-2 border-brand-500 border-t-transparent rounded-full animate-spin" />
          <h2 className="font-display text-base font-semibold text-white">Verifying Authorized Session</h2>
          <p className="text-xs text-neutral-400 max-w-xs">Connecting to cryptographic security service and loading CMS workspace...</p>
        </div>
      </main>
    )
  }

  return (
    <main className="relative min-h-screen bg-neutral-50 text-neutral-900 pb-20">
      <HeaderClient />

      {/* TOP CMS BAR */}
      <section className="pt-32 pb-6 sm:pt-40 bg-white border-b border-neutral-200">
        <div className="container max-w-7xl mx-auto px-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100 text-brand-700 text-xs font-semibold uppercase tracking-widest">
                <LayoutDashboard className="h-3.5 w-3.5" /> Olive Orange Technologies CMS
              </div>
              <h1 className="font-display text-2xl sm:text-3xl font-bold mt-2 text-neutral-900">
                Content &amp; Operations Management
              </h1>
              <p className="text-xs text-neutral-500 mt-1">
                Centralized Blog Management, Category Taxonomy, Verified Team, Media Library, and Site Settings.
              </p>
            </div>

            {/* Authenticated User Status & Console Actions */}
            <div className="flex flex-wrap items-center gap-3">
              {/* Verified Session Badge */}
              <div className="flex items-center gap-2 px-3 py-1.5 bg-neutral-100 rounded-2xl border border-neutral-200 text-xs">
                <div className="w-6 h-6 rounded-full bg-brand-500/10 text-brand-600 flex items-center justify-center font-bold text-[11px]">
                  <UserIcon className="h-3.5 w-3.5" />
                </div>
                <div className="flex flex-col text-left">
                  <span className="font-semibold text-neutral-900 leading-tight">
                    {currentUser?.name || 'Authorized Admin'}
                  </span>
                  <span className="text-[10px] text-neutral-500 font-mono">
                    {currentUser?.email || 'admin@oliveorangetech.in'}
                  </span>
                </div>
                <span className="ml-1 px-2 py-0.5 rounded-full bg-white border border-brand-200 text-[10px] font-bold text-brand-700 uppercase tracking-wider">
                  {activeRoleMeta?.label}
                </span>
              </div>

              <button
                onClick={fetchData}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-xl border border-neutral-200 bg-white hover:bg-neutral-50 transition"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh
              </button>

              <button
                onClick={handleLogout}
                disabled={loggingOut}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold rounded-xl border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 transition disabled:opacity-50"
              >
                <LogOut className="h-3.5 w-3.5" /> {loggingOut ? 'Signing out...' : 'Sign Out'}
              </button>
            </div>
          </div>

          {/* Active Role Permissions Banner */}
          <div className="mt-4 p-3 rounded-2xl bg-brand-50/50 border border-brand-100/80 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-600" />
              <span className="font-semibold text-brand-700">{activeRoleMeta?.label} Session</span>
              <span className="px-2 py-0.5 rounded-full bg-white border border-brand-200 text-[10px] text-brand-600 font-bold uppercase tracking-wider">
                {activeRoleMeta?.badge}
              </span>
              <span className="text-neutral-500 hidden sm:inline">— {activeRoleMeta?.desc}</span>
            </div>
            <div className="text-[11px] text-neutral-500 font-medium">
              Server-Side Cryptographic Session Active
            </div>
          </div>

          {/* CMS TABS */}
          <div className="mt-6 flex items-center gap-1 overflow-x-auto pb-1 border-b border-neutral-200/80">
            {[
              { id: 'overview', label: 'Overview', icon: LayoutDashboard },
              { id: 'blog', label: `Blog CMS (${posts.length})`, icon: FileText },
              { id: 'categories', label: `Categories (${categories.length})`, icon: Folder },
              { id: 'team', label: `Team (${team.length})`, icon: Users },
              { id: 'media', label: `Media (${media.length})`, icon: ImageIcon },
              { id: 'settings', label: 'Website Settings', icon: Settings },
              { id: 'leads', label: `Leads CRM (${leads.length})`, icon: Users },
            ].map((tab) => {
              const active = activeTab === tab.id
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`inline-flex items-center gap-2 px-4 py-2.5 text-xs font-medium border-b-2 transition whitespace-nowrap ${
                    active
                      ? 'border-brand-600 text-brand-600 font-semibold'
                      : 'border-transparent text-neutral-500 hover:text-neutral-900 hover:border-neutral-300'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              )
            })}
          </div>
        </div>
      </section>

      {/* MAIN CONTENT AREA */}
      <div className="container max-w-7xl mx-auto px-4 mt-8">
        {/* ==================== TAB 1: OVERVIEW ==================== */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="rounded-3xl bg-white p-6 border border-neutral-200/80 shadow-sm">
                <div className="text-xs text-neutral-500 font-medium">Published Articles</div>
                <div className="font-display text-3xl font-bold text-neutral-900 mt-2">
                  {posts.filter((p) => p.status === 'published').length}
                </div>
                <div className="text-xs text-emerald-600 mt-2 flex items-center gap-1">
                  <CheckCircle2 className="h-3 w-3" /> Live on /blog
                </div>
              </div>

              <div className="rounded-3xl bg-white p-6 border border-neutral-200/80 shadow-sm">
                <div className="text-xs text-neutral-500 font-medium">Draft Articles</div>
                <div className="font-display text-3xl font-bold text-amber-600 mt-2">
                  {posts.filter((p) => p.status === 'draft').length}
                </div>
                <div className="text-xs text-neutral-500 mt-2">Unpublished &amp; secure</div>
              </div>

              <div className="rounded-3xl bg-white p-6 border border-neutral-200/80 shadow-sm">
                <div className="text-xs text-neutral-500 font-medium">Taxonomy Categories</div>
                <div className="font-display text-3xl font-bold text-brand-600 mt-2">
                  {categories.length}
                </div>
                <div className="text-xs text-neutral-500 mt-2">Mapped to 12 capabilities</div>
              </div>

              <div className="rounded-3xl bg-white p-6 border border-neutral-200/80 shadow-sm">
                <div className="text-xs text-neutral-500 font-medium">Verified Team Members</div>
                <div className="font-display text-3xl font-bold text-neutral-900 mt-2">
                  {team.length}
                </div>
                <div className="text-xs text-neutral-500 mt-2">Strict factual policy</div>
              </div>
            </div>

            {/* Quick Actions Card */}
            <div className="rounded-3xl bg-white p-6 border border-neutral-200/80 shadow-sm">
              <h3 className="font-display font-bold text-lg text-neutral-900">CMS Quick Operations</h3>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
                <button
                  onClick={() => { setActiveTab('blog'); openNewPost() }}
                  className="p-4 rounded-2xl border border-neutral-200 hover:border-brand-500 hover:bg-brand-50/40 text-left transition group"
                >
                  <FileText className="h-6 w-6 text-brand-500 group-hover:scale-110 transition-transform" />
                  <div className="font-semibold text-sm text-neutral-900 mt-2">Create New Article</div>
                  <div className="text-xs text-neutral-500 mt-1">Rich content, tags &amp; SEO metadata</div>
                </button>

                <button
                  onClick={() => { setActiveTab('categories'); openNewCategory() }}
                  className="p-4 rounded-2xl border border-neutral-200 hover:border-brand-500 hover:bg-brand-50/40 text-left transition group"
                >
                  <Folder className="h-6 w-6 text-brand-500 group-hover:scale-110 transition-transform" />
                  <div className="font-semibold text-sm text-neutral-900 mt-2">Add Blog Category</div>
                  <div className="text-xs text-neutral-500 mt-1">Unique slug taxonomy</div>
                </button>

                <button
                  onClick={() => { setActiveTab('team'); openNewTeamMember() }}
                  className="p-4 rounded-2xl border border-neutral-200 hover:border-brand-500 hover:bg-brand-50/40 text-left transition group"
                >
                  <Users className="h-6 w-6 text-brand-500 group-hover:scale-110 transition-transform" />
                  <div className="font-semibold text-sm text-neutral-900 mt-2">Add Team Member</div>
                  <div className="text-xs text-neutral-500 mt-1">Real verified personnel only</div>
                </button>

                <button
                  onClick={() => { setActiveTab('media'); setMediaModal(true) }}
                  className="p-4 rounded-2xl border border-neutral-200 hover:border-brand-500 hover:bg-brand-50/40 text-left transition group"
                >
                  <ImageIcon className="h-6 w-6 text-brand-500 group-hover:scale-110 transition-transform" />
                  <div className="font-semibold text-sm text-neutral-900 mt-2">Register Media Asset</div>
                  <div className="text-xs text-neutral-500 mt-1">Image URLs, alt text &amp; storage</div>
                </button>
              </div>
            </div>

            {/* Public Links Test Checkpoints */}
            <div className="rounded-3xl bg-neutral-900 text-white p-6 border border-neutral-800">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-display font-bold text-lg">Public Connection Checkpoints</h4>
                  <p className="text-xs text-neutral-400 mt-1">Verify live routing and public content visibility.</p>
                </div>
              </div>
              <div className="grid sm:grid-cols-3 gap-3 mt-4 text-xs">
                <Link
                  href="/blog"
                  target="_blank"
                  className="p-3 rounded-2xl bg-neutral-800 hover:bg-neutral-700 flex items-center justify-between text-neutral-200 transition"
                >
                  <span>Public Blog Index (/blog)</span>
                  <ExternalLink className="h-3.5 w-3.5 text-brand-400" />
                </Link>
                <Link
                  href="/sitemap.xml"
                  target="_blank"
                  className="p-3 rounded-2xl bg-neutral-800 hover:bg-neutral-700 flex items-center justify-between text-neutral-200 transition"
                >
                  <span>XML Sitemap (/sitemap.xml)</span>
                  <ExternalLink className="h-3.5 w-3.5 text-brand-400" />
                </Link>
                <Link
                  href="/robots.txt"
                  target="_blank"
                  className="p-3 rounded-2xl bg-neutral-800 hover:bg-neutral-700 flex items-center justify-between text-neutral-200 transition"
                >
                  <span>Robots Config (/robots.txt)</span>
                  <ExternalLink className="h-3.5 w-3.5 text-brand-400" />
                </Link>
              </div>
            </div>
          </div>
        )}

        {/* ==================== TAB 2: BLOG CMS (MODULE 1) ==================== */}
        {activeTab === 'blog' && (
          <div className="space-y-6">
            {/* Header & Controls */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="font-display font-bold text-xl text-neutral-900">Article Management</h2>
                <p className="text-xs text-neutral-500">Create, edit, preview, publish, unpublish, and manage SEO meta.</p>
              </div>
              <button
                onClick={openNewPost}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-brand-500 hover:bg-brand-600 text-white text-xs font-semibold shadow-glow transition self-start sm:self-auto"
              >
                <Plus className="h-4 w-4" /> Create Blog Post
              </button>
            </div>

            {/* Filter Bar */}
            <div className="p-4 rounded-3xl bg-white border border-neutral-200/80 shadow-sm flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
              <div className="relative w-full md:w-80">
                <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-neutral-400" />
                <input
                  type="text"
                  placeholder="Search articles by title, slug, or content…"
                  value={searchPost}
                  onChange={(e) => setSearchPost(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-neutral-200 focus:outline-none focus:border-brand-500 text-xs"
                />
              </div>

              <div className="flex items-center gap-2 w-full md:w-auto">
                <select
                  value={postStatusFilter}
                  onChange={(e) => setPostStatusFilter(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-neutral-200 bg-white text-xs focus:outline-none"
                >
                  <option value="all">All Statuses ({posts.length})</option>
                  <option value="published">Published Only ({posts.filter((p) => p.status === 'published').length})</option>
                  <option value="draft">Drafts Only ({posts.filter((p) => p.status === 'draft').length})</option>
                </select>

                <select
                  value={postCatFilter}
                  onChange={(e) => setPostCatFilter(e.target.value)}
                  className="px-3 py-2 rounded-xl border border-neutral-200 bg-white text-xs focus:outline-none"
                >
                  <option value="all">All Categories</option>
                  {categories.map((c) => (
                    <option key={c.slug} value={c.name}>{c.name}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Articles Table */}
            <div className="rounded-3xl bg-white border border-neutral-200/80 shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 font-semibold uppercase tracking-wider">
                    <tr>
                      <th className="py-3.5 px-4">Article</th>
                      <th className="py-3.5 px-4">Category</th>
                      <th className="py-3.5 px-4">Status</th>
                      <th className="py-3.5 px-4">Date</th>
                      <th className="py-3.5 px-4">Author</th>
                      <th className="py-3.5 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-neutral-100">
                    {filteredPosts.length === 0 ? (
                      <tr>
                        <td colSpan="6" className="py-12 text-center text-neutral-400">
                          No articles match your search or filter.
                        </td>
                      </tr>
                    ) : (
                      filteredPosts.map((post) => {
                        const isPub = post.status === 'published'
                        return (
                          <tr key={post.slug} className="hover:bg-neutral-50/60 transition">
                            <td className="py-3 px-4 max-w-sm">
                              <div className="flex items-center gap-3">
                                <div className="h-10 w-14 shrink-0 rounded-lg overflow-hidden bg-neutral-100 border border-neutral-200">
                                  <img
                                    src={post.featuredImage || post.image || '/brand/oli-mascot.jpg'}
                                    alt={post.title}
                                    className="h-full w-full object-cover"
                                    onError={(e) => { e.currentTarget.src = 'https://images.unsplash.com/photo-1652156752342-c786f1e1d1ce?w=200&auto=format&fit=crop&q=70' }}
                                  />
                                </div>
                                <div className="min-w-0">
                                  <div className="font-semibold text-neutral-900 line-clamp-1">{post.title}</div>
                                  <div className="text-[11px] text-neutral-400 font-mono mt-0.5">/{post.slug}</div>
                                </div>
                              </div>
                            </td>
                            <td className="py-3.5 px-4">
                              <span className="px-2.5 py-1 rounded-full bg-neutral-100 text-neutral-700 font-medium">
                                {post.category}
                              </span>
                            </td>
                            <td className="py-3.5 px-4">
                              <button
                                onClick={() => handleTogglePublish(post)}
                                title={isPub ? 'Click to unpublish' : 'Click to publish'}
                                className={`px-2.5 py-1 rounded-full text-[11px] font-semibold flex items-center gap-1 border transition ${
                                  isPub
                                    ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                                    : 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100'
                                }`}
                              >
                                <span className={`h-1.5 w-1.5 rounded-full ${isPub ? 'bg-emerald-500' : 'bg-amber-500'}`} />
                                {isPub ? 'Published' : 'Draft'}
                              </button>
                            </td>
                            <td className="py-3.5 px-4 text-neutral-500 whitespace-nowrap">
                              {post.publicationDate || post.createdAt?.split('T')[0] || 'Unscheduled'}
                            </td>
                            <td className="py-3.5 px-4 text-neutral-600 whitespace-nowrap">
                              {post.author}
                            </td>
                            <td className="py-3.5 px-4 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => setPreviewPost(post)}
                                  className="p-1.5 rounded-lg hover:bg-neutral-100 text-neutral-600 hover:text-neutral-900 transition"
                                  title="Live Article Preview"
                                >
                                  <Eye className="h-3.5 w-3.5" />
                                </button>
                                {isPub && (
                                  <Link
                                    href={`/blog/${post.slug}`}
                                    target="_blank"
                                    className="p-1.5 rounded-lg hover:bg-neutral-100 text-neutral-600 hover:text-brand-600 transition"
                                    title="Open Public Link"
                                  >
                                    <ExternalLink className="h-3.5 w-3.5" />
                                  </Link>
                                )}
                                <button
                                  onClick={() => openEditPost(post)}
                                  className="p-1.5 rounded-lg hover:bg-neutral-100 text-neutral-600 hover:text-neutral-900 transition"
                                  title="Edit Post"
                                >
                                  <Edit className="h-3.5 w-3.5" />
                                </button>
                                <button
                                  onClick={() => handleDeletePost(post)}
                                  className="p-1.5 rounded-lg hover:bg-red-50 text-neutral-400 hover:text-red-600 transition"
                                  title="Delete Post"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                </button>
                              </div>
                            </td>
                          </tr>
                        )
                      })
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ==================== TAB 3: CATEGORIES CMS (MODULE 2) ==================== */}
        {activeTab === 'categories' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="font-display font-bold text-xl text-neutral-900">Blog Categories Taxonomy</h2>
                <p className="text-xs text-neutral-500">Manage unique category slugs, descriptions, and active status.</p>
              </div>
              <button
                onClick={openNewCategory}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-brand-500 hover:bg-brand-600 text-white text-xs font-semibold shadow-glow transition self-start sm:self-auto"
              >
                <Plus className="h-4 w-4" /> Add Category
              </button>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {categories.map((cat) => (
                <div
                  key={cat.slug}
                  className="rounded-3xl bg-white p-5 border border-neutral-200/80 shadow-sm flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-xs px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-600">
                        /{cat.slug}
                      </span>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${cat.active ? 'bg-emerald-50 text-emerald-700' : 'bg-neutral-100 text-neutral-500'}`}>
                        {cat.active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <h3 className="font-display font-bold text-base text-neutral-900 mt-3">{cat.name}</h3>
                    <p className="text-xs text-neutral-500 mt-1 leading-relaxed line-clamp-2">
                      {cat.description || 'No description provided.'}
                    </p>
                  </div>

                  <div className="mt-5 pt-3 border-t border-neutral-100 flex items-center justify-between">
                    <Link
                      href={`/blog/category/${cat.slug}`}
                      target="_blank"
                      className="text-xs text-brand-600 hover:text-brand-700 font-semibold flex items-center gap-1"
                    >
                      View Archive <ExternalLink className="h-3 w-3" />
                    </Link>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => openEditCategory(cat)}
                        className="p-1.5 rounded-lg hover:bg-neutral-100 text-neutral-600"
                        title="Edit Category"
                      >
                        <Edit className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => handleDeleteCategory(cat)}
                        className="p-1.5 rounded-lg hover:bg-red-50 text-neutral-400 hover:text-red-600"
                        title="Delete Category"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ==================== TAB 4: TEAM CMS (MODULE 3) ==================== */}
        {activeTab === 'team' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="font-display font-bold text-xl text-neutral-900">Team Directory Management</h2>
                <p className="text-xs text-neutral-500">
                  Strict factual policy: Do NOT invent team members. Only add real profiles provided by leadership.
                </p>
              </div>
              {activeRole !== 'editor' ? (
                <button
                  onClick={openNewTeamMember}
                  className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-brand-500 hover:bg-brand-600 text-white text-xs font-semibold shadow-glow transition self-start sm:self-auto"
                >
                  <Plus className="h-4 w-4" /> Add Team Member
                </button>
              ) : (
                <span className="text-xs text-amber-700 bg-amber-50 px-3 py-1.5 rounded-full border border-amber-200">
                  Editor role: Read-only access to team management
                </span>
              )}
            </div>

            {/* Factual Disclaimer Banner */}
            <div className="p-4 rounded-3xl bg-blue-50/60 border border-blue-100 text-xs text-blue-900 leading-relaxed">
              <span className="font-bold">Factual Accuracy Notice:</span> As per official company policy, team member profiles are only published when verified details (name, designation, bio, and official channels) are submitted by leadership.
            </div>

            {/* ==================== MAIN TEAM PHOTO MANAGEMENT CARD ==================== */}
            <div className="p-6 rounded-3xl bg-gradient-to-br from-neutral-50 via-white to-orange-50/30 border border-neutral-200/90 shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-brand-100 text-brand-700 text-[10px] font-bold uppercase tracking-wider">
                    CMS Managed Showcase
                  </div>
                  <h3 className="font-display font-bold text-base text-neutral-900 mt-1">Main Team Photo (Showcase)</h3>
                  <p className="text-xs text-neutral-500">
                    Large cinematic team photograph displayed on the public Team page. Upload or replace dynamically.
                  </p>
                </div>
                {activeRole !== 'editor' && (
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-neutral-900 hover:bg-black text-white text-xs font-semibold shadow-xs transition">
                      <Upload className="h-3.5 w-3.5 text-orange-400" />
                      <span>Upload Team Photo</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0]
                          if (!file) return
                          if (file.size > 5 * 1024 * 1024) {
                            toast.error('Image must be under 5MB')
                            return
                          }
                          const reader = new FileReader()
                          reader.onload = (ev) => {
                            const dataUrl = ev.target?.result
                            if (dataUrl) {
                              setSettingsForm((prev) => ({ ...prev, teamPhoto: dataUrl }))
                              toast.success(`Loaded team photo "${file.name}". Click "Save Team Photo" to publish!`)
                            }
                          }
                          reader.readAsDataURL(file)
                        }}
                      />
                    </label>
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          const res = await authFetch('/api/settings', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(settingsForm),
                          })
                          const data = await res.json()
                          if (data?.ok) {
                            toast.success('Main Team Photo saved and published!')
                            fetchData()
                          } else {
                            toast.error(data?.error || 'Failed to save')
                          }
                        } catch {
                          toast.error('Network error saving team photo')
                        }
                      }}
                      className="px-4 py-1.5 rounded-full bg-brand-500 hover:bg-brand-600 text-white text-xs font-semibold shadow-xs transition"
                    >
                      Save Team Photo
                    </button>
                  </div>
                )}
              </div>

              <div className="grid md:grid-cols-3 gap-4 items-center">
                <div className="md:col-span-2 relative aspect-[21/9] sm:aspect-[16/7] rounded-2xl overflow-hidden border border-neutral-200 bg-neutral-900 shadow-inner group">
                  {settingsForm.teamPhoto ? (
                    <img
                      src={settingsForm.teamPhoto}
                      alt={settingsForm.teamPhotoAlt || 'Olive Orange Technologies Team'}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex flex-col items-center justify-center text-neutral-400 p-6 text-center">
                      <Users className="h-8 w-8 mb-2 text-neutral-500" />
                      <span className="text-xs">No team photo uploaded yet</span>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent flex items-end p-4">
                    <span className="text-white text-xs font-medium">
                      {settingsForm.teamPhotoAlt || 'Olive Orange Technologies Engineering Collective'}
                    </span>
                  </div>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-neutral-700 mb-1">Image URL / Data URI</label>
                    <input
                      type="text"
                      value={settingsForm.teamPhoto || ''}
                      onChange={(e) => setSettingsForm({ ...settingsForm, teamPhoto: e.target.value })}
                      placeholder="https://... or upload from device above"
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-neutral-200 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-neutral-700 mb-1">Photo Description / Alt Text</label>
                    <input
                      type="text"
                      value={settingsForm.teamPhotoAlt || ''}
                      onChange={(e) => setSettingsForm({ ...settingsForm, teamPhotoAlt: e.target.value })}
                      placeholder="Olive Orange Technologies engineering and operations team"
                      className="w-full px-3 py-1.5 text-xs rounded-xl border border-neutral-200 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>

            {team.length === 0 ? (
              <div className="p-12 text-center rounded-3xl bg-white border border-neutral-200/80 shadow-sm max-w-xl mx-auto">
                <Users className="h-10 w-10 text-neutral-300 mx-auto mb-3" />
                <h3 className="font-display font-bold text-base text-neutral-900">No Team Profiles Added Yet</h3>
                <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
                  The team database is currently unseeded to ensure zero fictitious staff personas. Add real personnel when details are provided.
                </p>
                {activeRole !== 'editor' && (
                  <button
                    onClick={openNewTeamMember}
                    className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 rounded-full bg-brand-500 text-white text-xs font-semibold hover:bg-brand-600 transition"
                  >
                    <Plus className="h-3.5 w-3.5" /> Add First Verified Member
                  </button>
                )}
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {team.map((m) => (
                  <div
                    key={m.id}
                    className="rounded-3xl bg-white p-5 border border-neutral-200/80 shadow-sm flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-neutral-400 font-mono">Order: #{m.displayOrder}</span>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${m.isActive ? 'bg-emerald-50 text-emerald-700' : 'bg-neutral-100 text-neutral-500'}`}>
                          {m.isActive ? 'Active' : 'Hidden'}
                        </span>
                      </div>
                      <div className="mt-3 flex items-center gap-3">
                        {m.profileImage ? (
                          <div className="h-14 w-14 rounded-2xl overflow-hidden bg-neutral-100 border border-neutral-200 shrink-0">
                            <img src={m.profileImage} alt={m.name} className="w-full h-full object-cover" />
                          </div>
                        ) : (
                          <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-brand-500 to-brand-600 text-white flex items-center justify-center font-bold text-base shadow-sm shrink-0">
                            {m.name.split(' ').map((n) => n[0]).join('')}
                          </div>
                        )}
                        <div>
                          <h3 className="font-display font-bold text-base text-neutral-900">{m.name}</h3>
                          <p className="text-xs text-brand-600 font-medium">{m.designation}</p>
                          {m.linkedin && (
                            <a
                              href={m.linkedin}
                              target="_blank"
                              rel="noreferrer"
                              className="text-blue-600 hover:text-blue-800 text-[11px] inline-flex items-center gap-1 font-medium mt-0.5"
                            >
                              <Linkedin className="h-3 w-3" /> LinkedIn
                            </a>
                          )}
                        </div>
                      </div>
                      {m.bio && <p className="text-xs text-neutral-500 mt-3 line-clamp-3 leading-relaxed">{m.bio}</p>}
                    </div>

                    <div className="mt-5 pt-3 border-t border-neutral-100 flex items-center justify-between text-xs">
                      <div className="text-neutral-400 truncate max-w-[150px]">{m.email || 'No email published'}</div>
                      {activeRole !== 'editor' && (
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => openEditTeamMember(m)}
                            className="p-1.5 rounded-lg hover:bg-neutral-100 text-neutral-600"
                            title="Edit"
                          >
                            <Edit className="h-3.5 w-3.5" />
                          </button>
                          <button
                            onClick={() => handleDeleteTeam(m)}
                            className="p-1.5 rounded-lg hover:bg-red-50 text-neutral-400 hover:text-red-600"
                            title="Delete"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ==================== TAB 5: MEDIA LIBRARY (MODULE 5) ==================== */}
        {activeTab === 'media' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="font-display font-bold text-xl text-neutral-900">Media &amp; Assets System</h2>
                <p className="text-xs text-neutral-500">Centralized media references, image URLs, alt text and metadata.</p>
              </div>
              <button
                onClick={() => setMediaModal(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-brand-500 hover:bg-brand-600 text-white text-xs font-semibold shadow-glow transition self-start sm:self-auto"
              >
                <Plus className="h-4 w-4" /> Add Media Asset
              </button>
            </div>

            {/* Architecture Report Card */}
            <div className="p-4 rounded-3xl bg-neutral-900 text-neutral-200 border border-neutral-800 text-xs leading-relaxed flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
              <div>
                <span className="font-bold text-brand-400">Architecture Report (Google Cloud Run / Serverless):</span>
                <p className="text-neutral-400 mt-1">
                  Local container filesystems are ephemeral. Storing binary assets directly on disk is not production-safe across multi-instance scale-outs. The recommended production architecture is Google Cloud Storage (GCS) or S3 object store, with public CDN URLs and metadata managed here in the CMS.
                </p>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {media.map((item) => (
                <div
                  key={item.id}
                  className="group rounded-3xl bg-white border border-neutral-200/80 shadow-sm overflow-hidden flex flex-col justify-between"
                >
                  <div className="relative aspect-[16/10] bg-neutral-100 overflow-hidden">
                    <img
                      src={item.url}
                      alt={item.altText || item.fileName}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                    />
                  </div>
                  <div className="p-4">
                    <div className="font-semibold text-xs text-neutral-900 truncate" title={item.fileName}>
                      {item.fileName}
                    </div>
                    <p className="text-[11px] text-neutral-500 mt-1 line-clamp-2" title={item.altText}>
                      Alt: {item.altText}
                    </p>
                    <div className="mt-3 pt-3 border-t border-neutral-100 flex items-center justify-between text-[11px] text-neutral-400">
                      <span>{(item.size / 1024).toFixed(0)} KB</span>
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            navigator.clipboard.writeText(item.url)
                            toast.success('Media URL copied!')
                          }}
                          className="p-1 rounded-md hover:bg-neutral-100 text-neutral-600"
                          title="Copy URL"
                        >
                          <Copy className="h-3 w-3" />
                        </button>
                        <button
                          onClick={() => handleDeleteMedia(item)}
                          className="p-1 rounded-md hover:bg-red-50 text-neutral-400 hover:text-red-600"
                          title="Delete"
                        >
                          <Trash2 className="h-3 w-3" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ==================== TAB 6: WEBSITE SETTINGS (MODULE 4) ==================== */}
        {activeTab === 'settings' && (
          <div className="space-y-6 max-w-4xl">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-display font-bold text-xl text-neutral-900">Centralized Website Settings</h2>
                <p className="text-xs text-neutral-500">
                  Strictly factual Olive Orange Technologies information. Super Admin access only.
                </p>
              </div>
              {activeRole !== 'super_admin' && (
                <span className="text-xs text-red-700 bg-red-50 px-3 py-1 rounded-full border border-red-200 font-semibold flex items-center gap-1">
                  <Lock className="h-3 w-3" /> Read-Only for {activeRoleMeta?.label}
                </span>
              )}
            </div>

            <form onSubmit={handleSaveSettings} className="p-8 rounded-3xl bg-white border border-neutral-200/80 shadow-sm space-y-6">
              <div className="grid sm:grid-cols-2 gap-5">
                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1.5">Company Name</label>
                  <input
                    type="text"
                    disabled={activeRole !== 'super_admin'}
                    value={settingsForm.companyName}
                    onChange={(e) => setSettingsForm({ ...settingsForm, companyName: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-200 focus:outline-none focus:border-brand-500 disabled:bg-neutral-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1.5">Official Tagline</label>
                  <input
                    type="text"
                    disabled={activeRole !== 'super_admin'}
                    value={settingsForm.tagline}
                    onChange={(e) => setSettingsForm({ ...settingsForm, tagline: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-200 focus:outline-none focus:border-brand-500 disabled:bg-neutral-100"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-neutral-700 mb-1.5">Brand Positioning</label>
                  <input
                    type="text"
                    disabled={activeRole !== 'super_admin'}
                    value={settingsForm.positioning}
                    onChange={(e) => setSettingsForm({ ...settingsForm, positioning: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-200 focus:outline-none focus:border-brand-500 disabled:bg-neutral-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1.5">Official Phone</label>
                  <input
                    type="text"
                    disabled={activeRole !== 'super_admin'}
                    value={settingsForm.phone}
                    onChange={(e) => setSettingsForm({ ...settingsForm, phone: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-200 focus:outline-none focus:border-brand-500 disabled:bg-neutral-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1.5">Official WhatsApp Number</label>
                  <input
                    type="text"
                    disabled={activeRole !== 'super_admin'}
                    value={settingsForm.whatsapp}
                    onChange={(e) => setSettingsForm({ ...settingsForm, whatsapp: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-200 focus:outline-none focus:border-brand-500 disabled:bg-neutral-100"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold text-neutral-700 mb-1.5">Official Email</label>
                  <input
                    type="email"
                    disabled={activeRole !== 'super_admin'}
                    value={settingsForm.email}
                    onChange={(e) => setSettingsForm({ ...settingsForm, email: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-200 focus:outline-none focus:border-brand-500 disabled:bg-neutral-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1.5">Instagram URL</label>
                  <input
                    type="url"
                    disabled={activeRole !== 'super_admin'}
                    value={settingsForm.instagram}
                    onChange={(e) => setSettingsForm({ ...settingsForm, instagram: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-200 focus:outline-none focus:border-brand-500 disabled:bg-neutral-100"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1.5">Facebook URL</label>
                  <input
                    type="url"
                    disabled={activeRole !== 'super_admin'}
                    value={settingsForm.facebook}
                    onChange={(e) => setSettingsForm({ ...settingsForm, facebook: e.target.value })}
                    className="w-full px-3.5 py-2 text-xs rounded-xl border border-neutral-200 focus:outline-none focus:border-brand-500 disabled:bg-neutral-100"
                  />
                </div>
              </div>

              {activeRole === 'super_admin' && (
                <div className="pt-4 border-t border-neutral-100 flex justify-end">
                  <button
                    type="submit"
                    disabled={savingSettings}
                    className="px-6 py-2.5 rounded-full bg-brand-500 hover:bg-brand-600 text-white text-xs font-semibold shadow-glow transition disabled:opacity-50"
                  >
                    {savingSettings ? 'Saving...' : 'Save Settings'}
                  </button>
                </div>
              )}
            </form>
          </div>
        )}

        {/* ==================== TAB 7: LEADS CRM ==================== */}
        {activeTab === 'leads' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h2 className="font-display font-bold text-xl text-neutral-900">Inbound Leads CRM</h2>
                <p className="text-xs text-neutral-500">Track demo requests, consultation inquiries, and game scores.</p>
              </div>
              {activeRole !== 'editor' ? (
                <button
                  onClick={handleExportCSV}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold rounded-full bg-neutral-900 text-white hover:bg-black transition self-start sm:self-auto"
                >
                  <Download className="h-3.5 w-3.5" /> Export CSV
                </button>
              ) : (
                <span className="text-xs text-red-600 bg-red-50 px-3 py-1.5 rounded-full border border-red-200 font-semibold">
                  Editor role forbidden from viewing customer leads
                </span>
              )}
            </div>

            {activeRole === 'editor' ? (
              <div className="p-12 text-center rounded-3xl bg-white border border-neutral-200 text-neutral-500 text-sm">
                <Lock className="h-8 w-8 text-neutral-400 mx-auto mb-2" />
                Access Restricted: Editors cannot access or manage inbound customer leads. Switch role to Admin or Super Admin to view.
              </div>
            ) : (
              <div className="rounded-3xl bg-white border border-neutral-200/80 shadow-sm overflow-hidden">
                <div className="p-4 border-b border-neutral-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                  <div className="relative w-full sm:w-72">
                    <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-neutral-400" />
                    <input
                      type="text"
                      placeholder="Search leads by name, email, phone…"
                      value={searchLead}
                      onChange={(e) => setSearchLead(e.target.value)}
                      className="w-full pl-9 pr-3 py-1.5 rounded-xl border border-neutral-200 text-xs focus:outline-none"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <select
                      value={leadStatusFilter}
                      onChange={(e) => setLeadStatusFilter(e.target.value)}
                      className="px-3 py-1.5 rounded-xl border border-neutral-200 bg-white text-xs"
                    >
                      <option value="all">All Statuses</option>
                      <option value="new">New</option>
                      <option value="contacted">Contacted</option>
                      <option value="qualified">Qualified</option>
                      <option value="closed_won">Closed Won</option>
                    </select>
                  </div>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-neutral-50 border-b border-neutral-200 text-neutral-500 font-semibold uppercase tracking-wider">
                      <tr>
                        <th className="py-3 px-4">Contact</th>
                        <th className="py-3 px-4">Type</th>
                        <th className="py-3 px-4">Status</th>
                        <th className="py-3 px-4">Date</th>
                        <th className="py-3 px-4 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-neutral-100">
                      {filteredLeads.length === 0 ? (
                        <tr>
                          <td colSpan="5" className="py-12 text-center text-neutral-400">
                            No leads captured yet. Submissions from Demo Modal, Contact Form, and Business Health Game will populate here.
                          </td>
                        </tr>
                      ) : (
                        filteredLeads.map((lead) => (
                          <tr key={lead.id} className="hover:bg-neutral-50/60 transition">
                            <td className="py-3 px-4">
                              <div className="font-semibold text-neutral-900">{lead.name || 'Anonymous User'}</div>
                              <div className="text-[11px] text-neutral-400">{lead.email} · {lead.phone}</div>
                            </td>
                            <td className="py-3 px-4">
                              <span className="px-2 py-0.5 rounded-full bg-neutral-100 text-neutral-600 font-medium">
                                {lead.type}
                              </span>
                            </td>
                            <td className="py-3 px-4">
                              <select
                                value={lead.status || 'new'}
                                onChange={(e) => handleUpdateLeadStatus(lead.id, e.target.value)}
                                className={`px-2.5 py-1 rounded-full text-[11px] font-semibold border ${STATUS_COLORS[lead.status] || STATUS_COLORS.new}`}
                              >
                                <option value="new">New</option>
                                <option value="contacted">Contacted</option>
                                <option value="qualified">Qualified</option>
                                <option value="closed_won">Closed Won</option>
                                <option value="archived">Archived</option>
                              </select>
                            </td>
                            <td className="py-3 px-4 text-neutral-500 whitespace-nowrap">
                              {lead.createdAt?.split('T')[0]}
                            </td>
                            <td className="py-3 px-4 text-right">
                              <button
                                onClick={() => handleDeleteLead(lead.id)}
                                className="p-1 rounded-lg hover:bg-red-50 text-neutral-400 hover:text-red-600"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* ==================== MODAL 1: BLOG POST EDITOR ==================== */}
      <AnimatePresence>
        {postModal.open && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs overflow-y-auto">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-4xl max-h-[90vh] bg-white rounded-3xl shadow-2xl border border-neutral-200 overflow-hidden flex flex-col"
            >
              <div className="p-5 border-b border-neutral-100 flex items-center justify-between bg-neutral-50">
                <div>
                  <h3 className="font-display font-bold text-lg text-neutral-900">
                    {postModal.isEdit ? 'Edit Blog Post' : 'Create New Blog Post'}
                  </h3>
                  <p className="text-xs text-neutral-500">Configure content, category, AEO takeaways, and SEO tags.</p>
                </div>
                <button
                  onClick={() => setPostModal({ open: false, isEdit: false, targetSlug: '' })}
                  className="p-2 rounded-full hover:bg-neutral-200 transition"
                >
                  <XIcon className="h-4 w-4" />
                </button>
              </div>

              <form onSubmit={handleSavePost} className="p-6 overflow-y-auto space-y-6 text-xs flex-1">
                {/* Basic Info */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block font-semibold text-neutral-700 mb-1">
                      Article Title <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. How AI Is Quietly Transforming Indian Businesses"
                      value={postForm.title}
                      onChange={(e) => handleTitleChange(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-neutral-200 text-sm focus:outline-none focus:border-brand-500"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">
                      Unique Slug <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="ai-transforming-indian-businesses"
                      value={postForm.slug}
                      onChange={(e) => setPostForm({ ...postForm, slug: slugify(e.target.value) })}
                      className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 font-mono text-xs focus:outline-none focus:border-brand-500"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">Category</label>
                    <select
                      value={postForm.category}
                      onChange={(e) => setPostForm({ ...postForm, category: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 bg-white text-xs focus:outline-none"
                    >
                      {categories.map((c) => (
                        <option key={c.slug} value={c.name}>{c.name}</option>
                      ))}
                    </select>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block font-semibold text-neutral-700 mb-1">
                      Excerpt / Summary <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      rows={2}
                      required
                      placeholder="Brief 1-2 sentence overview for cards and meta description..."
                      value={postForm.excerpt}
                      onChange={(e) => setPostForm({ ...postForm, excerpt: e.target.value, metaDescription: e.target.value.slice(0, 160) })}
                      className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none focus:border-brand-500 leading-relaxed"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block font-semibold text-neutral-700 mb-1">
                      Article Content (Separate paragraphs with double enter)
                    </label>
                    <textarea
                      rows={8}
                      placeholder="Write your article paragraphs here. Double line break creates a new paragraph..."
                      value={postForm.content}
                      onChange={(e) => setPostForm({ ...postForm, content: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 text-xs font-sans leading-relaxed focus:outline-none focus:border-brand-500"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">Featured Article Image</label>
                    <div className="space-y-2">
                      <input
                        type="text"
                        placeholder="Paste image URL (https://images.unsplash.com/... or any web link)"
                        value={postForm.featuredImage}
                        onChange={(e) => setPostForm({ ...postForm, featuredImage: e.target.value, ogImage: e.target.value })}
                        className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none focus:border-brand-500"
                      />
                      
                      <div className="flex flex-wrap items-center gap-2">
                        <label className="cursor-pointer inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-800 font-semibold text-[11px] transition">
                          <Upload className="h-3.5 w-3.5 text-brand-600" />
                          <span>Upload from Computer / Mobile</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0]
                              if (!file) return
                              if (file.size > 5 * 1024 * 1024) {
                                toast.error('Image size must be under 5MB')
                                return
                              }
                              const reader = new FileReader()
                              reader.onload = (ev) => {
                                const dataUrl = ev.target?.result
                                if (dataUrl) {
                                  setPostForm((prev) => ({
                                    ...prev,
                                    featuredImage: dataUrl,
                                    ogImage: dataUrl,
                                    imageAltText: prev.imageAltText || file.name.replace(/\.[^/.]+$/, ''),
                                  }))
                                  toast.success(`Photo "${file.name}" loaded successfully!`)
                                }
                              }
                              reader.readAsDataURL(file)
                            }}
                          />
                        </label>

                        {media.length > 0 && (
                          <select
                            className="px-2.5 py-1.5 rounded-lg border border-neutral-200 bg-white text-neutral-700 text-[11px] font-medium focus:outline-none"
                            onChange={(e) => {
                              if (e.target.value) {
                                setPostForm((prev) => ({ ...prev, featuredImage: e.target.value, ogImage: e.target.value }))
                              }
                            }}
                            defaultValue=""
                          >
                            <option value="" disabled>Choose from Media Library ({media.length})</option>
                            {media.map((m) => (
                              <option key={m.id} value={m.url}>{m.fileName || m.altText || m.url.slice(0, 35)}</option>
                            ))}
                          </select>
                        )}
                      </div>

                      {postForm.featuredImage && (
                        <div className="mt-2.5 relative aspect-[16/9] w-56 rounded-2xl overflow-hidden border border-neutral-200 bg-neutral-100 shadow-xs">
                          <img
                            src={postForm.featuredImage}
                            alt="Preview"
                            className="w-full h-full object-cover"
                            onError={(e) => { e.currentTarget.src = 'https://images.unsplash.com/photo-1652156752342-c786f1e1d1ce?w=400&auto=format&fit=crop&q=80' }}
                          />
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">Image Alt Text</label>
                    <input
                      type="text"
                      placeholder="Descriptive text for accessibility & image search"
                      value={postForm.imageAltText}
                      onChange={(e) => setPostForm({ ...postForm, imageAltText: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">Author</label>
                    <input
                      type="text"
                      value={postForm.author}
                      onChange={(e) => setPostForm({ ...postForm, author: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">Status</label>
                    <select
                      value={postForm.status}
                      onChange={(e) => setPostForm({ ...postForm, status: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 bg-white text-xs font-semibold focus:outline-none"
                    >
                      <option value="draft">Draft (Private, not public)</option>
                      <option value="published">Published (Visible on public /blog)</option>
                    </select>
                  </div>
                </div>

                {/* AEO / GEO Section */}
                <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-3">
                  <div className="font-bold text-brand-700 flex items-center gap-1.5">
                    <Sparkles className="h-4 w-4" /> AEO / GEO Content Structure
                  </div>
                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">
                      Key Takeaways (One per line)
                    </label>
                    <textarea
                      rows={3}
                      placeholder="Takeaway 1&#10;Takeaway 2&#10;Takeaway 3"
                      value={postForm.keyTakeawaysText}
                      onChange={(e) => setPostForm({ ...postForm, keyTakeawaysText: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">
                      Structured FAQs (Format: Q: Question \n A: Answer, separated by double line break)
                    </label>
                    <textarea
                      rows={4}
                      placeholder="Q: What is this solution?&#10;A: It is an automated workflow system.&#10;&#10;Q: How long to implement?&#10;A: Typically 2 to 4 weeks."
                      value={postForm.faqsText}
                      onChange={(e) => setPostForm({ ...postForm, faqsText: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs font-mono"
                    />
                  </div>
                </div>

                {/* SEO Metadata Accordion */}
                <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-3">
                  <div className="font-bold text-neutral-800 flex items-center gap-1.5">
                    <Globe className="h-4 w-4 text-brand-500" /> SEO, Canonical &amp; OpenGraph
                  </div>
                  <div className="grid sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold text-neutral-700 mb-1">Meta Title</label>
                      <input
                        type="text"
                        value={postForm.metaTitle}
                        onChange={(e) => setPostForm({ ...postForm, metaTitle: e.target.value })}
                        className="w-full px-3 py-1.5 rounded-xl border border-neutral-200 text-xs"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold text-neutral-700 mb-1">Canonical URL</label>
                      <input
                        type="url"
                        placeholder={`https://oliveorangetech.in/blog/${postForm.slug || 'slug'}`}
                        value={postForm.canonicalUrl}
                        onChange={(e) => setPostForm({ ...postForm, canonicalUrl: e.target.value })}
                        className="w-full px-3 py-1.5 rounded-xl border border-neutral-200 text-xs font-mono"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <label className="block font-semibold text-neutral-700 mb-1">Meta Description (120-160 chars)</label>
                      <textarea
                        rows={2}
                        value={postForm.metaDescription}
                        onChange={(e) => setPostForm({ ...postForm, metaDescription: e.target.value })}
                        className="w-full px-3 py-1.5 rounded-xl border border-neutral-200 text-xs"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-neutral-100 flex items-center justify-between">
                  <button
                    type="button"
                    onClick={() => setPostModal({ open: false, isEdit: false, targetSlug: '' })}
                    className="px-4 py-2 rounded-full border border-neutral-200 text-neutral-600 hover:bg-neutral-50 font-semibold"
                  >
                    Cancel
                  </button>
                  <div className="flex items-center gap-2">
                    <button
                      type="submit"
                      disabled={savingPost}
                      className="px-6 py-2.5 rounded-full bg-brand-500 hover:bg-brand-600 text-white font-semibold shadow-glow transition disabled:opacity-50"
                    >
                      {savingPost ? 'Saving...' : postModal.isEdit ? 'Update Article' : 'Save Article'}
                    </button>
                  </div>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ==================== MODAL 2: CATEGORY EDITOR ==================== */}
      <AnimatePresence>
        {catModal.open && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-neutral-200 overflow-hidden"
            >
              <div className="p-5 border-b border-neutral-100 flex items-center justify-between bg-neutral-50">
                <h3 className="font-display font-bold text-base text-neutral-900">
                  {catModal.isEdit ? 'Edit Category' : 'Create Category'}
                </h3>
                <button onClick={() => setCatModal({ open: false, isEdit: false, targetSlug: '' })}>
                  <XIcon className="h-4 w-4" />
                </button>
              </div>

              <form onSubmit={handleSaveCategory} className="p-6 space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">Category Name *</label>
                  <input
                    type="text"
                    required
                    value={catForm.name}
                    onChange={(e) => setCatForm({ ...catForm, name: e.target.value, slug: !catModal.isEdit ? slugify(e.target.value) : catForm.slug })}
                    className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 text-sm focus:outline-none focus:border-brand-500"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">Slug *</label>
                  <input
                    type="text"
                    required
                    value={catForm.slug}
                    onChange={(e) => setCatForm({ ...catForm, slug: slugify(e.target.value) })}
                    className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 font-mono text-xs focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">Description</label>
                  <textarea
                    rows={3}
                    value={catForm.description}
                    onChange={(e) => setCatForm({ ...catForm, description: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none"
                  />
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <input
                    type="checkbox"
                    id="catActive"
                    checked={catForm.active}
                    onChange={(e) => setCatForm({ ...catForm, active: e.target.checked })}
                    className="rounded text-brand-500 focus:ring-brand-500 h-4 w-4"
                  />
                  <label htmlFor="catActive" className="text-neutral-700 font-medium">Active (Visible in public filters)</label>
                </div>

                <div className="pt-4 border-t border-neutral-100 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setCatModal({ open: false, isEdit: false, targetSlug: '' })}
                    className="px-4 py-2 rounded-full border border-neutral-200 text-neutral-600 hover:bg-neutral-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={savingCat}
                    className="px-5 py-2 rounded-full bg-brand-500 hover:bg-brand-600 text-white font-semibold transition disabled:opacity-50"
                  >
                    {savingCat ? 'Saving...' : 'Save Category'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ==================== MODAL 3: TEAM MEMBER EDITOR ==================== */}
      <AnimatePresence>
        {teamModal.open && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-neutral-200 overflow-hidden"
            >
              <div className="p-5 border-b border-neutral-100 flex items-center justify-between bg-neutral-50">
                <h3 className="font-display font-bold text-base text-neutral-900">
                  {teamModal.isEdit ? 'Edit Team Member' : 'Add Verified Team Member'}
                </h3>
                <button onClick={() => setTeamModal({ open: false, isEdit: false, targetId: '' })}>
                  <XIcon className="h-4 w-4" />
                </button>
              </div>

              <form onSubmit={handleSaveTeam} className="p-6 space-y-4 text-xs">
                {/* Profile Image Upload & Preview */}
                <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="block font-semibold text-neutral-800">Profile Photo</label>
                    <label className="cursor-pointer inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white border border-neutral-200 hover:bg-neutral-100 text-neutral-700 font-semibold text-[11px] shadow-2xs transition">
                      <Upload className="h-3 w-3 text-brand-600" />
                      <span>Upload from Device</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0]
                          if (!file) return
                          if (file.size > 5 * 1024 * 1024) {
                            toast.error('Image must be under 5MB')
                            return
                          }
                          const reader = new FileReader()
                          reader.onload = (ev) => {
                            const dataUrl = ev.target?.result
                            if (dataUrl) {
                              setTeamForm((prev) => ({ ...prev, profileImage: dataUrl }))
                              toast.success(`Photo "${file.name}" loaded!`)
                            }
                          }
                          reader.readAsDataURL(file)
                        }}
                      />
                    </label>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="h-14 w-14 rounded-2xl overflow-hidden bg-neutral-200 border border-neutral-300 shrink-0 relative flex items-center justify-center">
                      {teamForm.profileImage ? (
                        <img src={teamForm.profileImage} alt="Preview" className="w-full h-full object-cover" />
                      ) : (
                        <span className="font-bold text-neutral-500 text-base">
                          {teamForm.name ? teamForm.name.charAt(0) : 'O'}
                        </span>
                      )}
                    </div>
                    <div className="flex-1 space-y-1">
                      <input
                        type="text"
                        placeholder="https://... or upload from device above"
                        value={teamForm.profileImage || ''}
                        onChange={(e) => setTeamForm({ ...teamForm, profileImage: e.target.value })}
                        className="w-full px-3 py-1.5 rounded-xl border border-neutral-200 text-xs focus:outline-none bg-white"
                      />
                      {teamForm.profileImage && (
                        <button
                          type="button"
                          onClick={() => setTeamForm({ ...teamForm, profileImage: '' })}
                          className="text-[11px] text-red-600 hover:underline inline-block"
                        >
                          Remove photo
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">Full Name *</label>
                    <input
                      type="text"
                      required
                      value={teamForm.name}
                      onChange={(e) => setTeamForm({ ...teamForm, name: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">Designation *</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Lead Solutions Architect"
                      value={teamForm.designation}
                      onChange={(e) => setTeamForm({ ...teamForm, designation: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block font-semibold text-neutral-700 mb-1">Bio (Factual only)</label>
                    <textarea
                      rows={3}
                      placeholder="Professional background and domain focus..."
                      value={teamForm.bio}
                      onChange={(e) => setTeamForm({ ...teamForm, bio: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">Email (Only if provided)</label>
                    <input
                      type="email"
                      value={teamForm.email}
                      onChange={(e) => setTeamForm({ ...teamForm, email: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">LinkedIn URL</label>
                    <input
                      type="url"
                      placeholder="https://linkedin.com/in/..."
                      value={teamForm.linkedin}
                      onChange={(e) => setTeamForm({ ...teamForm, linkedin: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">Display Order</label>
                    <input
                      type="number"
                      min={1}
                      value={teamForm.displayOrder}
                      onChange={(e) => setTeamForm({ ...teamForm, displayOrder: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none"
                    />
                  </div>

                  <div className="flex items-center gap-2 pt-6">
                    <input
                      type="checkbox"
                      id="teamActive"
                      checked={teamForm.isActive}
                      onChange={(e) => setTeamForm({ ...teamForm, isActive: e.target.checked })}
                      className="rounded text-brand-500 focus:ring-brand-500 h-4 w-4"
                    />
                    <label htmlFor="teamActive" className="text-neutral-700 font-medium">Active Profile</label>
                  </div>
                </div>

                <div className="pt-4 border-t border-neutral-100 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setTeamModal({ open: false, isEdit: false, targetId: '' })}
                    className="px-4 py-2 rounded-full border border-neutral-200 text-neutral-600 hover:bg-neutral-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={savingTeam}
                    className="px-5 py-2 rounded-full bg-brand-500 hover:bg-brand-600 text-white font-semibold transition disabled:opacity-50"
                  >
                    {savingTeam ? 'Saving...' : 'Save Profile'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ==================== MODAL 4: MEDIA ADD ==================== */}
      <AnimatePresence>
        {mediaModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-neutral-200 overflow-hidden"
            >
              <div className="p-5 border-b border-neutral-100 flex items-center justify-between bg-neutral-50">
                <h3 className="font-display font-bold text-base text-neutral-900">Register Media Asset</h3>
                <button onClick={() => setMediaModal(false)}>
                  <XIcon className="h-4 w-4" />
                </button>
              </div>

              <form onSubmit={handleAddMedia} className="p-6 space-y-4 text-xs">
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="block font-semibold text-neutral-700">Image Asset Source *</label>
                    <label className="cursor-pointer inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-800 font-semibold text-[11px] transition">
                      <Upload className="h-3 w-3 text-brand-600" />
                      <span>Upload from Device</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0]
                          if (!file) return
                          if (file.size > 5 * 1024 * 1024) {
                            toast.error('Image size must be under 5MB')
                            return
                          }
                          const reader = new FileReader()
                          reader.onload = (ev) => {
                            const dataUrl = ev.target?.result
                            if (dataUrl) {
                              setMediaForm({
                                url: dataUrl,
                                fileName: file.name,
                                altText: file.name.replace(/\.[^/.]+$/, ''),
                              })
                              toast.success(`Photo "${file.name}" loaded!`)
                            }
                          }
                          reader.readAsDataURL(file)
                        }}
                      />
                    </label>
                  </div>
                  <input
                    type="text"
                    required
                    placeholder="https://images.unsplash.com/photo-... or upload file above"
                    value={mediaForm.url}
                    onChange={(e) => setMediaForm({ ...mediaForm, url: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none focus:border-brand-500"
                  />
                  {mediaForm.url && (
                    <div className="mt-2.5 relative aspect-[16/9] w-48 rounded-xl overflow-hidden border border-neutral-200 bg-neutral-50 shadow-xs">
                      <img
                        src={mediaForm.url}
                        alt="Preview"
                        className="w-full h-full object-cover"
                        onError={(e) => { e.currentTarget.src = 'https://images.unsplash.com/photo-1652156752342-c786f1e1d1ce?w=400&auto=format&fit=crop&q=80' }}
                      />
                    </div>
                  )}
                </div>

                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">File Name</label>
                  <input
                    type="text"
                    placeholder="ai-dashboard-preview.jpg"
                    value={mediaForm.fileName}
                    onChange={(e) => setMediaForm({ ...mediaForm, fileName: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">Alt Text</label>
                  <input
                    type="text"
                    placeholder="Descriptive image text for search engines and accessibility"
                    value={mediaForm.altText}
                    onChange={(e) => setMediaForm({ ...mediaForm, altText: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl border border-neutral-200 text-xs focus:outline-none"
                  />
                </div>

                <div className="pt-4 border-t border-neutral-100 flex justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setMediaModal(false)}
                    className="px-4 py-2 rounded-full border border-neutral-200 text-neutral-600 hover:bg-neutral-50"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={savingMedia}
                    className="px-5 py-2 rounded-full bg-brand-500 hover:bg-brand-600 text-white font-semibold transition disabled:opacity-50"
                  >
                    {savingMedia ? 'Saving...' : 'Register Asset'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* ==================== MODAL 5: ARTICLE PREVIEW DRAWER ==================== */}
      <AnimatePresence>
        {previewPost && (
          <div className="fixed inset-0 z-[110] flex items-center justify-end bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="w-full max-w-2xl h-full bg-white shadow-2xl border-l border-neutral-200 overflow-y-auto flex flex-col"
            >
              <div className="p-4 border-b border-neutral-100 flex items-center justify-between bg-neutral-50 sticky top-0 z-10">
                <div className="flex items-center gap-2">
                  <span className="font-display font-bold text-sm text-neutral-900">CMS Article Live Preview</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${previewPost.status === 'published' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}`}>
                    {previewPost.status.toUpperCase()}
                  </span>
                </div>
                <button onClick={() => setPreviewPost(null)} className="p-1.5 rounded-full hover:bg-neutral-200">
                  <XIcon className="h-4 w-4" />
                </button>
              </div>

              <div className="p-6 sm:p-8 space-y-6">
                <div>
                  <span className="text-xs text-brand-600 font-bold uppercase tracking-wider">{previewPost.category}</span>
                  <h1 className="font-display font-bold text-2xl sm:text-3xl text-neutral-900 mt-2 leading-tight">
                    {previewPost.title}
                  </h1>
                  <p className="text-neutral-600 text-sm mt-3 leading-relaxed">{previewPost.excerpt}</p>
                </div>

                {previewPost.featuredImage && (
                  <div className="relative aspect-[16/9] rounded-2xl overflow-hidden bg-neutral-100">
                    <img
                      src={previewPost.featuredImage || previewPost.image}
                      alt={previewPost.imageAltText || previewPost.title}
                      className="w-full h-full object-cover"
                      onError={(e) => { e.currentTarget.src = 'https://images.unsplash.com/photo-1652156752342-c786f1e1d1ce?w=800&auto=format&fit=crop&q=80' }}
                    />
                  </div>
                )}

                {/* Takeaways Preview */}
                {previewPost.keyTakeaways && previewPost.keyTakeaways.length > 0 && (
                  <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-200/80">
                    <div className="text-xs font-bold text-brand-700 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                      <BookOpen className="h-3.5 w-3.5" /> AEO Key Takeaways
                    </div>
                    <ul className="space-y-1.5 text-xs text-neutral-700">
                      {previewPost.keyTakeaways.map((t, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="h-1.5 w-1.5 rounded-full bg-brand-500 mt-1.5 shrink-0" />
                          <span>{t}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Body paragraphs */}
                <div className="space-y-4 text-neutral-800 text-sm leading-relaxed">
                  {(Array.isArray(previewPost.content) ? previewPost.content : [previewPost.content]).map((p, idx) => (
                    <p key={idx}>{p}</p>
                  ))}
                </div>

                {/* FAQs Preview */}
                {previewPost.faqs && previewPost.faqs.length > 0 && (
                  <div className="p-5 rounded-2xl bg-neutral-50 border border-neutral-200/80 space-y-3">
                    <div className="text-xs font-bold text-neutral-800 uppercase tracking-wider">
                      Frequently Asked Questions (FAQ Schema Eligible)
                    </div>
                    {previewPost.faqs.map((f, idx) => (
                      <div key={idx} className="text-xs border-b border-neutral-200/60 pb-2 last:border-none">
                        <div className="font-semibold text-neutral-900">{f.q}</div>
                        <div className="text-neutral-600 mt-1">{f.a}</div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Meta Summary */}
                <div className="p-4 rounded-2xl bg-brand-50/40 border border-brand-100 text-xs text-neutral-600 space-y-1">
                  <div><b>Meta Title:</b> {previewPost.metaTitle || previewPost.title}</div>
                  <div><b>Canonical:</b> https://oliveorangetech.in/blog/{previewPost.slug}</div>
                  <div><b>Schema:</b> BlogPosting + BreadcrumbList + FAQPage</div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <FooterCTA />
    </main>
  )
}

'use client'
import { useEffect, useRef, useState } from 'react'
import Image from 'next/image'
import { motion, AnimatePresence } from 'framer-motion'
import { X, Gamepad2, Phone, CalendarClock } from 'lucide-react'

const RANDOM_TIPS = [
  "Psst… try the Business Health game — takes 60 seconds!",
  "Need a CRM demo? I can book it for you in 1 click.",
  "Fun fact: our clients save 12+ hours a week. Wanna know how?",
  "Hey there! I'm OLI — your friendly software guide.",
  "Chat with us on WhatsApp — humans respond in under 2 mins.",
]

/**
 * OLI mascot uses the real 3D image (/brand/oli-mascot.jpg with white bg removed via CSS blend).
 * Behavior:
 *  - Sits in bottom-right always (button)
 *  - Every ~35s, if inactive, OLI "walks" across the bottom of the page (slides in from right, pauses, slides back)
 *  - Sleeps after 45s of no activity (dims + shows Z)
 *  - Speech bubbles show tips randomly
 *  - Confetti on celebrate
 */
export default function OliMascot({ onOpenGame, onOpenDemo }) {
  const [open, setOpen] = useState(false)
  const [bubble, setBubble] = useState(null)
  const [sleeping, setSleeping] = useState(false)
  const [celebrating, setCelebrating] = useState(false)
  const idleTimer = useRef(null)
  const tipTimer = useRef(null)

  // Welcome bubble
  useEffect(() => {
    const t = setTimeout(() => setBubble("Hi, I'm OLI 👋 Ask me anything!"), 1400)
    return () => clearTimeout(t)
  }, [])

  // Random tips
  useEffect(() => {
    tipTimer.current = setInterval(() => {
      if (!open && !sleeping) {
        const tip = RANDOM_TIPS[Math.floor(Math.random() * RANDOM_TIPS.length)]
        setBubble(tip)
        setTimeout(() => setBubble(null), 5000)
      }
    }, 20000)
    return () => clearInterval(tipTimer.current)
  }, [open, sleeping])

  // Inactivity → sleep
  useEffect(() => {
    const reset = () => {
      setSleeping(false)
      clearTimeout(idleTimer.current)
      idleTimer.current = setTimeout(() => setSleeping(true), 45000)
    }
    reset()
    const evs = ['mousemove', 'keydown', 'scroll', 'touchstart']
    evs.forEach(e => window.addEventListener(e, reset))
    return () => { evs.forEach(e => window.removeEventListener(e, reset)); clearTimeout(idleTimer.current) }
  }, [])

  useEffect(() => {
    window.__oliCelebrate = () => {
      setCelebrating(true)
      setBubble("🎉 Yay! You're awesome. We'll be in touch soon!")
      setTimeout(() => setCelebrating(false), 2200)
      setTimeout(() => setBubble(null), 4200)
    }
    return () => { delete window.__oliCelebrate }
  }, [])

  const handleWhatsApp = () => {
    window.open('https://wa.me/919624689335?text=' + encodeURIComponent('Hi Olive Orange team, I want to discuss a digital solution.'), '_blank')
  }

  return (
    <>
      {/* Chat panel — own fixed layer so it never pushes the buttons off-screen on mobile */}
      <div className="fixed bottom-24 sm:bottom-28 left-4 right-4 sm:left-auto sm:right-5 z-[60] flex justify-end pointer-events-none">
        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.9 }}
              transition={{ type: 'spring', stiffness: 260, damping: 22 }}
              className="w-full sm:w-[360px] rounded-3xl bg-white shadow-2xl border border-brand-100 overflow-hidden pointer-events-auto"
            >
              <div className="bg-gradient-to-br from-brand-500 to-brand-600 px-5 py-4 text-white">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 rounded-full bg-white/20 flex items-center justify-center overflow-hidden">
                    <OliImage size={44} />
                  </div>
                  <div>
                    <div className="font-display font-semibold">OLI</div>
                    <div className="text-xs opacity-90">Your Olive Orange guide</div>
                  </div>
                  <button onClick={() => setOpen(false)} className="ml-auto p-1.5 rounded-full hover:bg-white/20"><X className="h-4 w-4" /></button>
                </div>
              </div>
              <div className="p-4 space-y-3">
                <div className="bg-brand-50 text-neutral-800 p-3 rounded-2xl rounded-tl-sm text-sm">
                  Hi! I'm OLI. How can I help you today?
                </div>
                <button onClick={() => { onOpenGame?.(); setOpen(false) }} className="w-full flex items-center gap-3 p-3 rounded-2xl border border-neutral-200 hover:border-brand-500 hover:bg-brand-50 transition text-left">
                  <Gamepad2 className="h-5 w-5 text-brand-500" />
                  <div>
                    <div className="font-medium text-sm">Play Business Health Game</div>
                    <div className="text-xs text-neutral-500">Get your AI score in 60 sec</div>
                  </div>
                </button>
                <button onClick={() => { onOpenDemo?.(); setOpen(false) }} className="w-full flex items-center gap-3 p-3 rounded-2xl border border-neutral-200 hover:border-brand-500 hover:bg-brand-50 transition text-left">
                  <CalendarClock className="h-5 w-5 text-brand-500" />
                  <div>
                    <div className="font-medium text-sm">Book a Free Demo</div>
                    <div className="text-xs text-neutral-500">30-minute walkthrough</div>
                  </div>
                </button>
                <button onClick={handleWhatsApp} className="w-full flex items-center gap-3 p-3 rounded-2xl border border-neutral-200 hover:border-green-500 hover:bg-green-50 transition text-left">
                  <Phone className="h-5 w-5 text-green-600" />
                  <div>
                    <div className="font-medium text-sm">Chat on WhatsApp</div>
                    <div className="text-xs text-neutral-500">+91 96246 89335</div>
                  </div>
                </button>
                <div className="text-xs text-neutral-400 text-center pt-1">Powered by Olive Orange AI</div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="fixed bottom-4 right-4 sm:bottom-5 sm:right-5 z-[60] flex items-end gap-2 sm:gap-3 select-none">
        {/* Speech bubble */}
        <AnimatePresence>
          {bubble && !open && (
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.9 }}
              className="absolute bottom-20 sm:bottom-28 right-16 sm:right-28 max-w-[190px] sm:max-w-[240px] bg-white shadow-xl border border-brand-100 rounded-2xl rounded-br-sm px-4 py-2.5 text-sm text-neutral-800"
            >
              {bubble}
              <div className="absolute -bottom-1.5 right-6 h-3 w-3 bg-white border-r border-b border-brand-100 rotate-45" />
            </motion.div>
          )}
        </AnimatePresence>

        {/* WhatsApp button */}
        <motion.button
          whileHover={{ scale: 1.06 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleWhatsApp}
          aria-label="Chat on WhatsApp"
          className="h-12 w-12 sm:h-14 sm:w-14 rounded-full bg-[#25D366] shadow-glow flex items-center justify-center text-white shrink-0"
        >
          <svg viewBox="0 0 24 24" className="h-6 w-6 sm:h-7 sm:w-7 fill-current"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.198.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.145-.147.32-.381.48-.571.16-.19.213-.328.32-.547.107-.22.053-.41-.025-.571-.079-.16-.7-1.685-.958-2.31-.257-.622-.517-.53-.71-.54-.194-.011-.416-.014-.64-.014-.222 0-.583.083-.887.408-.304.325-1.16 1.133-1.16 2.762 0 1.63 1.185 3.204 1.35 3.428.165.223 2.315 3.53 5.617 4.812.783.302 1.394.483 1.87.618.786.223 1.501.192 2.068.117.63-.084 1.94-.795 2.213-1.564.274-.769.274-1.428.192-1.564-.083-.135-.298-.213-.595-.362zM12.05 21.785h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884M20.52 3.449C18.24 1.245 15.24 0 12.045 0 5.463 0 .073 5.39.07 12.012c0 2.113.55 4.176 1.596 5.988L0 24l6.335-1.661a11.882 11.882 0 0 0 5.71 1.457h.005c6.585 0 11.977-5.39 11.98-12.013a11.955 11.955 0 0 0-3.51-8.334" /></svg>
        </motion.button>

        {/* OLI Mascot */}
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => { setOpen(true); setBubble(null); setSleeping(false) }}
          className="relative h-16 w-16 sm:h-20 sm:w-20 rounded-full bg-white shadow-glow border-2 border-brand-200 overflow-visible idle-bounce shrink-0"
          aria-label="Open OLI chat"
        >
          <div className={`h-full w-full rounded-full overflow-hidden transition ${sleeping ? 'opacity-70 grayscale-[30%]' : ''}`}>
            <OliImage size={76} className="h-full w-full" />
          </div>
          {sleeping && (
            <>
              <span className="absolute -top-1 -right-1 text-brand-600 text-xs font-bold zzz-1">z</span>
              <span className="absolute -top-3 right-1 text-brand-500 text-sm font-bold zzz-2">z</span>
              <span className="absolute -top-5 right-3 text-brand-400 text-base font-bold zzz-3">z</span>
            </>
          )}
          {celebrating && <ConfettiBurst />}
          <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-green-500 border-2 border-white" />
        </motion.button>
      </div>
    </>
  )
}

export function OliImage({ size = 60, className }) {
  if (className) {
    return (
      <div className={`relative ${className}`}>
        <Image src="/brand/oli-mascot.jpg" alt="OLI" fill sizes={`${size}px`} priority className="rounded-full object-cover" style={{ mixBlendMode: 'multiply' }} />
      </div>
    )
  }
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <Image src="/brand/oli-mascot.jpg" alt="OLI" width={size} height={size} priority className="rounded-full object-cover" style={{ mixBlendMode: 'multiply' }} />
    </div>
  )
}

function ConfettiBurst() {
  const pieces = Array.from({ length: 18 })
  const colors = ['#FF7A00', '#FFE9D6', '#556B2F', '#FFB878', '#25D366']
  return (
    <div className="absolute inset-0 pointer-events-none">
      {pieces.map((_, i) => (
        <span
          key={i}
          className="absolute confetti-piece"
          style={{
            left: `${50 + (Math.random() * 60 - 30)}%`,
            top: '50%',
            width: 6, height: 10,
            background: colors[i % colors.length],
            borderRadius: 2,
            animationDelay: `${Math.random() * 0.3}s`,
          }}
        />
      ))}
    </div>
  )
}

'use client'
import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Phone,
  MessageSquare,
  Mail,
  MapPin,
  ArrowRight,
  Sparkles,
  Send,
  Building2,
  Clock,
  ShieldCheck,
  ChevronDown,
  CheckCircle2,
  Globe2,
} from 'lucide-react'
import { toast } from 'sonner'
import HeaderClient from '@/components/HeaderClient'
import FooterCTA from '@/components/FooterCTA'
import DemoModal from '@/components/DemoModal'

export const CONTACT_FAQS = [
  {
    question: 'How do we begin a project consultation with Olive Orange Technologies?',
    answer:
      'We start with a thorough problem discovery session. We analyze your operational friction, existing workflows, and software requirements, then recommend the right digital architecture and delivery scope.',
  },
  {
    question: 'How does WhatsApp Business API integration work with existing systems?',
    answer:
      'We connect directly to official APIs and gateways. Our middleware syncs inbound chat inquiries, automated lead qualification routines, invoice documents, and notifications seamlessly with your database or CRM in real time.',
  },
  {
    question: 'Do we own 100% of our code, customer records, and data schemas?',
    answer:
      'Yes, unconditionally. Olive Orange Technologies operates on complete client sovereignty. You receive full ownership of your proprietary codebases, custom schemas, and private data with zero hidden lock-ins or closed dependencies.',
  },
  {
    question: 'What engagement and pricing models does Olive Orange Technologies support?',
    answer:
      'We offer transparent, outcome-oriented models: (1) Fixed-scope milestone delivery for turn-key applications; (2) Iterative sprint engagements for continuous digital scaling; and (3) Modular tool deployments configured for your specific business requirements.',
  },
  {
    question: 'What support and post-deployment assistance do you provide?',
    answer:
      'Every deployment includes a complimentary hyper-care warranty period, documented onboarding playbooks, and direct support. Ongoing support tiers provide routine maintenance, security patches, and capability updates.',
  },
]

const CAPABILITIES = [
  'Branding & Creative',
  'Website Development',
  'Business Consulting',
  'Digital Marketing',
  'AI Solutions & Automation',
  'Data Analytics',
  'Software Development',
  'AI Visibility & SEO',
  'Support & Maintenance',
  'Business Ecosystem',
  'Mobile App Development',
  'AI Education & Training for Corporate',
]

export default function ContactClient() {
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    company: '',
    service: 'Website Development',
    budget: '₹2L – ₹5L',
    timeline: 'Within 30 Days',
    message: '',
  })
  const [submitting, setSubmitting] = useState(false)
  const [demoOpen, setDemoOpen] = useState(false)
  const [openFaq, setOpenFaq] = useState(null)

  const submit = async (e) => {
    e?.preventDefault()
    if (!form.name || !form.phone) {
      toast.error('Name and phone/WhatsApp number are required')
      return
    }
    setSubmitting(true)
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...form,
          type: 'contact',
        }),
      })
      const data = await res.json()
      if (data?.ok) {
        toast.success('Inquiry received! Our team will contact you shortly.')
        window.__oliCelebrate?.()
        setForm({
          name: '',
          phone: '',
          email: '',
          company: '',
          service: 'Website Development',
          budget: '₹2L – ₹5L',
          timeline: 'Within 30 Days',
          message: '',
        })
      } else {
        toast.error('Failed to submit. Please try again or reach out on WhatsApp.')
      }
    } catch {
      toast.error('Network error. Please call or WhatsApp us directly at +91 96246 89335.')
    }
    setSubmitting(false)
  }

  return (
    <main className="relative bg-white text-neutral-900 overflow-x-hidden">
      <HeaderClient />

      {/* HERO */}
      <section className="relative pt-36 pb-12 sm:pt-44">
        <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-24 -left-24 h-[420px] w-[420px] rounded-full bg-brand-200 opacity-60 blob" />
          <div
            className="absolute top-10 -right-20 h-[520px] w-[520px] rounded-full bg-orange-100 opacity-80 blob"
            style={{ animationDelay: '-4s' }}
          />
          <div className="absolute inset-0 grid-pattern opacity-40" />
        </div>
        <div className="container max-w-5xl mx-auto text-center px-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100 text-brand-700 text-xs font-semibold uppercase tracking-widest">
            <MessageSquare className="h-3.5 w-3.5" /> Direct Contact
          </div>
          <h1 className="font-display text-4xl sm:text-6xl font-bold mt-4 tracking-tight leading-[1.08] text-neutral-900">
            Let’s analyse your business problem and{' '}
            <span className="bg-gradient-to-r from-brand-500 via-orange-500 to-amber-500 bg-clip-text text-transparent">
              build the right solution.
            </span>
          </h1>
          <p className="text-neutral-600 text-lg mt-5 max-w-2xl mx-auto leading-relaxed">
            Every Problem Has A Solution. Connect directly with our solutions team via WhatsApp, phone, or email.
          </p>
        </div>
      </section>

      {/* DIRECT CHANNELS */}
      <section className="pb-14">
        <div className="container max-w-7xl mx-auto px-4 grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <a
            href="tel:+919624689335"
            className="rounded-3xl bg-white border border-neutral-200/80 hover:border-brand-300 shadow-sm p-6 flex flex-col justify-between transition group"
          >
            <div>
              <div className="h-12 w-12 rounded-2xl bg-brand-500 text-white flex items-center justify-center shadow-sm">
                <Phone className="h-6 w-6" />
              </div>
              <h3 className="font-display font-semibold text-lg mt-4 text-neutral-900 group-hover:text-brand-600 transition">
                Call Direct
              </h3>
              <div className="text-neutral-800 text-sm font-semibold mt-1">+91 96246 89335</div>
              <div className="text-neutral-500 text-xs mt-0.5">Direct Voice Assistance</div>
            </div>
            <div className="text-xs text-neutral-400 mt-4 pt-3 border-t border-neutral-100">
              Mon–Sat, 9:00 AM – 8:00 PM IST
            </div>
          </a>

          <a
            href="https://wa.me/919624689335?text=Hello%20Olive%20Orange%20Technologies,%20I%20would%20like%20to%20discuss%20a%20digital%20solution."
            target="_blank"
            rel="noreferrer"
            className="rounded-3xl bg-white border border-neutral-200/80 hover:border-[#25D366] shadow-sm p-6 flex flex-col justify-between transition group"
          >
            <div>
              <div className="h-12 w-12 rounded-2xl bg-[#25D366] text-white flex items-center justify-center shadow-sm">
                <MessageSquare className="h-6 w-6" />
              </div>
              <h3 className="font-display font-semibold text-lg mt-4 text-neutral-900 group-hover:text-[#25D366] transition">
                WhatsApp Business
              </h3>
              <div className="text-neutral-800 text-sm font-semibold mt-1">+91 96246 89335</div>
              <div className="text-emerald-700 text-xs font-medium mt-0.5">Direct chat &amp; inquiry channel</div>
            </div>
            <div className="text-xs text-neutral-400 mt-4 pt-3 border-t border-neutral-100">Direct team messaging</div>
          </a>

          <a
            href="mailto:oliveorangetechnologies@gmail.com"
            className="rounded-3xl bg-white border border-neutral-200/80 hover:border-brand-300 shadow-sm p-6 flex flex-col justify-between transition group"
          >
            <div>
              <div className="h-12 w-12 rounded-2xl bg-neutral-900 text-white flex items-center justify-center shadow-sm">
                <Mail className="h-6 w-6" />
              </div>
              <h3 className="font-display font-semibold text-lg mt-4 text-neutral-900 group-hover:text-brand-600 transition">
                Email Inquiries
              </h3>
              <div className="text-neutral-800 text-xs sm:text-sm font-semibold mt-1 break-all">oliveorangetechnologies@gmail.com</div>
              <div className="text-neutral-500 text-xs mt-0.5">Official Communications</div>
            </div>
            <div className="text-xs text-neutral-400 mt-4 pt-3 border-t border-neutral-100">Timely proposal &amp; brief reviews</div>
          </a>

          <div className="rounded-3xl bg-white border border-neutral-200/80 shadow-sm p-6 flex flex-col justify-between">
            <div>
              <div className="h-12 w-12 rounded-2xl bg-brand-100 text-brand-700 flex items-center justify-center">
                <Globe2 className="h-6 w-6" />
              </div>
              <h3 className="font-display font-semibold text-lg mt-4 text-neutral-900">Digital Advisory</h3>
              <div className="text-neutral-800 text-sm font-semibold mt-1">Direct &amp; Virtual Sessions</div>
              <div className="text-neutral-500 text-xs mt-0.5">Across India</div>
            </div>
            <div className="text-xs text-neutral-400 mt-4 pt-3 border-t border-neutral-100">1-on-1 discovery calls</div>
          </div>
        </div>
      </section>

      {/* FORM & OFFICIAL TOUCHPOINTS */}
      <section className="pb-20">
        <div className="container max-w-7xl mx-auto px-4 grid lg:grid-cols-12 gap-8">
          {/* Inquiry Form (7 cols) */}
          <div className="lg:col-span-7">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="rounded-3xl bg-white border border-neutral-200/80 shadow-sm p-6 sm:p-9"
            >
              <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">
                Start a Conversation
              </div>
              <h2 className="font-display text-2xl sm:text-3xl font-bold mt-3 text-neutral-900">
                Tell us about your business goals
              </h2>
              <p className="text-xs text-neutral-500 mt-1">
                Fill in your details below. We’ll analyze your requirements and discuss tailored solutions.
              </p>

              <form onSubmit={submit} className="mt-6 space-y-4">
                <div className="grid sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">Your Full Name*</label>
                    <input
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="e.g. Vikram Sharma"
                      className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">Phone / WhatsApp Number*</label>
                    <input
                      required
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      placeholder="e.g. +91 96246 00000"
                      className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">Email Address</label>
                    <input
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="e.g. vikram@organization.com"
                      className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">Company / Organization</label>
                    <input
                      value={form.company}
                      onChange={(e) => setForm({ ...form, company: e.target.value })}
                      placeholder="e.g. Sharma Enterprises"
                      className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">Service / Capability</label>
                    <select
                      value={form.service}
                      onChange={(e) => setForm({ ...form, service: e.target.value })}
                      className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-neutral-200 bg-white focus:border-brand-500 focus:outline-none"
                    >
                      {CAPABILITIES.map((cap) => (
                        <option key={cap} value={cap}>
                          {cap}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">Budget Allocation</label>
                    <select
                      value={form.budget}
                      onChange={(e) => setForm({ ...form, budget: e.target.value })}
                      className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-neutral-200 bg-white focus:border-brand-500 focus:outline-none"
                    >
                      <option value="Flexible / Exploring">Flexible / Exploring</option>
                      <option value="₹50K – ₹1.5L">₹50K – ₹1.5 Lakhs</option>
                      <option value="₹1.5L – ₹5L">₹1.5 Lakhs – ₹5 Lakhs</option>
                      <option value="₹5L – ₹15L">₹5 Lakhs – ₹15 Lakhs</option>
                      <option value="₹15L+">₹15 Lakhs+</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-700 mb-1">Desired Timeline</label>
                    <select
                      value={form.timeline}
                      onChange={(e) => setForm({ ...form, timeline: e.target.value })}
                      className="w-full px-3 py-2.5 text-xs sm:text-sm rounded-xl border border-neutral-200 bg-white focus:border-brand-500 focus:outline-none"
                    >
                      <option value="Immediate (< 2 Weeks)">Immediate (&lt; 2 Weeks)</option>
                      <option value="Within 30 Days">Within 30 Days</option>
                      <option value="1 to 3 Months">1 to 3 Months</option>
                      <option value="Exploring / Planning">Exploring / Planning</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-700 mb-1">
                    Describe your workflows, current problem, or goals
                  </label>
                  <textarea
                    rows={4}
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder="Tell us about the challenge you are facing in your business..."
                    className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-100"
                  />
                </div>

                <div className="pt-2 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <button
                    type="submit"
                    disabled={submitting}
                    className="flex-1 inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-brand-500 text-white font-semibold hover:bg-brand-600 shadow-glow disabled:opacity-60 transition text-sm"
                  >
                    {submitting ? 'Sending Request…' : (
                      <>
                        Submit Inquiry <Send className="h-4 w-4" />
                      </>
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => setDemoOpen(true)}
                    className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-full bg-neutral-900 text-white font-semibold hover:bg-black transition text-sm"
                  >
                    Book 1-on-1 Consultation <ArrowRight className="h-4 w-4" />
                  </button>
                </div>
              </form>
            </motion.div>
          </div>

          {/* Official Direct Touchpoints (5 cols) */}
          <div className="lg:col-span-5 space-y-5">
            {/* Brand Positioning Box */}
            <div className="rounded-3xl bg-white border border-neutral-200/80 shadow-sm p-6">
              <div className="flex items-start gap-3.5">
                <div className="h-10 w-10 rounded-xl bg-brand-100 text-brand-700 flex items-center justify-center shrink-0">
                  <Sparkles className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider font-semibold text-brand-600">
                    Official Positioning
                  </div>
                  <h3 className="font-display font-bold text-lg text-neutral-900 mt-0.5">Olive Orange Technologies</h3>
                  <p className="text-xs text-neutral-600 mt-1 leading-relaxed">
                    “We analyse your business problems and build the right digital solution.”
                  </p>
                  <div className="text-xs font-semibold text-neutral-800 mt-2">
                    Tagline: Every Problem Has A Solution.
                  </div>
                </div>
              </div>
            </div>

            {/* Direct Calling & WhatsApp */}
            <div className="rounded-3xl bg-white border border-neutral-200/80 shadow-sm p-6">
              <div className="flex items-start gap-3.5">
                <div className="h-10 w-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                  <MessageSquare className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider font-semibold text-emerald-600">
                    Direct Contact Channels
                  </div>
                  <h3 className="font-display font-bold text-lg text-neutral-900 mt-0.5">Phone &amp; WhatsApp</h3>
                  <p className="text-xs text-neutral-600 mt-1 leading-relaxed">
                    Official Phone / WhatsApp: <a href="tel:+919624689335" className="font-bold text-neutral-900 hover:text-brand-600">+91 96246 89335</a>
                  </p>
                  <p className="text-xs text-neutral-600 mt-1">
                    Official Email: <a href="mailto:oliveorangetechnologies@gmail.com" className="font-bold text-neutral-900 hover:text-brand-600">oliveorangetechnologies@gmail.com</a>
                  </p>
                </div>
              </div>
            </div>

            {/* Official Social Presence */}
            <div className="rounded-3xl bg-white border border-neutral-200/80 shadow-sm p-6">
              <div className="flex items-start gap-3.5">
                <div className="h-10 w-10 rounded-xl bg-orange-100 text-orange-700 flex items-center justify-center shrink-0">
                  <Globe2 className="h-5 w-5" />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider font-semibold text-orange-600">
                    Official Social Channels
                  </div>
                  <h3 className="font-display font-bold text-lg text-neutral-900 mt-0.5">Connect Online</h3>
                  <div className="mt-2 space-y-1.5 text-xs">
                    <div>
                      <a
                        href="https://www.instagram.com/oliveorange_technologies_india"
                        target="_blank"
                        rel="noreferrer"
                        className="text-brand-600 hover:text-brand-700 font-medium inline-flex items-center gap-1"
                      >
                        Instagram &rarr; @oliveorange_technologies_india
                      </a>
                    </div>
                    <div>
                      <a
                        href="https://www.facebook.com/profile.php?id=61592286137276"
                        target="_blank"
                        rel="noreferrer"
                        className="text-brand-600 hover:text-brand-700 font-medium inline-flex items-center gap-1"
                      >
                        Facebook &rarr; Olive Orange Technologies
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* AEO / GEO STRUCTURED FAQ SECTION */}
      <section className="py-16 bg-neutral-50/80 border-t border-neutral-200/80">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="text-center mb-10">
            <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">
              Frequently Answered Questions
            </div>
            <h2 className="font-display text-3xl font-bold mt-2 text-neutral-900">
              Clear answers before you get started
            </h2>
            <p className="text-xs text-neutral-500 mt-1">
              Direct, transparent answers regarding engagement models, code ownership, and integrations.
            </p>
          </div>

          <div className="space-y-3">
            {CONTACT_FAQS.map((faq, index) => {
              const isOpen = openFaq === index
              return (
                <div
                  key={faq.question}
                  className="rounded-2xl bg-white border border-neutral-200/80 overflow-hidden shadow-xs"
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : index)}
                    className="w-full px-5 py-4 text-left flex items-center justify-between gap-4 hover:bg-neutral-50/80 transition"
                  >
                    <span className="font-display font-semibold text-sm text-neutral-900">{faq.question}</span>
                    <ChevronDown
                      className={`h-4 w-4 text-neutral-400 shrink-0 transition-transform ${
                        isOpen ? 'rotate-180 text-brand-600' : ''
                      }`}
                    />
                  </button>
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="px-5 pb-4 text-xs sm:text-sm text-neutral-600 leading-relaxed border-t border-neutral-100 pt-3">
                          {faq.answer}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      <FooterCTA />
      <DemoModal open={demoOpen} onClose={() => setDemoOpen(false)} />
    </main>
  )
}

'use client'
import { motion } from 'framer-motion'
import Image from 'next/image'
import Link from 'next/link'
import {
  Sparkles,
  Rocket,
  Target,
  Heart,
  Users,
  CheckCircle2,
  ShieldCheck,
  TrendingUp,
  Award,
  Zap,
  Building2,
  ArrowRight,
  MessageSquare,
  Mail,
  Phone,
} from 'lucide-react'
import HeaderClient from '@/components/HeaderClient'
import FooterCTA from '@/components/FooterCTA'

const VALUES = [
  { icon: Rocket, title: 'Pragmatic Execution', desc: 'Working software engineered for your actual workflows. We prioritize real-world utility over ungrounded complexity.' },
  { icon: Heart, title: 'Problem-First Mindset', desc: 'We analyse your business problems and build the right digital solution. Every Problem Has A Solution.' },
  { icon: ShieldCheck, title: 'Client Sovereignty', desc: 'No hidden dependencies. Complete ownership of your code, customer records, and data schemas.' },
  { icon: Zap, title: 'Craft & Usability', desc: 'Clean, responsive user interfaces, maintainable backend code, and reliable software architecture.' },
]

const PROCESS = [
  { title: 'Discover', desc: 'We analyze your workflows, bottlenecks, and specific operational requirements.' },
  { title: 'Architect', desc: 'Design tailored data models, system interfaces, and integration flows.' },
  { title: 'Develop', desc: 'Iterative sprint-based engineering with transparent demonstration checkpoints.' },
  { title: 'Deploy', desc: 'Structured release, data onboarding, documentation, and user orientation.' },
  { title: 'Support', desc: 'Ongoing maintenance, security updates, and functional enhancements.' },
]

const PILLARS = [
  { v: '12', l: 'Core Capabilities' },
  { v: '100%', l: 'Code & Data Sovereignty' },
  { v: 'Custom', l: 'Right Digital Solution' },
  { v: 'Direct', l: 'WhatsApp & Phone Access' },
]

export default function AboutClient() {
  return (
    <main className="relative bg-white text-neutral-900 overflow-x-hidden">
      <HeaderClient />

      {/* HERO */}
      <section className="relative pt-36 pb-14 sm:pt-44">
        <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-24 -left-24 h-[420px] w-[420px] rounded-full bg-brand-200 opacity-60 blob" />
          <div className="absolute top-10 -right-20 h-[520px] w-[520px] rounded-full bg-orange-100 opacity-80 blob" style={{ animationDelay: '-4s' }} />
          <div className="absolute inset-0 grid-pattern opacity-40" />
        </div>
        <div className="container max-w-5xl mx-auto text-center px-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100 text-brand-700 text-xs font-semibold uppercase tracking-widest">
            <Sparkles className="h-3.5 w-3.5" /> About Olive Orange Technologies
          </div>
          <h1 className="font-display text-4xl sm:text-6xl font-bold mt-4 tracking-tight leading-[1.05]">
            Every Problem <br className="hidden sm:block" />
            <span className="bg-gradient-to-r from-brand-500 via-orange-500 to-amber-500 bg-clip-text text-transparent">Has A Solution.</span>
          </h1>
          <p className="text-neutral-600 text-lg mt-5 max-w-2xl mx-auto leading-relaxed">
            We analyse your business problems and build the right digital solution.
          </p>
        </div>
      </section>

      {/* STORY / POSITIONING */}
      <section className="py-16">
        <div className="container max-w-5xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-10 items-center">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">Our Approach</div>
              <h2 className="font-display text-3xl sm:text-4xl font-bold mt-3">Built to solve real business challenges.</h2>
              <div className="mt-4 space-y-4 text-neutral-600 leading-relaxed text-sm sm:text-base">
                <p>Every business encounters unique operational bottlenecks — whether managing customer inquiries, synchronizing inventory across locations, coordinating field operations, or automating repetitive administrative routines.</p>
                <p>At Olive Orange Technologies, our philosophy is straightforward: <b>Every Problem Has A Solution.</b> We take the time to understand how your business operates, diagnose where friction occurs, and build the right digital solution across our 12 capability areas — from branding and web development to custom software and corporate AI training.</p>
              </div>
            </div>
            <div className="relative">
              <div className="rounded-3xl overflow-hidden bg-gradient-to-br from-brand-100 to-orange-50 p-6 border border-brand-200 shadow-soft">
                <Image src="/brand/oli-mascot.jpg" alt="OLI" width={500} height={500} className="w-full h-auto rounded-2xl" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MISSION + VISION */}
      <section className="py-16 bg-gradient-to-b from-white via-brand-50/40 to-white">
        <div className="container max-w-6xl mx-auto px-4 grid md:grid-cols-2 gap-6">
          <div className="rounded-3xl bg-white border border-neutral-100 shadow-soft p-8 card-lift">
            <div className="h-12 w-12 rounded-2xl bg-brand-100 text-brand-600 flex items-center justify-center"><Target className="h-6 w-6" /></div>
            <div className="font-display text-2xl font-bold mt-4">Our Mission</div>
            <p className="text-neutral-600 mt-3 leading-relaxed">
              To analyze complex business challenges and engineer robust, user-friendly digital solutions that give businesses measurable operational clarity.
            </p>
          </div>
          <div className="rounded-3xl bg-neutral-900 text-white shadow-soft p-8 relative overflow-hidden card-lift">
            <div className="absolute -top-16 -right-16 h-40 w-40 rounded-full bg-brand-500/30 blob" />
            <div className="relative">
              <div className="h-12 w-12 rounded-2xl bg-brand-500/20 text-brand-300 flex items-center justify-center"><Rocket className="h-6 w-6" /></div>
              <div className="font-display text-2xl font-bold mt-4">Our Commitment</div>
              <p className="text-neutral-300 mt-3 leading-relaxed">
                To build long-term relationships grounded in software craftsmanship, transparent communication, and genuine ownership of your technological assets.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CORE VALUES */}
      <section className="py-20">
        <div className="container max-w-7xl mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">Guiding Values</div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold mt-3">What guides our engineering</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mt-10">
            {VALUES.map((v, i) => (
              <motion.div key={v.title} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className="rounded-3xl p-6 bg-white border border-neutral-100 shadow-soft card-lift">
                <div className="h-11 w-11 rounded-xl bg-brand-100 text-brand-600 flex items-center justify-center"><v.icon className="h-5 w-5" /></div>
                <div className="font-display font-semibold text-lg mt-4">{v.title}</div>
                <p className="text-neutral-500 text-sm mt-1 leading-relaxed">{v.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* PROCESS */}
      <section className="py-16 bg-gradient-to-b from-brand-50/40 to-white">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">Our Process</div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold mt-3">How we work with you</h2>
          </div>
          <div className="grid md:grid-cols-5 gap-4 mt-10">
            {PROCESS.map((s, i) => (
              <motion.div key={s.title} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.05 }}
                className="relative rounded-2xl p-5 bg-white border border-neutral-100 shadow-soft">
                <div className="absolute -top-3 -left-3 h-9 w-9 rounded-xl bg-brand-500 text-white flex items-center justify-center font-bold shadow-glow">{i + 1}</div>
                <div className="font-display font-semibold mt-2">{s.title}</div>
                <p className="text-neutral-500 text-xs sm:text-sm mt-1 leading-relaxed">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CAPABILITY PILLARS */}
      <section className="py-16 bg-gradient-to-b from-brand-50/40 to-white">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">Core Standards</div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold mt-3">Foundational Principles</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-10">
            {PILLARS.map(a => (
              <div key={a.l} className="rounded-3xl bg-white border border-neutral-100 shadow-soft p-6 text-center card-lift">
                <div className="font-display text-3xl sm:text-4xl font-bold text-brand-600">{a.v}</div>
                <div className="text-neutral-600 text-xs sm:text-sm mt-1 font-medium">{a.l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* TEAM ARCHITECTURE DISCLOSURE */}
      <section className="py-20">
        <div className="container max-w-4xl mx-auto px-4">
          <div className="rounded-3xl bg-neutral-50 border border-neutral-200/80 p-8 sm:p-12 text-center">
            <div className="h-12 w-12 rounded-2xl bg-brand-100 text-brand-700 flex items-center justify-center mx-auto mb-4">
              <Users className="h-6 w-6" />
            </div>
            <h3 className="font-display font-bold text-2xl text-neutral-900">
              Team &amp; Talent Directory
            </h3>
            <p className="text-neutral-600 text-sm mt-3 max-w-xl mx-auto leading-relaxed">
              Official team profiles and verified leadership disclosures will be published here upon official release.
              In the meantime, connect directly with our solutions team to discuss your business requirements.
            </p>
            <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
              <a
                href="https://wa.me/919624689335"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#25D366] text-white text-xs font-semibold hover:opacity-90 transition"
              >
                <MessageSquare className="h-3.5 w-3.5" /> WhatsApp: +91 96246 89335
              </a>
              <a
                href="mailto:oliveorangetechnologies@gmail.com"
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-neutral-900 text-white text-xs font-semibold hover:bg-black transition"
              >
                <Mail className="h-3.5 w-3.5" /> Email Us
              </a>
              <Link
                href="/team"
                className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-full bg-white border border-neutral-200 text-neutral-800 text-xs font-semibold hover:border-brand-500 transition"
              >
                View Careers &amp; Team Architecture <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="py-16 bg-gradient-to-b from-white via-brand-50/40 to-white">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">Why Choose Us</div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold mt-3">Why businesses partner with Olive Orange Technologies</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mt-10">
            {[
              { icon: Award, title: 'Problem-First Discovery', desc: 'We take time to analyze your specific operational friction before architecting any code.' },
              { icon: Zap, title: 'Iterative Delivery', desc: 'Sprint-based releases with regular demonstration checkpoints.' },
              { icon: ShieldCheck, title: 'Complete Code Ownership', desc: 'Your data schemas, source repositories, and digital assets remain 100% yours.' },
              { icon: TrendingUp, title: 'Practical Automation', desc: 'Focus on tangible efficiency gains rather than superficial hype.' },
              { icon: Users, title: 'Direct Communication', desc: 'Direct access via WhatsApp, phone, and video consultations without bureaucratic layers.' },
              { icon: Building2, title: '12 Capability Areas', desc: 'Comprehensive digital services spanning creative branding, websites, software, and AI.' },
            ].map(c => (
              <div key={c.title} className="rounded-2xl p-5 bg-white border border-neutral-100 shadow-soft card-lift flex items-start gap-3">
                <div className="h-10 w-10 rounded-xl bg-brand-100 text-brand-600 flex items-center justify-center flex-shrink-0"><c.icon className="h-5 w-5" /></div>
                <div>
                  <div className="font-semibold text-neutral-900">{c.title}</div>
                  <p className="text-neutral-500 text-sm mt-1 leading-relaxed">{c.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <FooterCTA />
    </main>
  )
}

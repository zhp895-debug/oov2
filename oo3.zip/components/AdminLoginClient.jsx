'use client'
import { useState, useEffect } from 'react'
import Image from 'next/image'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Lock, Mail, Eye, EyeOff, ShieldCheck, ArrowRight, AlertCircle, ArrowLeft } from 'lucide-react'
import { toast } from 'sonner'

export default function AdminLoginClient() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [errorMsg, setErrorMsg] = useState('')

  useEffect(() => {
    const token =
      typeof window !== 'undefined'
        ? sessionStorage.getItem('oo_admin_token') || localStorage.getItem('oo_admin_token')
        : null

    if (token) {
      fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
        credentials: 'include',
      })
        .then((r) => r.json())
        .then((d) => {
          if (d.ok && d.authenticated) {
            window.location.href = '/admin'
          }
        })
        .catch(() => {})
    }
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    setErrorMsg('')

    if (!email || !password) {
      setErrorMsg('Please enter both email and password.')
      return
    }

    setLoading(true)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), password }),
        credentials: 'include',
      })

      const data = await res.json().catch(() => ({}))

      if (!res.ok || !data.ok) {
        setErrorMsg(data.error || 'Authentication failed. Please verify your credentials.')
        toast.error(data.error || 'Authentication failed')
        setLoading(false)
        return
      }

      // Store token and user in client storage for iframe resilience
      if (data.token) {
        try {
          sessionStorage.setItem('oo_admin_token', data.token)
          localStorage.setItem('oo_admin_token', data.token)
          if (data.user) {
            sessionStorage.setItem('oo_admin_user', JSON.stringify(data.user))
          }
        } catch (e) {}
      }

      toast.success('Authenticated successfully. Opening console...')
      // Full page navigation to refresh server session
      window.location.href = '/admin'
    } catch (err) {
      setErrorMsg('Network error connecting to authorization server.')
      toast.error('Connection error')
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-neutral-950 text-white flex flex-col justify-between relative overflow-hidden selection:bg-brand-500 selection:text-white">
      {/* Background ambient decorative glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-brand-500/10 rounded-full blur-[140px] pointer-events-none" />
      <div className="absolute -bottom-20 -left-20 w-[400px] h-[400px] bg-brand-600/10 rounded-full blur-[120px] pointer-events-none" />

      {/* Top Bar */}
      <header className="relative z-10 px-6 py-6 flex items-center justify-between max-w-7xl mx-auto w-full">
        <Link href="/" className="inline-flex items-center gap-2.5 group">
          <Image
            src="/brand/oo-logo.jpg"
            alt="Olive Orange Technologies Logo"
            width={36}
            height={36}
            className="rounded-xl object-contain bg-white/5 p-1 ring-1 ring-white/10"
          />
          <div className="flex flex-col">
            <span className="font-display font-bold text-sm tracking-tight text-white group-hover:text-brand-400 transition">
              Olive Orange Technologies
            </span>
            <span className="text-[10px] text-neutral-400">Operations Portal</span>
          </div>
        </Link>

        <Link
          href="/"
          className="inline-flex items-center gap-1.5 text-xs text-neutral-400 hover:text-white transition px-3 py-1.5 rounded-full border border-white/10 hover:border-white/20 bg-white/5"
        >
          <ArrowLeft className="h-3.5 w-3.5" /> Return to Website
        </Link>
      </header>

      {/* Main Login Card */}
      <div className="relative z-10 w-full max-w-md mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35, ease: 'easeOut' }}
          className="bg-neutral-900/90 backdrop-blur-xl border border-white/10 rounded-3xl p-7 sm:p-9 shadow-2xl shadow-black/80"
        >
          {/* Card Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-brand-500/10 text-brand-400 border border-brand-500/20 mb-4">
              <ShieldCheck className="h-6 w-6" />
            </div>
            <h1 className="font-display text-2xl font-bold text-white tracking-tight">
              Operations &amp; CMS Console
            </h1>
            <p className="text-xs text-neutral-400 mt-2 leading-relaxed">
              Enter your verified credentials to access administrative operations, CMS publishing, and inbound leads.
            </p>
          </div>

          {/* Error Banner */}
          {errorMsg && (
            <div className="mb-6 p-3.5 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-start gap-2.5 text-xs text-red-300">
              <AlertCircle className="h-4 w-4 text-red-400 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                Authorized Email
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-500">
                  <Mail className="h-4 w-4" />
                </div>
                <input
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@oliveorangetech.in"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-neutral-950/80 border border-white/10 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 transition"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                Secure Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-neutral-500">
                  <Lock className="h-4 w-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-neutral-950/80 border border-white/10 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 transition"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-neutral-500 hover:text-neutral-300 transition"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 inline-flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-brand-500 hover:bg-brand-600 active:bg-brand-700 text-white text-sm font-semibold shadow-lg shadow-brand-500/25 transition disabled:opacity-50 disabled:pointer-events-none"
            >
              {loading ? (
                <>
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>Verifying Credentials...</span>
                </>
              ) : (
                <>
                  <span>Sign In to Console</span>
                  <ArrowRight className="h-4 w-4" />
                </>
              )}
            </button>
          </form>

          {/* Security note */}
          <div className="mt-8 pt-6 border-t border-white/5 flex items-center justify-between text-[11px] text-neutral-500">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
              Cryptographic Session (HMAC)
            </span>
            <span>24h Token Life</span>
          </div>
        </motion.div>
      </div>

      {/* Footer */}
      <footer className="relative z-10 px-6 py-6 text-center text-xs text-neutral-500">
        <p>© {new Date().getFullYear()} Olive Orange Technologies. Every Problem Has A Solution.</p>
        <p className="mt-1 text-[11px] text-neutral-600">Unauthorized access attempts are logged and rejected.</p>
      </footer>
    </main>
  )
}

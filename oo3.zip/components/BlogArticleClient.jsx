'use client'
import { useState } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { motion } from 'framer-motion'
import {
  Clock,
  ArrowRight,
  User,
  Calendar,
  ChevronRight,
  Share2,
  Copy,
  Check,
  Bookmark,
  MessageSquare,
  Sparkles,
  BookOpen,
} from 'lucide-react'
import { toast } from 'sonner'
import HeaderClient from '@/components/HeaderClient'
import FooterCTA from '@/components/FooterCTA'

function fmtDate(iso) {
  return new Date(iso).toLocaleDateString('en-IN', { day: '2-digit', month: 'long', year: 'numeric' })
}

function getPostImage(post, width = 1600) {
  let src = post?.featuredImage || post?.image || post?.coverImage || ''
  if (!src || typeof src !== 'string' || src.includes('undefined') || src.includes('kommodo.ai/i/')) {
    return `https://images.unsplash.com/photo-1652156752342-c786f1e1d1ce?w=${width}&auto=format&fit=crop&q=80`
  }
  if (src.startsWith('https://images.unsplash.com/') && !src.includes('?')) {
    return `${src}?w=${width}&auto=format&fit=crop&q=80`
  }
  return src
}

export default function BlogArticleClient({ post, related }) {
  const [copied, setCopied] = useState(false)

  const handleCopyLink = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(window.location.href)
      setCopied(true)
      toast.success('Article link copied to clipboard!')
      setTimeout(() => setCopied(false), 2500)
    }
  }

  // Derive AEO Key Takeaways from article content
  const takeaways = post.content.slice(0, 3).map((p) => {
    const firstSentence = p.split('.')[0] + '.'
    return firstSentence.length > 30 ? firstSentence : p.slice(0, 110) + '...'
  })

  return (
    <main className="relative bg-white text-neutral-900 overflow-x-hidden">
      <HeaderClient />

      {/* ARTICLE HEADER */}
      <section className="relative pt-32 pb-8 sm:pt-40">
        <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-24 -left-24 h-[400px] w-[400px] rounded-full bg-brand-200 opacity-60 blob" />
          <div
            className="absolute top-10 -right-20 h-[500px] w-[500px] rounded-full bg-orange-100 opacity-70 blob"
            style={{ animationDelay: '-4s' }}
          />
        </div>
        <div className="container max-w-4xl mx-auto px-4">
          {/* Breadcrumbs */}
          <nav className="text-xs text-neutral-500 mb-5 flex items-center gap-1.5 flex-wrap">
            <Link href="/" className="hover:text-brand-600 transition">
              Home
            </Link>
            <span aria-hidden="true">/</span>
            <Link href="/blog" className="hover:text-brand-600 transition">
              Blog
            </Link>
            <span aria-hidden="true">/</span>
            <span className="text-brand-600 font-medium">{post.category}</span>
          </nav>

          {/* Clean unboxed metadata with separators (Anti-Slop rule) */}
          <div className="flex items-center gap-2 text-xs text-neutral-500 mb-3">
            <span className="font-semibold text-brand-600">{post.category}</span>
            <span aria-hidden="true">·</span>
            <span>{post.readMin} min read</span>
            <span aria-hidden="true">·</span>
            <span>{fmtDate(post.date)}</span>
          </div>

          <motion.h1
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="font-display text-3xl sm:text-5xl md:text-5xl font-bold tracking-tight leading-[1.1] text-neutral-900"
          >
            {post.title}
          </motion.h1>

          <p className="text-neutral-600 text-lg mt-4 max-w-3xl leading-relaxed">{post.excerpt}</p>

          {/* Author bar & Share controls */}
          <div className="mt-6 pt-5 border-t border-neutral-100 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-gradient-to-br from-brand-500 to-brand-600 text-white flex items-center justify-center font-bold text-xs shadow-sm">
                {post.author
                  .split(' ')
                  .map((w) => w[0])
                  .join('')}
              </div>
              <div>
                <div className="font-semibold text-sm text-neutral-900">{post.author}</div>
                <div className="text-xs text-neutral-500">{post.role}</div>
              </div>
            </div>

            {/* Social Share Controls */}
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyLink}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-neutral-200 text-xs font-medium hover:bg-neutral-50 transition"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
                <span>{copied ? 'Link Copied' : 'Copy Link'}</span>
              </button>
              <a
                href={`https://wa.me/?text=${encodeURIComponent(`${post.title} - Read more on Olive Orange: `)}`}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-full border border-neutral-200 text-[#25D366] hover:bg-emerald-50 transition"
                title="Share on WhatsApp"
              >
                <MessageSquare className="h-3.5 w-3.5" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* COVER IMAGE */}
      <section className="pb-10">
        <div className="container max-w-5xl mx-auto px-4">
          <div className="relative aspect-[16/9] rounded-3xl overflow-hidden shadow-sm border border-neutral-100">
            <Image
              src={getPostImage(post, 1600)}
              alt={post.title}
              fill
              priority
              className="object-cover"
              sizes="100vw"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>
      </section>

      {/* ARTICLE BODY & AEO CONTENT STRUCTURE */}
      <article className="py-6 pb-16">
        <div className="container max-w-3xl mx-auto px-4">
          {/* AEO / GEO Structured Key Takeaways Box */}
          <div className="rounded-3xl bg-neutral-50 border border-neutral-200/80 p-6 sm:p-7 mb-10">
            <div className="flex items-center gap-2 text-xs uppercase tracking-wider font-bold text-brand-700">
              <BookOpen className="h-4 w-4" /> Executive Brief &amp; Key Takeaways
            </div>
            <ul className="mt-3.5 space-y-2.5 text-sm text-neutral-700">
              {takeaways.map((point, idx) => (
                <li key={idx} className="flex items-start gap-2.5 leading-relaxed">
                  <span className="h-1.5 w-1.5 rounded-full bg-brand-500 mt-2 shrink-0" />
                  <span>{point}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Paragraphs */}
          <div className="space-y-6 text-neutral-800 text-lg leading-relaxed">
            {post.content.map((para, i) => (
              <p
                key={i}
                className={
                  i === 0
                    ? 'first-letter:font-display first-letter:text-5xl first-letter:font-bold first-letter:text-brand-500 first-letter:mr-2.5 first-letter:float-left first-letter:leading-none'
                    : ''
                }
              >
                {para}
              </p>
            ))}
          </div>

          {/* Topic Tags */}
          <div className="mt-12 pt-6 border-t border-neutral-100 flex flex-wrap items-center gap-2">
            <span className="text-xs uppercase tracking-wider text-neutral-500 font-semibold mr-1">Topics:</span>
            {post.tags.map((t) => (
              <span
                key={t}
                className="text-xs text-neutral-600 bg-neutral-100 px-2.5 py-1 rounded-lg font-medium"
              >
                #{t}
              </span>
            ))}
          </div>

          {/* Author Box */}
          <div className="mt-10 rounded-3xl bg-neutral-50 border border-neutral-200/80 p-6 sm:p-7 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="h-14 w-14 rounded-2xl bg-gradient-to-br from-brand-500 to-brand-600 text-white flex items-center justify-center font-display text-xl font-bold shadow-sm shrink-0">
                {post.author
                  .split(' ')
                  .map((w) => w[0])
                  .join('')}
              </div>
              <div>
                <div className="font-display font-bold text-base text-neutral-900">{post.author}</div>
                <div className="text-xs text-brand-600 font-medium">{post.role}</div>
                <div className="text-xs text-neutral-500 mt-0.5">Olive Orange Technologies</div>
              </div>
            </div>
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-neutral-900 text-white text-xs font-semibold hover:bg-black transition whitespace-nowrap"
            >
              Discuss This Topic <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </div>
        </div>
      </article>

      {/* RELATED ARTICLES */}
      {related && related.length > 0 && (
        <section className="py-16 bg-neutral-50/80 border-t border-neutral-200/80">
          <div className="container max-w-7xl mx-auto px-4">
            <div className="max-w-2xl mx-auto text-center mb-10">
              <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-brand-100 text-brand-700 font-semibold uppercase tracking-widest">
                Related Analyses
              </div>
              <h2 className="font-display text-2xl sm:text-3xl font-bold mt-2 text-neutral-900">
                Continue reading playbooks
              </h2>
            </div>

            <div className="grid sm:grid-cols-3 gap-6">
              {related.map((r) => (
                <Link
                  key={r.slug}
                  href={`/blog/${r.slug}`}
                  className="group rounded-3xl bg-white border border-neutral-200/80 hover:border-brand-300 shadow-sm hover:shadow-md overflow-hidden transition flex flex-col justify-between"
                >
                  <div>
                    <div className="relative aspect-[16/10]">
                      <Image
                        src={getPostImage(r, 600)}
                        alt={r.title}
                        fill
                        sizes="33vw"
                        className="object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="p-5">
                      <div className="text-xs text-brand-600 font-semibold">{r.category}</div>
                      <h3 className="font-display font-bold text-sm leading-snug mt-1.5 text-neutral-900 group-hover:text-brand-600 transition line-clamp-2">
                        {r.title}
                      </h3>
                    </div>
                  </div>
                  <div className="p-5 pt-0">
                    <div className="pt-3 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-500">
                      <span>{r.readMin} min read</span>
                      <span className="font-semibold text-brand-600 inline-flex items-center gap-1 group-hover:gap-1.5 transition-all">
                        Read <ChevronRight className="h-3.5 w-3.5" />
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      <FooterCTA />
    </main>
  )
}

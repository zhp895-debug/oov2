'use client'
import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import Link from 'next/link'
import {
  Users,
  Linkedin,
  ArrowRight,
  Sparkles,
  Award,
  CheckCircle2,
  Briefcase,
  ShieldCheck,
  Cpu,
  Terminal,
  Crown,
  X as XIcon,
  Send,
  MessageSquare,
  Mail,
  Phone,
  Layers,
  ChevronRight,
  ExternalLink,
  Code2,
} from 'lucide-react'
import { toast } from 'sonner'
import HeaderClient from '@/components/HeaderClient'
import FooterCTA from '@/components/FooterCTA'
import DemoModal from '@/components/DemoModal'

const OPEN_POSITIONS = [
  {
    title: 'Full-Stack Developer (Web & Cloud)',
    type: 'Full-time / Contract',
    location: 'Remote / Hybrid (Gujarat / India)',
    exp: 'Relevant Experience',
    desc: 'Build resilient web applications, modern responsive interfaces, and API integrations for client systems.',
  },
  {
    title: 'AI Solutions & Automation Engineer',
    type: 'Full-time / Contract',
    location: 'Remote / Hybrid (Gujarat / India)',
    exp: 'Relevant Experience',
    desc: 'Develop practical AI automation, workflow integrations, and conversational agents for Indian businesses.',
  },
  {
    title: 'Business Solutions Consultant',
    type: 'Full-time / Contract',
    location: 'Remote / Hybrid (Gujarat / India)',
    exp: 'Relevant Experience',
    desc: 'Analyse business workflows, diagnose friction points, and design customized digital solution roadmaps.',
  },
  {
    title: 'UI/UX & Creative Designer',
    type: 'Full-time / Contract',
    location: 'Remote / Hybrid (Gujarat / India)',
    exp: 'Relevant Experience',
    desc: 'Create clean, intuitive digital experiences, design systems, and brand assets for web and mobile.',
  },
]

// Fallback focus pillars by member designation to highlight core strengths
function getMemberPillars(designation = '') {
  const d = designation.toLowerCase()
  if (d.includes('ceo') || d.includes('cmo') || d.includes('founder')) {
    return ['Business Discovery', 'Strategic Direction', 'Client Architecture']
  }
  if (d.includes('cto') || d.includes('cpo')) {
    return ['System Engineering', 'Cloud Infrastructure', 'Product Architecture']
  }
  if (d.includes('security') || d.includes('support') || d.includes('maintenance')) {
    return ['Cyber Security', 'SLA Reliability', 'Infrastructure Support']
  }
  return ['Digital Solutions', 'Engineering', 'Workflow Optimization']
}

// Executive role emblem selector
function getMemberIcon(designation = '') {
  const d = designation.toLowerCase()
  if (d.includes('ceo') || d.includes('cmo') || d.includes('founder')) {
    return Crown
  }
  if (d.includes('cto') || d.includes('cpo')) {
    return Cpu
  }
  if (d.includes('security') || d.includes('support')) {
    return ShieldCheck
  }
  return Code2
}

export default function TeamClient({ initialMembers = [], settings = {} }) {
  const [teamList, setTeamList] = useState(
    Array.isArray(initialMembers) ? [...initialMembers].filter((m) => m.isActive !== false) : []
  )
  const [siteSettings, setSiteSettings] = useState(settings || {})
  const [demoOpen, setDemoOpen] = useState(false)
  const [applyModal, setApplyModal] = useState({ open: false, role: '' })
  const [applyForm, setApplyForm] = useState({ name: '', email: '', phone: '', portfolio: '', note: '' })
  const [submittingApply, setSubmittingApply] = useState(false)

  // Re-sync with client-side API to immediately catch CMS updates without reload
  useEffect(() => {
    fetch('/api/team')
      .then((r) => r.json())
      .then((data) => {
        if (data?.ok && Array.isArray(data.members) && data.members.length > 0) {
          const sorted = [...data.members]
            .filter((m) => m.isActive !== false)
            .sort((a, b) => (Number(a.displayOrder) || 0) - (Number(b.displayOrder) || 0))
          setTeamList(sorted)
        }
      })
      .catch(() => {})

    fetch('/api/settings')
      .then((r) => r.json())
      .then((data) => {
        if (data?.ok && data.settings) {
          setSiteSettings(data.settings)
        }
      })
      .catch(() => {})
  }, [])

  const sortedMembers = [...teamList]
    .filter((m) => m.isActive !== false)
    .sort((a, b) => (Number(a.displayOrder) || 0) - (Number(b.displayOrder) || 0))

  const handleApply = async (e) => {
    e.preventDefault()
    if (!applyForm.name || !applyForm.phone) {
      toast.error('Please provide your name and phone/WhatsApp number.')
      return
    }
    setSubmittingApply(true)
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...applyForm,
          type: 'career_application',
          role: applyModal.role,
          message: `Career Application for ${applyModal.role}. Portfolio: ${applyForm.portfolio}. Note: ${applyForm.note}`,
        }),
      })
      const data = await res.json()
      if (data?.ok) {
        toast.success(`Application submitted for ${applyModal.role}! Our team will get in touch.`)
        setApplyModal({ open: false, role: '' })
        setApplyForm({ name: '', email: '', phone: '', portfolio: '', note: '' })
      } else {
        toast.error('Failed to submit application. Please email oliveorangetechnologies@gmail.com')
      }
    } catch {
      toast.error('Network error. Please email oliveorangetechnologies@gmail.com')
    }
    setSubmittingApply(false)
  }

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.1,
      },
    },
  }

  const cardVariants = {
    hidden: { opacity: 0, y: 35, scale: 0.98 },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: { duration: 0.65, ease: [0.22, 1, 0.36, 1] },
    },
  }

  const mainTeamPhoto =
    siteSettings?.teamPhoto ||
    'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1600&q=80'
  const mainTeamPhotoAlt =
    siteSettings?.teamPhotoAlt ||
    'Olive Orange Technologies engineering and operations team collaborating on client solutions'

  return (
    <main className="relative bg-white text-neutral-900 overflow-x-hidden selection:bg-[#FF7A00]/20 selection:text-neutral-900">
      <HeaderClient />

      {/* ==================== 1. HERO SECTION WITH HIGH-GRAPHICS AMBIENT FIELD ==================== */}
      <section className="relative pt-36 pb-20 sm:pt-44 sm:pb-28 overflow-hidden">
        {/* Ambient background graphics */}
        <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
          {/* Olive Green ambient blob */}
          <div
            className="absolute -top-32 -left-32 h-[520px] w-[520px] rounded-full opacity-35 blur-3xl pointer-events-none"
            style={{
              background: 'radial-gradient(circle, rgba(85,107,47,0.45) 0%, rgba(85,107,47,0) 70%)',
            }}
          />
          {/* Orange ambient blob */}
          <div
            className="absolute top-12 -right-28 h-[580px] w-[580px] rounded-full opacity-40 blur-3xl pointer-events-none"
            style={{
              background: 'radial-gradient(circle, rgba(255,122,0,0.40) 0%, rgba(255,122,0,0) 70%)',
            }}
          />
          {/* Fine technical dot grid */}
          <div className="absolute inset-0 bg-[radial-gradient(#d1d5db_1px,transparent_1px)] [background-size:24px_24px] opacity-40" />

          {/* Technical hairline rules & coordinate watermarks */}
          <div className="absolute top-28 left-8 hidden lg:flex items-center gap-2 text-[10px] font-mono text-neutral-400 tracking-widest uppercase opacity-60">
            <span className="h-1.5 w-1.5 rounded-full bg-[#556B2F] animate-pulse" />
            <span>SYS_LOC // 23°01&apos;N 72°35&apos;E</span>
          </div>
          <div className="absolute top-28 right-8 hidden lg:flex items-center gap-2 text-[10px] font-mono text-neutral-400 tracking-widest uppercase opacity-60">
            <span>OO_LEADERSHIP // PROD-RELEASE</span>
            <span className="h-1.5 w-1.5 rounded-full bg-[#FF7A00] animate-pulse" />
          </div>
        </div>

        <div className="container max-w-5xl mx-auto text-center px-4">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-[#556B2F]/10 via-[#FF7A00]/10 to-[#556B2F]/10 border border-[#556B2F]/20 text-[#556B2F] text-xs font-semibold uppercase tracking-wider shadow-2xs backdrop-blur-xs"
          >
            <Users className="h-3.5 w-3.5 text-[#FF7A00]" />
            <span>Executive Leadership &amp; Engineering</span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="font-display text-4xl sm:text-6xl lg:text-7xl font-bold mt-5 tracking-tight leading-[1.08] text-neutral-900"
          >
            People who turn problems{' '}
            <span className="bg-gradient-to-r from-[#556B2F] via-[#FF7A00] to-amber-500 bg-clip-text text-transparent">
              into digital solutions.
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-neutral-600 text-base sm:text-xl mt-6 max-w-2xl mx-auto leading-relaxed font-normal"
          >
            We analyse your business problems and build the right digital solution.{' '}
            <span className="font-semibold text-neutral-900">Every Problem Has A Solution.</span> Direct technical
            accountability, sovereign engineering, and practical execution.
          </motion.p>
        </div>
      </section>

      {/* ==================== 2. EXECUTIVE LEADERSHIP CARDS (3 CARDS) ==================== */}
      <section className="relative py-12 pb-24">
        {/* Subtle decorative grid borders */}
        <div className="container max-w-6xl mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-14">
            <div>
              <div className="inline-flex items-center gap-1.5 text-[11px] font-mono tracking-widest uppercase text-neutral-500 font-semibold">
                <span className="h-2 w-2 rounded-full bg-[#FF7A00]" />
                EXECUTIVE DIRECTORY
              </div>
              <h2 className="font-display text-3xl sm:text-4xl font-bold mt-2 text-neutral-900 tracking-tight">
                Founding &amp; Technical Leadership
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-neutral-500 max-w-md leading-relaxed">
              Real people with direct engineering, strategy, and operational ownership. Zero outsourced accountability.
            </p>
          </div>

          {/* Cards Grid */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7 lg:gap-8"
          >
            {sortedMembers.map((member, index) => {
              const RoleIcon = getMemberIcon(member.designation)
              const pillars = getMemberPillars(member.designation)
              const initials = member.name
                ? member.name
                    .split(' ')
                    .map((n) => n[0])
                    .join('')
                : 'OO'

              return (
                <motion.div
                  key={member.id || member.name || index}
                  variants={cardVariants}
                  whileHover={{ y: -8 }}
                  transition={{ duration: 0.35, ease: 'easeOut' }}
                  className="group relative rounded-3xl p-[1px] bg-gradient-to-b from-neutral-200/90 via-neutral-100 to-neutral-200/50 hover:from-[#556B2F]/50 hover:via-white hover:to-[#FF7A00]/50 transition-all duration-700 shadow-[0_8px_30px_-6px_rgba(0,0,0,0.06)] hover:shadow-[0_25px_50px_-12px_rgba(85,107,47,0.22)]"
                >
                  {/* Hover ambient lighting glow behind card */}
                  <div
                    className="absolute -inset-1 rounded-3xl opacity-0 group-hover:opacity-100 blur-xl transition-all duration-700 -z-10 pointer-events-none"
                    style={{
                      background:
                        'radial-gradient(circle at 50% 30%, rgba(85,107,47,0.28) 0%, rgba(255,122,0,0.25) 50%, transparent 80%)',
                    }}
                  />

                  {/* Inner card container */}
                  <div className="relative rounded-[23px] bg-white overflow-hidden flex flex-col justify-between h-full border border-neutral-100/80">
                    {/* TOP: Image or High-End Executive Avatar */}
                    <div className="relative h-80 sm:h-96 w-full overflow-hidden bg-neutral-950 flex items-center justify-center">
                      {member.profileImage ? (
                        <img
                          src={member.profileImage}
                          alt={member.name}
                          className="w-full h-full object-cover object-top transform group-hover:scale-105 transition-transform duration-700 ease-out"
                        />
                      ) : (
                        /* Premium Executive Monogram Artwork */
                        <div className="relative w-full h-full flex flex-col items-center justify-center p-8 bg-gradient-to-br from-neutral-950 via-neutral-900 to-[#1c1510] overflow-hidden">
                          {/* Radial lighting back-glow */}
                          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(85,107,47,0.35)_0%,rgba(255,122,0,0.18)_50%,transparent_75%)] opacity-70 group-hover:opacity-100 transition-opacity duration-700" />
                          {/* Faint technical orbital rings */}
                          <div className="absolute h-56 w-56 rounded-full border border-white/5 animate-[spin_40s_linear_infinite]" />
                          <div className="absolute h-40 w-40 rounded-full border border-white/10" />

                          {/* Central Monogram Medallion */}
                          <div className="relative z-10 flex flex-col items-center">
                            <div className="h-24 w-24 rounded-2xl p-0.5 bg-gradient-to-br from-amber-400/40 via-white/20 to-[#556B2F]/40 shadow-xl backdrop-blur-md">
                              <div className="h-full w-full rounded-[14px] bg-neutral-950/80 flex items-center justify-center border border-white/10">
                                <span className="font-display font-extrabold text-3xl sm:text-4xl tracking-tight bg-gradient-to-br from-white via-neutral-200 to-amber-200 bg-clip-text text-transparent drop-shadow-sm">
                                  {initials}
                                </span>
                              </div>
                            </div>
                            <div className="mt-3 inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/10 backdrop-blur-md border border-white/15 text-[10px] font-mono tracking-widest text-amber-300 uppercase">
                              <RoleIcon className="h-3 w-3 text-[#FF7A00]" />
                              <span>OFFICIAL LEADERSHIP</span>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Top Badges */}
                      <div className="absolute top-4 left-4 z-20">
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-black/60 backdrop-blur-md border border-white/20 text-[10px] font-mono text-white tracking-widest uppercase shadow-xs">
                          <span className="h-1.5 w-1.5 rounded-full bg-[#FF7A00]" />
                          OO // #{String(member.displayOrder || index + 1).padStart(2, '0')}
                        </span>
                      </div>

                      {/* Bottom Gradient Vignette for perfect text readability */}
                      <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/50 to-transparent pointer-events-none z-10" />

                      {/* Name & Designation overlay */}
                      <div className="absolute bottom-4 left-4 right-4 z-20">
                        <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/15 backdrop-blur-md border border-white/20 text-[11px] font-semibold text-amber-300 shadow-2xs mb-1.5">
                          <RoleIcon className="h-3 w-3 text-[#FF7A00]" />
                          <span className="truncate max-w-[220px]">{member.designation}</span>
                        </div>
                        <h3 className="font-display text-2xl sm:text-[26px] font-bold text-white tracking-tight leading-snug drop-shadow-sm">
                          {member.name}
                        </h3>
                      </div>
                    </div>

                    {/* BOTTOM: Body, Responsibilities, Actions */}
                    <div className="p-6 sm:p-7 flex flex-col justify-between flex-1 space-y-5">
                      <div>
                        {/* Bio */}
                        <p className="text-xs sm:text-sm text-neutral-600 leading-relaxed font-normal">
                          {member.bio ||
                            'Dedicated solutions leadership focused on diagnostic problem discovery, sovereign system architecture, and robust digital execution.'}
                        </p>

                        {/* Responsibility Focus Tags */}
                        <div className="mt-4 pt-4 border-t border-neutral-100 flex flex-wrap gap-1.5">
                          {pillars.map((p) => (
                            <span
                              key={p}
                              className="px-2.5 py-0.5 rounded-lg bg-neutral-100 text-neutral-700 text-[11px] font-medium"
                            >
                              {p}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* Action Button: LinkedIn or Direct Connect */}
                      <div className="pt-2">
                        {member.linkedin ? (
                          <a
                            href={member.linkedin}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-xl bg-neutral-900 hover:bg-[#0A66C2] text-white text-xs font-semibold transition-all duration-300 shadow-xs group/btn"
                          >
                            <Linkedin className="h-3.5 w-3.5 text-white group-hover/btn:scale-110 transition-transform" />
                            <span>Connect on LinkedIn</span>
                            <ExternalLink className="h-3 w-3 text-neutral-400 group-hover/btn:text-white ml-auto" />
                          </a>
                        ) : (
                          <a
                            href={`mailto:oliveorangetechnologies@gmail.com?subject=Inquiry for ${encodeURIComponent(
                              member.name
                            )} - Olive Orange Technologies`}
                            className="inline-flex items-center justify-center gap-2 w-full py-2.5 px-4 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-800 text-xs font-semibold transition-colors duration-200 group/btn"
                          >
                            <Mail className="h-3.5 w-3.5 text-[#556B2F]" />
                            <span>Connect with Leadership</span>
                            <ArrowRight className="h-3 w-3 text-neutral-400 group-hover/btn:translate-x-0.5 transition-transform ml-auto" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )
            })}
          </motion.div>
        </div>
      </section>

      {/* ==================== 3. CINEMATIC MAIN TEAM PHOTO SHOWCASE (CMS-DRIVEN) ==================== */}
      <section className="py-16 pb-24 bg-gradient-to-b from-neutral-50 via-white to-neutral-50 border-y border-neutral-200/70">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-[#556B2F]/10 to-[#FF7A00]/10 border border-[#556B2F]/20 text-[#556B2F] text-[11px] font-bold uppercase tracking-wider">
              <Sparkles className="h-3.5 w-3.5 text-[#FF7A00]" />
              The Engineering Collective
            </div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold mt-3 text-neutral-900 tracking-tight">
              One Unified Digital Solutions Team
            </h2>
            <p className="text-neutral-600 text-sm mt-2 leading-relaxed">
              System architects, full-stack engineers, and operational consultants building sovereign technology for
              enterprises across India.
            </p>
          </div>

          {/* Cinematic Viewport Container */}
          <div className="relative group rounded-3xl p-1 bg-gradient-to-b from-neutral-300/80 via-neutral-100 to-neutral-300/60 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.12)]">
            {/* Ambient halo glow */}
            <div
              className="absolute -inset-2 rounded-3xl opacity-60 group-hover:opacity-90 blur-2xl transition-all duration-700 -z-10 pointer-events-none"
              style={{
                background:
                  'radial-gradient(circle, rgba(85,107,47,0.30) 0%, rgba(255,122,0,0.22) 50%, transparent 80%)',
              }}
            />

            <div className="relative rounded-[22px] overflow-hidden bg-neutral-950 aspect-[16/9] sm:aspect-[21/9] border border-neutral-200">
              <img
                src={mainTeamPhoto}
                alt={mainTeamPhotoAlt}
                className="w-full h-full object-cover object-center transform group-hover:scale-[1.02] transition-transform duration-1000 ease-out"
              />

              {/* Cinematic Vignette */}
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/85 via-neutral-950/25 to-transparent pointer-events-none" />

              {/* Floating Glass Label Bar at bottom */}
              <div className="absolute bottom-4 left-4 right-4 sm:bottom-6 sm:left-6 sm:right-6 z-20 flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 sm:p-5 rounded-2xl bg-neutral-950/70 backdrop-blur-md border border-white/15 text-white">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-xl bg-gradient-to-br from-[#556B2F] to-[#FF7A00] flex items-center justify-center text-white shadow-sm shrink-0">
                    <Users className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-display font-bold text-sm sm:text-base text-white">
                      Olive Orange Technologies Engineering Collective
                    </h3>
                    <p className="text-xs text-neutral-300 font-normal">
                      Delivering custom ERP, CRM, workflow automation, and AI platforms.
                    </p>
                  </div>
                </div>

                <div className="hidden md:flex items-center gap-2 text-xs font-mono text-amber-300 bg-white/10 px-3 py-1.5 rounded-xl border border-white/10">
                  <span className="h-2 w-2 rounded-full bg-[#25D366] animate-pulse" />
                  <span>DIRECT CLIENT ACCOUNTABILITY</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ==================== 4. HOW WE WORK (PRESERVED FACTUAL APPROACH) ==================== */}
      <section className="py-20 bg-neutral-50/80 border-b border-neutral-200/60">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-[#556B2F]/10 text-[#556B2F] font-semibold uppercase tracking-widest">
              Our Methodology
            </div>
            <h2 className="font-display text-3xl sm:text-4xl font-bold mt-3 text-neutral-900 tracking-tight">
              How we approach every problem
            </h2>
            <p className="text-neutral-600 text-sm mt-2">
              Every Problem Has A Solution. We analyse your business problems and build the right digital solution.
            </p>
          </div>

          <div className="grid sm:grid-cols-3 gap-6 mt-12">
            <div className="rounded-3xl bg-white p-7 border border-neutral-200/80 shadow-sm hover:shadow-md transition-shadow duration-300">
              <div className="h-10 w-10 rounded-xl bg-[#556B2F]/10 text-[#556B2F] flex items-center justify-center font-bold text-sm">
                01
              </div>
              <h3 className="font-display font-bold text-lg mt-4 text-neutral-900">Problem Analysis</h3>
              <p className="text-neutral-600 text-sm mt-2 leading-relaxed">
                We begin by understanding your exact business bottlenecks, manual steps, and workflow inefficiencies
                before proposing any technology.
              </p>
            </div>
            <div className="rounded-3xl bg-white p-7 border border-neutral-200/80 shadow-sm hover:shadow-md transition-shadow duration-300">
              <div className="h-10 w-10 rounded-xl bg-[#FF7A00]/10 text-[#FF7A00] flex items-center justify-center font-bold text-sm">
                02
              </div>
              <h3 className="font-display font-bold text-lg mt-4 text-neutral-900">The Right Digital Solution</h3>
              <p className="text-neutral-600 text-sm mt-2 leading-relaxed">
                We design and build the right digital solution tailored to your operational scale, whether that is web,
                automation, AI, or custom software.
              </p>
            </div>
            <div className="rounded-3xl bg-white p-7 border border-neutral-200/80 shadow-sm hover:shadow-md transition-shadow duration-300">
              <div className="h-10 w-10 rounded-xl bg-[#556B2F]/10 text-[#556B2F] flex items-center justify-center font-bold text-sm">
                03
              </div>
              <h3 className="font-display font-bold text-lg mt-4 text-neutral-900">Delivery &amp; Support</h3>
              <p className="text-neutral-600 text-sm mt-2 leading-relaxed">
                We ensure seamless implementation, user onboarding, and ongoing maintenance to keep your systems running
                smoothly.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ==================== 5. CAREERS & TALENT OPPORTUNITIES ==================== */}
      <section className="py-20 pb-24">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-[#FF7A00]/10 text-[#FF7A00] font-semibold uppercase tracking-widest">
                Career Opportunities
              </div>
              <h2 className="font-display text-3xl sm:text-4xl font-bold mt-3 text-neutral-900 tracking-tight">
                Work with Olive Orange Technologies
              </h2>
              <p className="text-neutral-600 text-sm mt-2 max-w-xl leading-relaxed">
                Passionate about solving real-world business challenges through technology? Explore open engineering
                roles or submit your portfolio directly.
              </p>
            </div>
            <a
              href="mailto:oliveorangetechnologies@gmail.com?subject=Career Inquiry - Olive Orange Technologies"
              className="inline-flex items-center gap-2 text-sm font-semibold text-[#556B2F] hover:text-brand-700 transition"
            >
              Email resume directly <ArrowRight className="h-4 w-4" />
            </a>
          </div>

          <div className="space-y-4">
            {OPEN_POSITIONS.map((pos) => (
              <div
                key={pos.title}
                className="rounded-3xl bg-white p-6 sm:p-7 border border-neutral-200/80 hover:border-[#FF7A00]/50 shadow-sm hover:shadow-md flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all duration-300"
              >
                <div>
                  <h3 className="font-display font-bold text-lg text-neutral-900">{pos.title}</h3>
                  <div className="flex items-center gap-2 text-xs text-neutral-500 mt-1">
                    <span>{pos.type}</span>
                    <span aria-hidden="true">·</span>
                    <span>{pos.location}</span>
                    <span aria-hidden="true">·</span>
                    <span>{pos.exp}</span>
                  </div>
                  <p className="text-xs text-neutral-600 mt-2 max-w-2xl leading-relaxed">{pos.desc}</p>
                </div>
                <button
                  onClick={() => setApplyModal({ open: true, role: pos.title })}
                  className="px-5 py-2.5 rounded-full bg-neutral-900 hover:bg-black text-white text-xs font-semibold whitespace-nowrap transition self-start md:self-center shadow-xs"
                >
                  Apply for Role
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ==================== 6. APPLICATION MODAL ==================== */}
      <AnimatePresence>
        {applyModal.open && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="relative w-full max-w-lg bg-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-neutral-200"
            >
              <button
                onClick={() => setApplyModal({ open: false, role: '' })}
                className="absolute top-5 right-5 p-2 rounded-full hover:bg-neutral-100 text-neutral-500"
                aria-label="Close modal"
              >
                <XIcon className="h-5 w-5" />
              </button>

              <div className="inline-flex items-center gap-1.5 text-xs px-3 py-1 rounded-full bg-[#556B2F]/10 text-[#556B2F] font-semibold uppercase tracking-widest">
                Career Application
              </div>
              <h3 className="font-display text-2xl font-bold mt-2 text-neutral-900">Apply: {applyModal.role}</h3>
              <p className="text-xs text-neutral-500 mt-1">
                Tell us about your background, code repos, and engineering experience.
              </p>

              <form onSubmit={handleApply} className="mt-5 space-y-3">
                <input
                  required
                  value={applyForm.name}
                  onChange={(e) => setApplyForm({ ...applyForm, name: e.target.value })}
                  placeholder="Your Full Name*"
                  className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-[#FF7A00] focus:outline-none focus:ring-2 focus:ring-[#FF7A00]/20"
                />
                <div className="grid sm:grid-cols-2 gap-3">
                  <input
                    type="email"
                    value={applyForm.email}
                    onChange={(e) => setApplyForm({ ...applyForm, email: e.target.value })}
                    placeholder="Email Address"
                    className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-[#FF7A00] focus:outline-none focus:ring-2 focus:ring-[#FF7A00]/20"
                  />
                  <input
                    required
                    value={applyForm.phone}
                    onChange={(e) => setApplyForm({ ...applyForm, phone: e.target.value })}
                    placeholder="Phone / WhatsApp*"
                    className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-[#FF7A00] focus:outline-none focus:ring-2 focus:ring-[#FF7A00]/20"
                  />
                </div>
                <input
                  value={applyForm.portfolio}
                  onChange={(e) => setApplyForm({ ...applyForm, portfolio: e.target.value })}
                  placeholder="Portfolio / LinkedIn / GitHub URL"
                  className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-[#FF7A00] focus:outline-none focus:ring-2 focus:ring-[#FF7A00]/20"
                />
                <textarea
                  rows={3}
                  value={applyForm.note}
                  onChange={(e) => setApplyForm({ ...applyForm, note: e.target.value })}
                  placeholder="Tell us about what you build and your engineering background"
                  className="w-full px-4 py-2.5 text-sm rounded-xl border border-neutral-200 focus:border-[#FF7A00] focus:outline-none focus:ring-2 focus:ring-[#FF7A00]/20"
                />

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="button"
                    onClick={() => setApplyModal({ open: false, role: '' })}
                    className="px-4 py-2 text-xs font-semibold text-neutral-600 hover:text-neutral-900"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={submittingApply}
                    className="px-5 py-2.5 rounded-full bg-[#FF7A00] hover:bg-[#e06c00] text-white text-xs font-semibold shadow-xs disabled:opacity-60 transition"
                  >
                    {submittingApply ? 'Submitting…' : 'Submit Application'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <FooterCTA />
      <DemoModal open={demoOpen} onClose={() => setDemoOpen(false)} />
    </main>
  )
}

'use client'
import { useState, useMemo } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { Sparkles, Clock, ArrowRight, User, Search, Tag } from 'lucide-react'
import HeaderClient from '@/components/HeaderClient'
import FooterCTA from '@/components/FooterCTA'

const CATEGORIES = [
  'All',
  'AI & Automation',
  'CRM & Sales',
  'ERP & Operations',
  'Healthcare',
  'Real Estate',
  'Retail & F&B',
  'Cloud & DevOps',
  'Startups',
]

function fmtDate(iso) {
  return new Date(iso).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
}

function getPostImage(post) {
  let src = post?.featuredImage || post?.image || post?.coverImage || ''
  if (!src || typeof src !== 'string' || src.includes('undefined') || src.includes('kommodo.ai/i/')) {
    return 'https://images.unsplash.com/photo-1652156752342-c786f1e1d1ce?w=1200&auto=format&fit=crop&q=80'
  }
  if (src.startsWith('https://images.unsplash.com/') && !src.includes('?')) {
    return `${src}?w=1200&auto=format&fit=crop&q=80`
  }
  return src
}

export default function BlogIndexClient({ initialPosts }) {
  const [activeCategory, setActiveCategory] = useState('All')
  const [searchTerm, setSearchTerm] = useState('')

  const filteredPosts = useMemo(() => {
    return initialPosts.filter((p) => {
      const matchesCat = activeCategory === 'All' || p.category === activeCategory
      const matchesSearch =
        p.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (p.tags || []).some((t) => t.toLowerCase().includes(searchTerm.toLowerCase()))
      return matchesCat && matchesSearch
    })
  }, [initialPosts, activeCategory, searchTerm])

  const featured = filteredPosts[0] || initialPosts[0]
  const rest = filteredPosts.slice(1)

  return (
    <main className="relative bg-white text-neutral-900 overflow-x-hidden">
      <HeaderClient />

      {/* Hero */}
      <section className="relative pt-36 pb-10 sm:pt-44">
        <div className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
          <div className="absolute -top-24 -left-24 h-[400px] w-[400px] rounded-full bg-brand-200 opacity-60 blob" />
          <div
            className="absolute top-10 -right-20 h-[500px] w-[500px] rounded-full bg-orange-100 opacity-70 blob"
            style={{ animationDelay: '-4s' }}
          />
          <div className="absolute inset-0 grid-pattern opacity-40" />
        </div>
        <div className="container max-w-5xl mx-auto text-center px-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-brand-100 text-brand-700 text-xs font-semibold uppercase tracking-widest">
            <Sparkles className="h-3.5 w-3.5" /> Engineering &amp; Strategic Perspectives
          </div>
          <h1 className="font-display text-4xl sm:text-6xl font-bold mt-4 tracking-tight leading-[1.05] text-neutral-900">
            Insights that{' '}
            <span className="bg-gradient-to-r from-brand-500 via-orange-500 to-amber-500 bg-clip-text text-transparent">
              ship results.
            </span>
          </h1>
          <p className="text-neutral-600 text-lg mt-5 max-w-2xl mx-auto leading-relaxed">
            Honest architectural playbooks, practical AI implementation case studies, and digital transformation guides
            from the engineers at Olive Orange Technologies.
          </p>
        </div>
      </section>

      {/* Search and Category Filter Bar */}
      <section className="pb-8">
        <div className="container max-w-7xl mx-auto px-4 space-y-4">
          {/* Search Input */}
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-3.5 top-3 h-4 w-4 text-neutral-400" />
            <input
              type="text"
              placeholder="Search articles by title, keyword, or topic…"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 text-xs rounded-2xl border border-neutral-200 focus:outline-none focus:border-brand-500 shadow-sm"
            />
          </div>

          {/* Interactive Category Tabs */}
          <div className="flex items-center justify-center flex-wrap gap-1.5 p-1 bg-neutral-100/80 rounded-2xl max-w-4xl mx-auto">
            {CATEGORIES.map((cat) => {
              const active = activeCategory === cat
              return (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`px-3.5 py-1.5 text-xs font-medium rounded-xl transition whitespace-nowrap ${
                    active
                      ? 'bg-white text-neutral-900 shadow-sm font-semibold'
                      : 'text-neutral-600 hover:text-neutral-900'
                  }`}
                >
                  {cat}
                </button>
              )
            })}
          </div>
        </div>
      </section>

      {/* Featured Article */}
      {featured && (
        <section className="py-6">
          <div className="container max-w-7xl mx-auto px-4">
            <Link href={`/blog/${featured.slug}`} className="group block">
              <div className="grid lg:grid-cols-12 gap-8 items-center rounded-3xl overflow-hidden bg-white border border-neutral-200/80 shadow-sm hover:shadow-md transition">
                <div className="lg:col-span-7 relative aspect-[16/10] lg:aspect-auto lg:h-full min-h-[300px]">
                  <Image
                    src={getPostImage(featured)}
                    alt={featured.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                    sizes="(max-width: 1024px) 100vw, 60vw"
                    priority
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="lg:col-span-5 p-8 lg:p-10">
                  {/* Clean unboxed metadata */}
                  <div className="flex items-center gap-2 text-xs text-neutral-500">
                    <span className="font-semibold text-brand-600">{featured.category}</span>
                    <span aria-hidden="true">·</span>
                    <span>{featured.readMin} min read</span>
                    <span aria-hidden="true">·</span>
                    <span>{fmtDate(featured.date)}</span>
                  </div>

                  <h2 className="font-display text-2xl sm:text-3xl font-bold mt-3 leading-tight text-neutral-900 group-hover:text-brand-600 transition">
                    {featured.title}
                  </h2>
                  <p className="text-neutral-600 text-sm mt-3 leading-relaxed">{featured.excerpt}</p>

                  <div className="mt-6 flex items-center justify-between pt-4 border-t border-neutral-100">
                    <div className="text-xs text-neutral-600 font-medium">By {featured.author}</div>
                    <div className="inline-flex items-center gap-1.5 text-brand-600 text-xs font-semibold group-hover:gap-2 transition-all">
                      Read In-Depth Playbook <ArrowRight className="h-3.5 w-3.5" />
                    </div>
                  </div>
                </div>
              </div>
            </Link>
          </div>
        </section>
      )}

      {/* Grid of Articles */}
      <section className="py-10 pb-20">
        <div className="container max-w-7xl mx-auto px-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {rest.map((p) => (
              <Link key={p.slug} href={`/blog/${p.slug}`} className="group flex">
                <article className="w-full rounded-3xl bg-white border border-neutral-200/80 hover:border-brand-300 shadow-sm hover:shadow-md transition flex flex-col justify-between overflow-hidden">
                  <div>
                    <div className="relative aspect-[16/10] overflow-hidden">
                      <Image
                        src={getPostImage(p)}
                        alt={p.title}
                        fill
                        sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 33vw"
                        className="object-cover group-hover:scale-105 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                    </div>
                    <div className="p-6">
                      {/* Clean unboxed metadata */}
                      <div className="flex items-center gap-2 text-xs text-neutral-500">
                        <span className="font-semibold text-brand-600">{p.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>{p.readMin}m read</span>
                      </div>

                      <h3 className="font-display font-bold text-base leading-snug mt-2 text-neutral-900 group-hover:text-brand-600 transition line-clamp-2">
                        {p.title}
                      </h3>
                      <p className="text-neutral-600 text-xs mt-2 line-clamp-3 leading-relaxed">{p.excerpt}</p>
                    </div>
                  </div>

                  <div className="p-6 pt-0">
                    <div className="pt-3 border-t border-neutral-100 flex items-center justify-between text-xs text-neutral-500">
                      <span>{p.author}</span>
                      <span>{fmtDate(p.date)}</span>
                    </div>
                  </div>
                </article>
              </Link>
            ))}
          </div>

          {filteredPosts.length === 0 && (
            <div className="py-16 text-center text-neutral-500">
              <p className="text-base font-semibold text-neutral-800">No articles found</p>
              <p className="text-xs text-neutral-500 mt-1">Try another search keyword or clear category filters.</p>
              <button
                onClick={() => {
                  setActiveCategory('All')
                  setSearchTerm('')
                }}
                className="mt-4 px-4 py-2 rounded-xl bg-neutral-900 text-white text-xs font-semibold"
              >
                Reset Filters
              </button>
            </div>
          )}
        </div>
      </section>

      <FooterCTA />
    </main>
  )
}

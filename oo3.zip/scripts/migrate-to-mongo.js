/**
 * Safe Migration Script: Local Data -> MongoDB
 * Usage: node scripts/migrate-to-mongo.js
 *
 * Safety Guarantees:
 * 1. Checks existing collections before inserting.
 * 2. NEVER overwrites or drops existing production collections.
 * 3. Preserves all local development data and seed articles.
 */

const fs = require('fs')
const path = require('path')
const { MongoClient } = require('mongodb')

let MONGO_URI = process.env.MONGO_URI || process.env.MONGO_URL || ''
let DB_NAME = process.env.DB_NAME || 'olive_orange'

// If not in shell environment, load from .env.local if present
if (!MONGO_URI) {
  const envLocalPath = path.join(process.cwd(), '.env.local')
  if (fs.existsSync(envLocalPath)) {
    const lines = fs.readFileSync(envLocalPath, 'utf-8').split('\n')
    for (const line of lines) {
      if (line.startsWith('MONGO_URI=')) MONGO_URI = line.substring('MONGO_URI='.length).trim()
      if (line.startsWith('DB_NAME=')) DB_NAME = line.substring('DB_NAME='.length).trim()
    }
  }
}

async function migrate() {
  console.log('========================================================')
  console.log('Olive Orange Technologies — Safe MongoDB Migration Tool')
  console.log('========================================================')

  if (!MONGO_URI) {
    console.error('ERROR: Neither MONGO_URI nor MONGO_URL environment variable is set.')
    console.log('Please provide MONGO_URI to run this migration.')
    process.exit(1)
  }

  console.log(`Connecting to MongoDB database: ${DB_NAME}...`)
  const client = new MongoClient(MONGO_URI, { serverSelectionTimeoutMS: 5000 })

  try {
    await client.connect()
    console.log('✓ Successfully connected to MongoDB.')

    const db = client.db(DB_NAME)

    // Load local files if available
    const cmsFilePath = path.join(process.cwd(), 'data', 'cms-store.json')
    const usersFilePath = path.join(process.cwd(), 'data', 'admin-users.json')

    let cmsData = {}
    if (fs.existsSync(cmsFilePath)) {
      try {
        cmsData = JSON.parse(fs.readFileSync(cmsFilePath, 'utf-8'))
        console.log(`Found local CMS file: ${cmsFilePath}`)
      } catch (e) {
        console.warn('Could not parse local cms-store.json:', e.message)
      }
    }

    let usersData = []
    if (fs.existsSync(usersFilePath)) {
      try {
        usersData = JSON.parse(fs.readFileSync(usersFilePath, 'utf-8'))
        console.log(`Found local admin users file: ${usersFilePath}`)
      } catch (e) {
        console.warn('Could not parse local admin-users.json:', e.message)
      }
    }

    const collectionsToMigrate = [
      { name: 'posts', items: cmsData.posts || [] },
      { name: 'categories', items: cmsData.categories || [] },
      { name: 'team', items: cmsData.team || [] },
      { name: 'media', items: cmsData.media || [] },
      { name: 'leads', items: cmsData.leads || [] },
      { name: 'admin_users', items: usersData || [] },
    ]

    for (const { name, items } of collectionsToMigrate) {
      const coll = db.collection(name)
      const existingCount = await coll.countDocuments()

      if (existingCount > 0) {
        console.log(`[SAFE] Collection "${name}" already contains ${existingCount} documents. Preserving existing data (skipped).`)
      } else if (items.length > 0) {
        const sanitizedItems = items.map(({ _id, ...rest }) => rest)
        const result = await coll.insertMany(sanitizedItems)
        console.log(`[MIGRATED] Collection "${name}" seeded with ${result.insertedCount} documents from local storage.`)
      } else {
        console.log(`[INFO] Collection "${name}" is empty and no local items were found to seed.`)
      }
    }

    // Settings migration
    const settingsColl = db.collection('settings')
    const existingSettings = await settingsColl.findOne({ id: 'primary_settings' })
    if (existingSettings) {
      console.log('[SAFE] Settings document already exists. Preserving existing configuration.')
    } else if (cmsData.settings) {
      await settingsColl.insertOne({
        id: 'primary_settings',
        ...cmsData.settings,
        migratedAt: new Date().toISOString(),
      })
      console.log('[MIGRATED] Settings document migrated successfully.')
    }

    console.log('========================================================')
    console.log('Migration completed safely with zero data loss.')
    console.log('========================================================')
  } catch (err) {
    console.error('Migration failed:', err.message)
    process.exit(1)
  } finally {
    await client.close()
  }
}

if (require.main === module) {
  migrate()
}

module.exports = { migrate }
